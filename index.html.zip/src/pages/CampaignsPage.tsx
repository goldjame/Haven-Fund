import { Baby, HelpCircle, Layers, Users, Wallet, ListChecks } from "lucide-react";
import Campaigns from "../components/Campaigns";
import { CtaBand, GhostLink, PageHero, PrimaryLink, Section } from "../components/layout";
import { SectionHeading } from "../components/ui";
import { CAMPAIGNS } from "../config/campaigns";
import { to } from "../router";

export default function CampaignsPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Causes & Campaigns"
        title="Choose where your"
        accent="kindness goes."
        crumb="Campaigns"
        chips={[`${CAMPAIGNS.length} open campaigns`, "Street children", "Homeless people", "Same secure wallets"]}
        actions={
          <>
            <PrimaryLink href={to("donate", undefined, { campaign: "general" })}>Give to the General Fund</PrimaryLink>
            <GhostLink href={to("impact")}>How donations help</GhostLink>
          </>
        }
      >
        Each campaign is a focus area describing how donations are intended to be used. Choose the cause closest to your heart — or the General
        Fund to support wherever the need is greatest.
      </PageHero>

      {/* Causes */}
      <Section className="pt-0" labelledBy="causes-title">
        <h2 id="causes-title" className="sr-only">Our causes</h2>
        <div className="grid gap-5 md:grid-cols-2">
          {[
            { icon: Baby, t: "Street children", d: "Children and young people living or working on the streets, often without stable care, safety or schooling.", c: "text-hope-300 bg-hope-400/15" },
            { icon: Users, t: "Homeless people", d: "Individuals and families without secure housing, facing exposure, hunger and isolation.", c: "text-tech-300 bg-tech-400/15" },
          ].map((x) => (
            <div key={x.t} className="reveal glass flex gap-5 rounded-3xl p-6">
              <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${x.c}`}><x.icon className="h-6 w-6" /></span>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Our cause</p>
                <h3 className="mt-1 font-display text-3xl text-white">{x.t}</h3>
                <p className="mt-2 text-sm text-slate-400">{x.d}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Campaigns showHeading={false} />

      {/* How campaigns work */}
      <Section labelledBy="how-campaigns">
        <SectionHeading id="how-campaigns" eyebrow="How campaigns work" title="Simple, open," accent="and honest.">
          What happens when you choose a campaign.
        </SectionHeading>
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: ListChecks, t: "Pick a campaign", d: "Choose a focus area in the donation panel, or tap “Donate to this campaign” on any card." },
            { icon: Wallet, t: "Same secure wallets", d: "All campaigns use the same verified wallets, so you never need a different address." },
            { icon: Layers, t: "Preference recorded", d: "Your campaign choice is saved with your donation reference to guide allocation." },
            { icon: HelpCircle, t: "Verified progress only", d: "Targets and progress are shown only once verified figures are published." },
          ].map((s, i) => (
            <div key={s.t} className="reveal glass rounded-3xl p-6" style={{ transitionDelay: `${i * 80}ms` }}>
              <s.icon className="h-6 w-6 text-hope-300" />
              <h3 className="mt-4 font-bold text-white">{s.t}</h3>
              <p className="mt-2 text-sm text-slate-400">{s.d}</p>
            </div>
          ))}
        </div>
      </Section>

      <CtaBand title="Not sure which to choose?" text="The Haven General Fund supports wherever the need is greatest — or ask Haven AI to explain each campaign." />
    </>
  );
}
