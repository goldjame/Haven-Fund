import type React from "react";
import { cn } from "../../utils/cn";

export function Row({ k, children }: { k: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-slate-500">{k}</dt>
      <dd className="text-right">{children}</dd>
    </div>
  );
}

export function NavRow({ children }: { children: React.ReactNode }) {
  return <div className="mt-8 flex items-center justify-between gap-3 border-t border-white/5 pt-6">{children}</div>;
}

export function PrimaryBtn({ children, className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...p}
      className={cn(
        "btn-shine inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold text-ink-950 shadow-[0_10px_30px_-10px_rgba(245,180,60,0.8)] transition hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100",
        className
      )}
    >
      {children}
    </button>
  );
}

export function GhostBtn({ children, className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...p}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-slate-200 transition hover:bg-white/10",
        className
      )}
    >
      {children}
    </button>
  );
}
