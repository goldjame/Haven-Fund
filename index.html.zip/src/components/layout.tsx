import type { ReactNode } from "react";
import { ArrowRight, ChevronRight, MessageCircle } from "lucide-react";
import hero from "../assets/hero.jpg";
import { to } from "../router";
import { openHavenAI } from "./AssistantSection";
import { cn } from "../utils/cn";

export function PageHero({
  eyebrow,
  title,
  accent,
  children,
  crumb,
  actions,
  chips,
}: {
  eyebrow: string;
  title: string;
  accent?: string;
  children?: ReactNode;
  crumb: string;
  actions?: ReactNode;
  chips?: string[];
}) {
  return (
    <header className="relative isolate overflow-hidden pb-14 pt-32 md:pb-20 md:pt-40">
      <div aria-hidden className="absolute inset-0 -z-10">
        <img src={hero} alt="" className="absolute right-0 top-0 h-full w-full object-cover object-[70%_center] opacity-25 md:w-2/3" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/90 to-ink-950/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/70" />
        <div className="absolute -left-20 top-20 h-72 w-72 rounded-full bg-hope-500/15 blur-[100px]" />
      </div>
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <nav aria-label="Breadcrumb" className="animate-fade-up">
          <ol className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
            <li><a href={to("home")} className="hover:text-white">Home</a></li>
            <li aria-hidden><ChevronRight className="h-3.5 w-3.5" /></li>
            <li aria-current="page" className="text-slate-300">{crumb}</li>
          </ol>
        </nav>
        <p className="animate-fade-up mt-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-hope-300 [animation-delay:60ms]">
          <span className="h-1.5 w-1.5 rounded-full bg-hope-400 shadow-[0_0_10px_2px_rgba(245,180,60,0.7)]" />
          {eyebrow}
        </p>
        <h1 className="animate-fade-up mt-5 max-w-4xl font-display text-5xl leading-[0.98] text-white [animation-delay:120ms] sm:text-6xl md:text-7xl">
          {title} {accent && <em className="text-gradient italic">{accent}</em>}
        </h1>
        {children && (
          <p className="animate-fade-up mt-6 max-w-2xl text-base leading-relaxed text-slate-300 [animation-delay:180ms] md:text-lg">{children}</p>
        )}
        {chips && (
          <ul className="animate-fade-up mt-7 flex flex-wrap gap-2 [animation-delay:240ms]">
            {chips.map((c) => (
              <li key={c} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-200 backdrop-blur">{c}</li>
            ))}
          </ul>
        )}
        {actions && <div className="animate-fade-up mt-8 flex flex-col gap-3 [animation-delay:280ms] sm:flex-row">{actions}</div>}
      </div>
    </header>
  );
}

export function Section({ id, children, className, labelledBy }: { id?: string; children: ReactNode; className?: string; labelledBy?: string }) {
  return (
    <section id={id} aria-labelledby={labelledBy} className={cn("relative scroll-mt-24 py-20 md:py-28", className)}>
      <div className="mx-auto max-w-7xl px-5 sm:px-8">{children}</div>
    </section>
  );
}

export function PrimaryLink({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return (
    <a
      href={href}
      className={cn(
        "btn-shine group inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-3.5 font-bold text-ink-950 shadow-[0_18px_50px_-14px_rgba(245,180,60,0.8)] transition hover:scale-[1.02]",
        className
      )}
    >
      {children}
      <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
    </a>
  );
}

export function GhostLink({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return (
    <a
      href={href}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-6 py-3.5 font-semibold text-white backdrop-blur transition hover:border-white/30 hover:bg-white/10",
        className
      )}
    >
      {children}
    </a>
  );
}

export function CtaBand({
  title = "Ready to give hope?",
  text = "Your crypto donation is intended to help provide food, shelter, clothing, education and essential support.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <Section className="pt-6">
      <div className="reveal glass-strong border-gradient relative overflow-hidden rounded-[2.25rem] p-8 text-center md:p-14">
        <div aria-hidden className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-hope-500/20 blur-3xl" />
        <div aria-hidden className="absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-tech-500/20 blur-3xl" />
        <h2 className="relative font-display text-4xl text-white md:text-6xl">{title}</h2>
        <p className="relative mx-auto mt-4 max-w-xl text-slate-400">{text}</p>
        <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <PrimaryLink href={to("donate")}>Donate With Crypto</PrimaryLink>
          <button
            type="button"
            onClick={() => openHavenAI()}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-tech-400/40 bg-tech-400/10 px-6 py-3.5 font-bold text-tech-100 transition hover:bg-tech-400/20"
          >
            <MessageCircle className="h-4 w-4" /> Ask Haven AI
          </button>
        </div>
      </div>
    </Section>
  );
}
