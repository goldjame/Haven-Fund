/**
 * Lightweight hash router (works with the single-file static build and any
 * static host — no server rewrites needed).
 *
 *   #/                       → Home
 *   #/about                  → About Us
 *   #/about/who-we-help      → About Us, scrolled to a section
 *   #/donate?campaign=food   → Donate, with a campaign pre-selected
 *   #/updates/<slug>         → a single update / news post
 *
 * Legacy in-page anchors (e.g. "#donate", "#faq") used by older links and by
 * Haven AI are transparently redirected to their new page + section.
 */
import { useEffect, useState } from "react";

export type PageId =
  | "home"
  | "about"
  | "campaigns"
  | "donate"
  | "impact"
  | "updates"
  | "contact"
  | "privacy"
  | "terms"
  | "security"
  | "notfound";

export const PAGE_PATHS: Record<Exclude<PageId, "notfound">, string> = {
  home: "",
  about: "about",
  campaigns: "campaigns",
  donate: "donate",
  impact: "how-donations-help",
  updates: "updates",
  contact: "contact",
  privacy: "privacy",
  terms: "terms",
  security: "security",
};

const PATH_TO_PAGE: Record<string, PageId> = {
  ...Object.fromEntries(Object.entries(PAGE_PATHS).map(([k, v]) => [v, k as PageId])),
  home: "home",
  "about-us": "about",
  causes: "campaigns",
  impact: "impact",
  news: "updates",
  "contact-us": "contact",
  "privacy-policy": "privacy",
  "terms-and-conditions": "terms",
  trust: "security",
};

/** Old single-page anchors → new page + section */
const LEGACY: Record<string, { page: PageId; section?: string }> = {
  mission: { page: "about", section: "mission" },
  "who-we-help": { page: "about", section: "who-we-help" },
  about: { page: "about" },
  campaigns: { page: "campaigns" },
  causes: { page: "campaigns" },
  "how-it-works": { page: "donate", section: "how-it-works" },
  donate: { page: "donate" },
  transparency: { page: "impact", section: "transparency" },
  impact: { page: "impact" },
  stories: { page: "impact", section: "stories" },
  updates: { page: "updates" },
  news: { page: "updates" },
  faq: { page: "contact", section: "faq" },
  contact: { page: "contact" },
  "haven-ai": { page: "home", section: "haven-ai" },
};

export const PAGE_META: Record<PageId, { label: string; title: string; description: string }> = {
  home: {
    label: "Home",
    title: "Haven Fund — A Digital Wallet for Human Hope | Crypto Donations for Street Children & Homeless People",
    description:
      "Donate cryptocurrency to help provide food, shelter, clothing, education and essential support to street children and homeless people. Technology With Humanity.",
  },
  about: {
    label: "About Us",
    title: "About Us — Haven Fund",
    description: "Learn about Haven Fund’s mission, values and the people we focus on: street children and homeless people.",
  },
  campaigns: {
    label: "Campaigns",
    title: "Our Causes & Campaigns — Haven Fund",
    description: "Choose a Haven Fund campaign: food, shelter, clothing, education, essential care — or the General Fund.",
  },
  donate: {
    label: "Donate",
    title: "Donate Crypto — Haven Fund",
    description: "Donate Bitcoin, Lightning, Ethereum, USDT, USDC, Solana or Litecoin in minutes with QR codes and step-by-step guidance.",
  },
  impact: {
    label: "How Donations Help",
    title: "How Donations Help — Haven Fund",
    description: "See how crypto donations are intended to be used, verify official wallets on-chain, and read our transparency commitments.",
  },
  updates: {
    label: "Updates",
    title: "Updates & News — Haven Fund",
    description: "Announcements, campaign news, transparency updates and beginner guides from Haven Fund.",
  },
  contact: {
    label: "Contact Us",
    title: "Contact Us — Haven Fund",
    description: "Contact Haven Fund by email, phone or Facebook, and find answers to frequently asked questions.",
  },
  privacy: { label: "Privacy Policy", title: "Privacy Policy — Haven Fund", description: "How Haven Fund handles your information." },
  terms: { label: "Terms & Conditions", title: "Terms & Conditions — Haven Fund", description: "Terms and conditions for using Haven Fund and donating." },
  security: {
    label: "Security",
    title: "Security & Trust — Haven Fund",
    description: "How Haven Fund protects donors: HTTPS, security headers, wallet address checks, privacy controls, scam warnings and how to report issues.",
  },
  notfound: { label: "Not found", title: "Page not found — Haven Fund", description: "The page you are looking for could not be found." },
};

export interface Route {
  page: PageId;
  /** Section id (most pages) or slug (updates) */
  param?: string;
  query: URLSearchParams;
  /** Increments on every navigation, even to the same URL */
  nonce: number;
}

let nonce = 0;

export function to(page: Exclude<PageId, "notfound">, param?: string, query?: Record<string, string>) {
  const base = PAGE_PATHS[page];
  let h = `#/${base}`;
  if (param) h += `${base ? "/" : "home/"}${encodeURIComponent(param)}`;
  if (query && Object.keys(query).length) h += `?${new URLSearchParams(query).toString()}`;
  return h;
}

export const navigate = (hash: string) => {
  if (window.location.hash === hash) window.dispatchEvent(new HashChangeEvent("hashchange"));
  else window.location.hash = hash;
};

/** Returns a route, or null for an unknown in-page anchor (e.g. "#main"). */
function resolve(hash: string): Route | null {
  if (!hash || hash === "#" || hash === "#/") return { page: "home", query: new URLSearchParams(), nonce: ++nonce };
  if (hash.startsWith("#/")) {
    const [pathPart, qs = ""] = hash.slice(2).split("?");
    const [p = "", param] = pathPart.split("/").filter(Boolean);
    const page = PATH_TO_PAGE[p] ?? "notfound";
    return { page, param: param ? decodeURIComponent(param) : undefined, query: new URLSearchParams(qs), nonce: ++nonce };
  }
  const legacy = LEGACY[hash.slice(1)];
  if (legacy) {
    const canonical = to(legacy.page as Exclude<PageId, "notfound">, legacy.section);
    history.replaceState(null, "", canonical);
    return { page: legacy.page, param: legacy.section, query: new URLSearchParams(), nonce: ++nonce };
  }
  return null;
}

const initial = (): Route => resolve(typeof window !== "undefined" ? window.location.hash : "") ?? { page: "home", query: new URLSearchParams(), nonce: 0 };

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(initial);
  useEffect(() => {
    const on = () => {
      const h = window.location.hash;
      if (h === "#top") {
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      const r = resolve(h);
      if (r) setRoute(r);
      else document.getElementById(h.slice(1))?.scrollIntoView({ behavior: "smooth" });
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}
