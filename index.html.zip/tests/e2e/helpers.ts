import { expect, type Page, type Route } from "@playwright/test";
import { PNG } from "pngjs";
import jsQR from "jsqr";
import { ASSETS, type CryptoAsset } from "../../src/config/wallets";
import { tronToHex20 } from "../../src/services/verify";

export { ASSETS };
export type { CryptoAsset };

export const ROUTES = [
  { path: "/#/", h1: /Digital Wallet/ },
  { path: "/#/about", h1: /Technology with/ },
  { path: "/#/campaigns", h1: /kindness goes/ },
  { path: "/#/donate", h1: /Give in minutes/ },
  { path: "/#/how-donations-help", h1: /real needs/ },
  { path: "/#/updates", h1: /told honestly/ },
  { path: "/#/updates/meet-haven-ai", h1: /Meet Haven AI/ },
  { path: "/#/contact", h1: /about hope/ },
  { path: "/#/security", h1: /confidence/ },
  { path: "/#/privacy", h1: /Privacy Policy/ },
  { path: "/#/terms", h1: /Terms & Conditions/ },
];

/** Skip the first-visit privacy banner (tested separately). */
export async function presetConsent(page: Page, overrides: Record<string, boolean> = {}) {
  await page.addInitScript((o) => {
    if (!localStorage.getItem("havenfund.consent"))
      localStorage.setItem("havenfund.consent", JSON.stringify({ preferences: false, prices: false, voice: false, decided: true, version: 1, ...o }));
  }, overrides);
}

/** Collect console errors & uncaught exceptions. */
export function trackErrors(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console: ${m.text()}`);
  });
  return errors;
}

export async function expectNoHorizontalScroll(page: Page) {
  const r = await page.evaluate(() => {
    const vw = window.innerWidth;
    const offenders = Array.from(document.querySelectorAll<HTMLElement>("body *"))
      .filter((el) => {
        const b = el.getBoundingClientRect();
        if (!b.width || getComputedStyle(el).position === "fixed") return false;
        let p: HTMLElement | null = el.parentElement;
        while (p) {
          const ov = getComputedStyle(p).overflowX;
          if (ov === "hidden" || ov === "auto" || ov === "scroll" || ov === "clip") return false;
          p = p.parentElement;
        }
        return b.right > vw + 1;
      })
      .slice(0, 5)
      .map((el) => `${el.tagName.toLowerCase()}.${String(el.className).slice(0, 60)} → right ${Math.round(el.getBoundingClientRect().right)}`);
    return { scroll: document.documentElement.scrollWidth, vw, offenders };
  });
  expect(r.offenders, `elements overflowing the ${r.vw}px viewport`).toEqual([]);
  expect(r.scroll).toBeLessThanOrEqual(r.vw + 1);
}

/* ------------------------------ network mocks ------------------------------ */
export interface EmailCapture {
  requests: { body: Record<string, string>; referer?: string; url: string }[];
}

export async function mockEmail(page: Page, mode: "ok" | "activation" | "down" = "ok"): Promise<EmailCapture> {
  const cap: EmailCapture = { requests: [] };
  await page.route("https://formsubmit.co/**", async (route) => {
    const req = route.request();
    cap.requests.push({ body: req.postDataJSON(), referer: req.headers()["referer"], url: req.url() });
    if (mode === "down") return route.abort("failed");
    if (mode === "activation")
      return route.fulfill({ json: { success: "false", message: "This form needs Activation. We've sent you an email containing an 'Activate Form' link." } });
    return route.fulfill({ json: { success: "true", message: "The form was submitted successfully." } });
  });
  return cap;
}

const pad64 = (hex: string) => hex.replace(/^0x/, "").padStart(64, "0");
export const RECEIVED: Record<string, number> = { BTC: 0.0015, LTC: 0.25, ETH: 0.01, USDC: 25, USDT: 25, SOL: 1.5 };

/** Sample tx ids that pass each network's format check. */
export const TX: Record<string, string> = {
  BTC: "a".repeat(64),
  LN: "b".repeat(64),
  ETH: "0x" + "c".repeat(64),
  USDC: "0x" + "d".repeat(64),
  USDT: "e".repeat(64),
  SOL: "5".repeat(87) + "A",
  LTC: "f".repeat(64),
};

/**
 * Mock every public blockchain API the site uses.
 * scenario: "paid" → tx pays Haven Fund; "other" → tx pays someone else; "missing" → tx doesn't exist.
 */
export async function mockChains(page: Page, scenario: "paid" | "other" | "missing" = "paid") {
  const addr = (id: string) => ASSETS.find((a) => a.id === id)!.address;
  const esplora = (id: "BTC" | "LTC") => async (route: Route) => {
    if (scenario === "missing") return route.fulfill({ status: 404, body: "Transaction not found" });
    return route.fulfill({
      json: {
        vout: [{ scriptpubkey_address: scenario === "paid" ? addr(id) : "bc1qsomeoneelse000000000000000000000000000", value: Math.round(RECEIVED[id] * 1e8) }],
        status: { confirmed: true, block_height: 900123 },
      },
    });
  };
  await page.route("https://mempool.space/api/tx/**", esplora("BTC"));
  await page.route("https://litecoinspace.org/api/tx/**", esplora("LTC"));

  await page.route("https://ethereum-rpc.publicnode.com/**", async (route) => {
    const { method, params } = route.request().postDataJSON();
    const isUsdc = String(params[0]).startsWith("0xd");
    const me = scenario === "paid" ? addr("ETH").toLowerCase() : "0x000000000000000000000000000000000000dead";
    if (scenario === "missing") return route.fulfill({ json: { jsonrpc: "2.0", id: 1, result: null } });
    if (method === "eth_getTransactionByHash")
      return route.fulfill({
        json: { jsonrpc: "2.0", id: 1, result: isUsdc ? { to: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", value: "0x0", blockNumber: "0x10" } : { to: me, value: "0x" + (BigInt(RECEIVED.ETH * 1e6) * 10n ** 12n).toString(16), blockNumber: "0x10" } },
      });
    if (method === "eth_getTransactionReceipt")
      return route.fulfill({
        json: {
          jsonrpc: "2.0",
          id: 1,
          result: {
            status: "0x1",
            blockNumber: "0x1592a3c",
            logs: isUsdc
              ? [{ address: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", topics: ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x" + pad64("1234"), "0x" + pad64(me)], data: "0x" + pad64((RECEIVED.USDC * 1e6).toString(16)) }]
              : [],
          },
        },
      });
    return route.fulfill({ json: { jsonrpc: "2.0", id: 1, result: null } });
  });

  await page.route("https://api.trongrid.io/**", async (route) => {
    if (scenario === "missing") return route.fulfill({ json: {} });
    const to = scenario === "paid" ? tronToHex20(addr("USDT")) : "99ec79385b07412db62197cfcbe76f39e22db8dd";
    return route.fulfill({
      json: {
        id: TX.USDT,
        blockNumber: 70000000,
        receipt: { result: "SUCCESS" },
        log: [{ address: tronToHex20("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"), topics: ["ddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", pad64("abcd"), pad64(to)], data: pad64((RECEIVED.USDT * 1e6).toString(16)) }],
      },
    });
  });

  await page.route("https://solana-rpc.publicnode.com/**", async (route) => {
    if (scenario === "missing") return route.fulfill({ json: { jsonrpc: "2.0", id: 1, result: null } });
    const me = scenario === "paid" ? addr("SOL") : "SomeoneElse1111111111111111111111111111111";
    return route.fulfill({
      json: { jsonrpc: "2.0", id: 1, result: { slot: 380000000, meta: { err: null, preBalances: [5e9, 2e9], postBalances: [3.5e9 - 5000, 2e9 + RECEIVED.SOL * 1e9] }, transaction: { message: { accountKeys: [{ pubkey: "Payer111111111111111111111111111111111111111" }, { pubkey: me }] } } } },
    });
  });
}

/** Decode the QR code shown on screen and return its text. */
export async function readQr(page: Page): Promise<string | null> {
  const box = page.locator("[data-qr-zone]");
  // Worst case for phones: QR at the very bottom of the screen, where floating buttons live.
  await box.evaluate((el) => el.scrollIntoView({ block: "end" }));
  await page.waitForTimeout(400);
  const coveredNow = () =>
    box.evaluate((el) => {
      const r = el.getBoundingClientRect();
      const pts: [number, number][] = [];
      for (let i = 1; i < 10; i++) for (let j = 1; j < 10; j++) pts.push([r.left + (r.width * i) / 10, r.top + (r.height * j) / 10]);
      const describe = (n: Element) => {
        const host = n.closest("[id],[aria-label],button,a,header,footer,nav") as HTMLElement | null;
        return `${n.tagName.toLowerCase()} in ${host ? `${host.tagName.toLowerCase()}${host.id ? "#" + host.id : ""}${host.getAttribute("aria-label") ? `[${host.getAttribute("aria-label")}]` : ""}` : "?"}`;
      };
      return [...new Set(pts
        .filter(([x, y]) => y < window.innerHeight && x < window.innerWidth)
        .map(([x, y]) => document.elementFromPoint(x, y))
        .filter((hit): hit is Element => !!hit && !el.contains(hit))
        .map(describe))];
    });
  // The QR must become fully unobstructed shortly after scrolling stops.
  await expect.poll(coveredNow, { message: "nothing may cover the QR code", timeout: 3000, intervals: [100, 200, 400] }).toEqual([]);
  const png = PNG.sync.read(await box.screenshot({ animations: "disabled" }));
  const res = jsQR(new Uint8ClampedArray(png.data.buffer, png.data.byteOffset, png.data.length), png.width, png.height, { inversionAttempts: "dontInvert" });
  return res?.data ?? null;
}

export const AMOUNT: Record<string, string> = { BTC: "0.0015", LN: "5000", ETH: "0.01", USDT: "25", USDC: "25", SOL: "1.5", LTC: "0.25" };

/** Walk the donation panel from asset selection to the confirmation step. */
export async function goToConfirmStep(page: Page, asset: CryptoAsset, amount = AMOUNT[asset.id]) {
  const panel = page.locator("#donate-panel");
  await panel.getByRole("radio").filter({ hasText: asset.network }).click();
  await panel.getByRole("button", { name: new RegExp(`Continue with ${asset.symbol.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`) }).click();
  await panel.getByLabel(new RegExp(`Amount in ${asset.unit}`)).fill(amount);
  await panel.getByRole("button", { name: "Show wallet address" }).click();
  await expect(panel.getByText(`Send ${asset.name}`)).toBeVisible();
  return panel;
}
