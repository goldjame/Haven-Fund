import type { AssetId } from "../config/wallets";

export function CryptoIcon({ id, size = 36, className }: { id: AssetId; size?: number; className?: string }) {
  const common = { width: size, height: size, viewBox: "0 0 32 32", className, "aria-hidden": true as const };
  switch (id) {
    case "BTC":
      return (
        <svg {...common}>
          <circle cx="16" cy="16" r="16" fill="#F7931A" />
          <path
            fill="#FFF"
            d="M23.189 14.02c.314-2.096-1.283-3.223-3.465-3.975l.708-2.84-1.728-.43-.69 2.765c-.454-.114-.92-.22-1.385-.326l.695-2.783L15.596 6l-.708 2.839c-.376-.086-.746-.17-1.104-.26l.002-.009-2.384-.595-.46 1.846s1.283.294 1.256.312c.7.175.826.638.805 1.006l-.806 3.235c.048.012.11.03.18.057l-.183-.045-1.13 4.532c-.086.212-.303.531-.793.41.018.025-1.256-.313-1.256-.313l-.858 1.978 2.25.561c.418.105.828.215 1.231.318l-.715 2.872 1.727.43.708-2.84c.472.127.93.245 1.378.357l-.706 2.828 1.728.43.715-2.866c2.948.558 5.164.333 6.097-2.333.752-2.146-.037-3.385-1.588-4.192 1.13-.26 1.98-1.003 2.207-2.538zm-3.95 5.538c-.533 2.147-4.148.986-5.32.695l.95-3.805c1.172.293 4.929.872 4.37 3.11zm.535-5.569c-.487 1.953-3.495.96-4.47.717l.86-3.45c.975.243 4.118.696 3.61 2.733z"
          />
        </svg>
      );
    case "LN":
      return (
        <svg {...common}>
          <defs>
            <linearGradient id="ln-g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#FDE047" />
              <stop offset="1" stopColor="#F59E0B" />
            </linearGradient>
          </defs>
          <circle cx="16" cy="16" r="16" fill="#1A1405" />
          <circle cx="16" cy="16" r="15.25" fill="none" stroke="url(#ln-g)" strokeOpacity=".5" strokeWidth="1.5" />
          <path fill="url(#ln-g)" d="M18.6 5.5 9.4 17.6h5.8l-1.8 8.9 9.2-12.3h-5.9z" />
        </svg>
      );
    case "ETH":
      return (
        <svg {...common}>
          <circle cx="16" cy="16" r="16" fill="#627EEA" />
          <g fill="#FFF">
            <path fillOpacity=".6" d="M16.498 4v8.87l7.497 3.35z" />
            <path d="M16.498 4 9 16.22l7.498-3.35z" />
            <path fillOpacity=".6" d="M16.498 21.968v6.027L24 17.616z" />
            <path d="M16.498 27.995v-6.028L9 17.616z" />
            <path fillOpacity=".2" d="m16.498 20.573 7.497-4.353-7.497-3.348z" />
            <path fillOpacity=".6" d="m9 16.22 7.498 4.353v-7.701z" />
          </g>
        </svg>
      );
    case "USDT":
      return (
        <svg {...common}>
          <circle cx="16" cy="16" r="16" fill="#26A17B" />
          <path
            fill="#FFF"
            d="M17.922 17.383v-.002c-.11.008-.677.042-1.942.042-1.01 0-1.721-.03-1.971-.042v.003c-3.888-.171-6.79-.848-6.79-1.658 0-.809 2.902-1.486 6.79-1.66v2.644c.254.018.982.061 1.988.061 1.207 0 1.812-.05 1.925-.06v-2.643c3.88.173 6.775.85 6.775 1.658 0 .81-2.895 1.485-6.775 1.657m0-3.59v-2.366h5.414V7.819H8.595v3.608h5.414v2.365c-4.4.202-7.709 1.074-7.709 2.118 0 1.044 3.309 1.915 7.709 2.118v7.582h3.913v-7.584c4.393-.202 7.694-1.073 7.694-2.116 0-1.043-3.301-1.914-7.694-2.117"
          />
        </svg>
      );
    case "USDC":
      return (
        <svg {...common}>
          <circle cx="16" cy="16" r="16" fill="#2775CA" />
          <path
            fill="none"
            stroke="#FFF"
            strokeWidth="1.6"
            strokeLinecap="round"
            d="M12.2 7.6A9.4 9.4 0 0 0 12.2 24.4M19.8 7.6a9.4 9.4 0 0 1 0 16.8"
          />
          <path
            fill="none"
            stroke="#FFF"
            strokeWidth="1.8"
            strokeLinecap="round"
            d="M19.3 13.1c-.3-1.3-1.5-2-3.3-2-1.9 0-3.2.9-3.2 2.3 0 3.4 6.6 1.7 6.6 5.1 0 1.5-1.4 2.4-3.4 2.4-2 0-3.3-.8-3.6-2.3M16 9.4v1.7M16 21v1.6"
          />
        </svg>
      );
    case "SOL":
      return (
        <svg {...common}>
          <defs>
            <linearGradient id="sol-g" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0" stopColor="#9945FF" />
              <stop offset="1" stopColor="#14F195" />
            </linearGradient>
          </defs>
          <circle cx="16" cy="16" r="16" fill="#0B0B12" />
          <g fill="url(#sol-g)">
            <path d="M10.9 19.9a.6.6 0 0 1 .42-.17h13.1c.27 0 .4.32.21.5l-2.58 2.6a.6.6 0 0 1-.42.17H8.53a.3.3 0 0 1-.21-.5z" />
            <path d="M10.9 9.17a.6.6 0 0 1 .42-.17h13.1c.27 0 .4.32.21.5l-2.58 2.6a.6.6 0 0 1-.42.17H8.53a.3.3 0 0 1-.21-.5z" />
            <path d="M21.63 14.5a.6.6 0 0 0-.42-.17H8.1c-.27 0-.4.32-.21.5l2.58 2.6c.11.1.26.17.42.17h13.1c.27 0 .4-.32.21-.5z" />
          </g>
        </svg>
      );
    case "LTC":
      return (
        <svg {...common}>
          <defs>
            <linearGradient id="ltc-g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#D8DADB" />
              <stop offset="1" stopColor="#8E9294" />
            </linearGradient>
          </defs>
          <circle cx="16" cy="16" r="16" fill="url(#ltc-g)" />
          <path
            fill="#FFF"
            d="M10.427 19.214 9 19.768l.688-2.759 1.444-.58L13.213 8h5.129l-1.519 6.196 1.41-.571-.68 2.75-1.427.571-.848 3.483H23L22.127 24H9.252z"
          />
        </svg>
      );
  }
}
