import { test, expect } from "@playwright/test";
import { writeFileSync, mkdirSync } from "node:fs";
import { ROUTES, presetConsent } from "./helpers";
import { NEWS } from "../../src/config/news";

test("every link on every page works", async ({ page }, info) => {
  test.setTimeout(180_000);
  await presetConsent(page);
  const start = [...ROUTES.map((r) => r.path.replace(/^\//, "")), ...NEWS.map((n) => `#/updates/${n.slug}`)];
  const internal = new Set<string>();
  const external = new Map<string, string>(); // url -> found on
  const mailtoTel = new Set<string>();

  for (const p of start) {
    await page.goto(`/${p}`);
    await expect(page.locator("h1").first()).toBeVisible();
    const hrefs = await page.$$eval("a[href]", (as) => as.map((a) => a.getAttribute("href")!));
    for (const h of hrefs) {
      if (h.startsWith("#")) internal.add(h);
      else if (h.startsWith("mailto:") || h.startsWith("tel:")) mailtoTel.add(h.split("?")[0]);
      else if (h.startsWith("http")) external.set(h, p);
      else throw new Error(`Unexpected link "${h}" on ${p}`);
    }
  }

  // Internal links: open each and check it's a real page (and the section exists)
  const broken: string[] = [];
  for (const h of [...internal].sort()) {
    if (h === "#main" || h === "#top") continue;
    await page.goto(`/${h}`);
    await page.waitForTimeout(150);
    const isNotFound = await page.locator("h1", { hasText: "nowhere" }).count();
    if (isNotFound) { broken.push(`${h} → 404`); continue; }
    const m = h.match(/^#\/[^/?]+\/([^?]+)/);
    if (m && !h.startsWith("#/updates/")) {
      const exists = await page.locator(`[id="${decodeURIComponent(m[1])}"]`).count();
      if (!exists) broken.push(`${h} → section #${m[1]} missing`);
    }
    if (h.startsWith("#/updates/")) {
      if (await page.getByText("Update not found").count()) broken.push(`${h} → post not found`);
    }
  }
  expect(broken, "broken internal links").toEqual([]);

  // Contact links
  expect([...mailtoTel].sort()).toEqual(["mailto:", "mailto:havenfund@hotmail.com", "tel:+13154945538"].filter((x) => [...mailtoTel].includes(x)));
  for (const m of mailtoTel) expect(["mailto:havenfund@hotmail.com", "tel:+13154945538", "mailto:"]).toContain(m);

  // Every external link must be HTTPS
  for (const u of external.keys()) expect(u, `insecure link on ${external.get(u)}`).toMatch(/^https:\/\//);

  mkdirSync("test-results", { recursive: true });
  writeFileSync("test-results/links.json", JSON.stringify({ internal: [...internal].sort(), external: Object.fromEntries(external), contact: [...mailtoTel] }, null, 2));
  info.attach("links", { body: `${internal.size} internal, ${external.size} external, ${mailtoTel.size} contact`, contentType: "text/plain" });
});

test("legacy links from the old one-page site redirect correctly", async ({ page }) => {
  await presetConsent(page);
  for (const [old, h1] of [["#donate", /Give in minutes/], ["#faq", /about hope/], ["#transparency", /real needs/], ["#mission", /Technology with/]] as const) {
    await page.goto(`/${old}`);
    await expect(page.locator("h1")).toHaveText(h1);
  }
});
