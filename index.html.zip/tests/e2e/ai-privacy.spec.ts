import { test, expect } from "@playwright/test";
import { presetConsent, trackErrors } from "./helpers";

test.describe("Privacy controls", () => {
  test("first visit shows the privacy notice; choice is remembered", async ({ page }) => {
    const errors = trackErrors(page);
    await page.goto("/#/");
    const banner = page.getByRole("region", { name: "Privacy choices" });
    await expect(banner).toBeVisible();
    await banner.getByRole("button", { name: "Essential only" }).click();
    await expect(banner).toHaveCount(0);
    await page.reload();
    await expect(page.locator("h1")).toBeVisible();
    await expect(page.getByRole("region", { name: "Privacy choices" })).toHaveCount(0);
    expect(errors).toEqual([]);
  });

  test("privacy settings can be reopened from the footer and changed", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/contact");
    await page.locator("footer").getByRole("button", { name: "Privacy settings" }).click();
    const dlg = page.getByRole("dialog", { name: "Privacy settings" });
    await expect(dlg).toBeVisible();
    const sw = dlg.getByRole("switch", { name: "Live price estimates" });
    await expect(sw).toHaveAttribute("aria-checked", "false");
    await sw.click();
    await dlg.getByRole("button", { name: "Save choices" }).click();
    await expect(dlg).toHaveCount(0);
    const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("havenfund.consent")!));
    expect(saved.prices).toBe(true);
  });

  test("no cookies are set", async ({ page, context }) => {
    await presetConsent(page, { preferences: true, prices: false, voice: true });
    await page.goto("/#/");
    await page.goto("/#/donate");
    expect(await context.cookies()).toEqual([]);
  });
});

test.describe("Haven AI assistant", () => {
  test("opens from the floating button and answers in English and Spanish", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/");
    await page.getByRole("button", { name: "Ask Haven AI" }).last().click();
    const panel = page.getByRole("dialog", { name: "Haven AI assistant chat" });
    await expect(panel).toBeVisible();
    await panel.getByLabel("Message Haven AI").fill("How do I donate?");
    await panel.getByLabel("Message Haven AI").press("Enter");
    await expect(panel).toContainText("four simple steps");
    await panel.getByLabel("Message Haven AI").fill("¿Dónde están ubicados?");
    await panel.getByRole("button", { name: "Send message" }).click();
    await expect(panel).toContainText("Charter Oak Place");
    // action button navigates
    await panel.getByRole("link", { name: /Contactar al equipo/ }).first().click();
    await expect(page.locator("h1")).toHaveText(/about hope/);
  });

  test("voice button asks permission first", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/");
    await page.getByRole("button", { name: "Ask Haven AI" }).last().click();
    await page.getByRole("button", { name: "Ask with your voice" }).click();
    await expect(page.getByRole("alertdialog", { name: "Allow voice questions?" })).toBeVisible();
  });
});
