import { Clock, MessageCircle } from "lucide-react";
import Contact from "../components/Contact";
import FAQ from "../components/FAQ";
import { PageHero, Section } from "../components/layout";
import { openHavenAI } from "../components/AssistantSection";
import { ORG } from "../config/org";

export default function ContactPage() {
  return (
    <>
      <PageHero eyebrow="Contact Us" title="Let’s talk" accent="about hope." crumb="Contact Us" chips={[ORG.email, ORG.phone, "Hartford, CT", "Facebook"]}>
        Questions about donating, campaigns, transparency or getting involved? We’d love to hear from you.
      </PageHero>

      <Contact showHeading={false} />

      <Section className="py-6 md:py-8">
        <div className="reveal grid gap-4 md:grid-cols-2">
          <div className="glass flex items-start gap-4 rounded-3xl p-6">
            <Clock className="mt-0.5 h-5 w-5 shrink-0 text-hope-300" />
            <div>
              <p className="font-bold text-white">Response times</p>
              <p className="mt-1 text-sm text-slate-400">We aim to reply as soon as possible. For donation issues, include your transaction ID and reference.</p>
            </div>
          </div>
          <button onClick={() => openHavenAI()} className="glass flex items-start gap-4 rounded-3xl p-6 text-left transition hover:border-tech-400/40">
            <MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-tech-300" />
            <div>
              <p className="font-bold text-white">Instant answers, 24/7</p>
              <p className="mt-1 text-sm text-slate-400">Haven AI answers common questions instantly — by text or voice, in 5 languages.</p>
            </div>
          </button>
        </div>
      </Section>

      <FAQ />
    </>
  );
}
