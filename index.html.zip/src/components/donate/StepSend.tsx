import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { AlertTriangle, ArrowLeft, ArrowRight, ExternalLink, Loader2, Share2, Smartphone, Zap } from "lucide-react";
import type { CryptoAsset } from "../../config/wallets";
import { paymentProvider } from "../../services/payments";
import { CryptoIcon } from "../CryptoIcon";
import { CopyButton } from "../ui";
import { GhostBtn, NavRow, PrimaryBtn } from "./controls";
import { cn } from "../../utils/cn";

interface Props {
  asset: CryptoAsset;
  amount?: number;
  usdEstimate?: number;
  onBack: () => void;
  onNext: () => void;
}

export function StepSend({ asset, amount, usdEstimate, onBack, onNext }: Props) {
  const [withAmount, setWithAmount] = useState(true);
  const [ack, setAck] = useState(false);
  const [checkout, setCheckout] = useState<"idle" | "loading" | "error">("idle");
  const isLN = asset.id === "LN";

  const canEmbedAmount = Boolean(asset.buildUri && amount);
  const qrValue = asset.buildUri && withAmount ? asset.buildUri(asset.address, amount) : asset.address;
  const walletLink = asset.buildUri ? asset.buildUri(asset.address, withAmount ? amount : undefined) : isLN ? `lightning:${asset.address}` : null;
  const amountStr = amount !== undefined ? amount.toLocaleString("en-US", { maximumFractionDigits: asset.decimals, useGrouping: false }) : undefined;

  const head = asset.address.slice(0, 6);
  const tail = asset.address.slice(-6);
  const mid = asset.address.slice(6, -6);

  const share = async () => {
    try {
      await navigator.share({ title: `Donate ${asset.name}`, text: `${asset.name} donation address (${asset.network}): ${asset.address}` });
    } catch {
      /* user cancelled */
    }
  };

  const hosted = async () => {
    if (!paymentProvider.createCheckout) return;
    setCheckout("loading");
    try {
      const { checkoutUrl } = await paymentProvider.createCheckout({ assetId: asset.id, amount, usdEstimate });
      const url = new URL(checkoutUrl);
      if (url.protocol !== "https:") throw new Error("Insecure checkout URL");
      window.location.assign(url.toString());
    } catch {
      setCheckout("error");
    }
  };

  const steps = isLN
    ? [
        "Open a Lightning wallet that supports BOLT12 offers (for example Phoenix).",
        "Tap Send / Scan and scan the QR code — or copy the offer and paste it.",
        amountStr ? `Enter ${amountStr} sats as the amount.` : "Enter the amount you’d like to give.",
        "Confirm the payment. Lightning payments usually settle within seconds.",
      ]
    : [
        `Open your wallet or exchange and choose Send / Withdraw for ${asset.symbol}.`,
        `Select the network: ${asset.network}.`,
        "Scan the QR code or paste the copied address. Check the first and last 6 characters.",
        amountStr ? `Enter ${amountStr} ${asset.unit}, review the network fee, and confirm.` : "Enter your amount, review the network fee, and confirm.",
      ];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3">
        <CryptoIcon id={asset.id} size={40} />
        <div className="mr-auto">
          <h3 className="text-xl font-bold text-white">Send {asset.name}</h3>
          <p className="text-sm text-slate-400">Scan with your wallet or copy the {isLN ? "offer" : "address"} below.</p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-tech-400/30 bg-tech-400/10 px-3 py-1.5 text-xs font-bold text-tech-200">
          <span className="h-1.5 w-1.5 rounded-full bg-tech-300" />
          {asset.network}
        </span>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-[auto_1fr]">
        {/* QR */}
        <div className="mx-auto flex flex-col items-center">
          <div data-qr-zone className="relative rounded-[1.75rem] bg-white p-4 shadow-[0_30px_80px_-30px_rgba(245,180,60,0.5)]">
            <QRCodeSVG
              value={qrValue}
              size={isLN ? 250 : 220}
              level={isLN ? "L" : "H"}
              bgColor="#ffffff"
              fgColor="#05060f"
              marginSize={0}
              title={`QR code for ${asset.name} ${isLN ? "offer" : "address"}`}
            />
            {!isLN && (
              <span className="absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-xl bg-white shadow">
                <CryptoIcon id={asset.id} size={36} />
              </span>
            )}
          </div>
          {canEmbedAmount && (
            <label className="mt-4 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-400">
              <input type="checkbox" checked={withAmount} onChange={(e) => setWithAmount(e.target.checked)} className="h-4 w-4 accent-amber-400" />
              Include amount in QR code
            </label>
          )}
        </div>

        {/* Address + details */}
        <div className="min-w-0 space-y-4">
          <div className="rounded-2xl border border-white/10 bg-ink-900/70 p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {isLN ? "Lightning offer (BOLT12)" : `${asset.symbol} address`}
              </p>
              <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-300">Format verified</span>
            </div>
            <p className={cn("mono-break mt-2 font-mono leading-relaxed text-slate-300", isLN ? "max-h-28 overflow-y-auto pr-1 text-[11px]" : "text-sm sm:text-[15px]")}>
              <span className="font-semibold text-hope-300">{head}</span>
              {mid}
              <span className="font-semibold text-hope-300">{tail}</span>
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <CopyButton text={asset.address} label={isLN ? "Copy offer" : "Copy address"} />
              {typeof navigator !== "undefined" && "share" in navigator && (
                <button onClick={share} className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 text-sm font-semibold text-white transition hover:bg-white/10">
                  <Share2 className="h-4 w-4" /> Share
                </button>
              )}
              {walletLink && (
                <a href={walletLink} className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 text-sm font-semibold text-white transition hover:bg-white/10 md:hidden">
                  <Smartphone className="h-4 w-4" /> Open wallet
                </a>
              )}
            </div>
          </div>

          {amountStr && (
            <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-ink-900/70 p-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Amount to send</p>
                <p className="mt-1 text-lg font-bold text-white">
                  {amountStr} <span className="text-slate-400">{asset.unit}</span>
                </p>
                {usdEstimate !== undefined && <p className="text-xs text-slate-500">≈ ${usdEstimate.toFixed(2)} USD estimate</p>}
              </div>
              <CopyButton text={amountStr} compact label="Copy amount" />
            </div>
          )}

          <div className="space-y-2">
            {asset.warnings.map((w) => (
              <p key={w} className="flex gap-2.5 rounded-2xl border border-amber-300/25 bg-amber-300/[0.06] p-3.5 text-sm text-amber-100">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
                {w}
              </p>
            ))}
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-6 rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <p className="flex items-center gap-2 text-sm font-bold text-white">
          {isLN ? <Zap className="h-4 w-4 text-hope-300" /> : <Smartphone className="h-4 w-4 text-hope-300" />}
          Step-by-step instructions
        </p>
        <ol className="mt-4 grid gap-3 sm:grid-cols-2">
          {steps.map((s, i) => (
            <li key={s} className="flex gap-3 text-sm text-slate-300">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-hope-400/15 text-xs font-bold text-hope-300">{i + 1}</span>
              {s}
            </li>
          ))}
        </ol>
        <p className="mt-4 text-xs text-slate-500">{asset.feeNote}</p>
        {asset.explorerAddress && (
          <a href={asset.explorerAddress(asset.address)} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-tech-300 hover:underline">
            Verify this address on a public block explorer <ExternalLink className="h-3 w-3" />
          </a>
        )}
      </div>

      {paymentProvider.hosted && (
        <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-sm">
          <p className="text-slate-300">Prefer a guided checkout? Use our hosted payment provider.</p>
          <GhostBtn className="mt-3" onClick={hosted} disabled={checkout === "loading"}>
            {checkout === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <ExternalLink className="h-4 w-4" />} Hosted checkout
          </GhostBtn>
          {checkout === "error" && <p className="mt-2 text-rose-300">Checkout is unavailable right now. You can still donate directly using the address above.</p>}
        </div>
      )}

      <label className="mt-6 flex cursor-pointer items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-sm text-slate-300">
        <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-0.5 h-4 w-4 shrink-0 accent-amber-400" />
        <span>
          I confirm I’m sending <strong className="text-white">{asset.symbol}</strong> on the <strong className="text-white">{asset.network}</strong> network and have checked the {isLN ? "offer" : "address"}.
        </span>
      </label>

      <NavRow>
        <GhostBtn onClick={onBack}>
          <ArrowLeft className="h-4 w-4" /> Back
        </GhostBtn>
        <PrimaryBtn disabled={!ack} onClick={onNext}>
          I’ve sent my donation <ArrowRight className="h-4 w-4" />
        </PrimaryBtn>
      </NavRow>
    </div>
  );
}
