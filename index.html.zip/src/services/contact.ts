import { secureFetch } from "./http";
import { sendEmail, emailEnabled } from "./email";

export interface ContactPayload {
  name: string;
  email: string;
  topic: string;
  message: string;
}

const ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT;

export const contactConfigured = Boolean(ENDPOINT) || emailEnabled;

/**
 * Delivery order: custom backend (VITE_CONTACT_ENDPOINT) → email provider → demo.
 * Throws EmailNotActivatedError / EmailError so the UI can offer a mailto fallback.
 */
export async function sendContact(payload: ContactPayload): Promise<{ mode: "sent" | "demo" }> {
  if (ENDPOINT) {
    const res = await secureFetch(ENDPOINT, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`Message could not be sent (${res.status}). Please try again.`);
    return { mode: "sent" };
  }
  if (emailEnabled) {
    await sendEmail({
      subject: `Haven Fund website — ${payload.topic} — from ${payload.name}`,
      replyTo: payload.email,
      fields: { Name: payload.name, Email: payload.email, Topic: payload.topic, Message: payload.message, Page: "Contact form" },
    });
    return { mode: "sent" };
  }
  await new Promise((r) => setTimeout(r, 900));
  return { mode: "demo" };
}
