/**
 * Haven AI — multilingual humanitarian assistant.
 * ------------------------------------------------------------------
 * Two modes:
 *  1. REMOTE: if VITE_AI_ENDPOINT is set, the conversation is POSTed to
 *     your backend proxy (which holds the AI provider key) together with
 *     SYSTEM_PROMPT and the preferred language.
 *     Request:  { system, language, messages: [{role, content}] }
 *     Response: { reply: string }
 *  2. LOCAL (default): a deterministic, grounded multilingual knowledge
 *     base that only answers from verified site content. It cannot invent
 *     facts, statistics, beneficiaries, projects or financial information.
 */
import { secureFetch } from "../http";
import { ASSETS } from "../../config/wallets";
import { CAMPAIGNS } from "../../config/campaigns";
import { ORG } from "../../config/org";
import { ACTION, LANGS, detectLang, type Lang } from "./i18n";
import { CAMPAIGN_SHORT, CAMPAIGN_TEMPLATE, COIN_TEMPLATE, FALLBACK, INTENTS } from "./knowledge";

export * from "./i18n";

export type Role = "user" | "assistant";
export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  lang?: Lang;
  actions?: { label: string; href: string }[];
  error?: boolean;
  viaVoice?: boolean;
}
export type Reply = Pick<ChatMessage, "content" | "actions" | "lang">;

export const SYSTEM_PROMPT = `You are Haven AI, the AI assistant for ${ORG.name}, a cryptocurrency-only donation platform supporting street children and homeless people ("${ORG.tagline}").
Rules:
- You are an AI. Never claim or imply you are a human. If asked, say clearly you are an AI assistant.
- Reply in the same language the user writes or speaks in (supported: ${LANGS.map((l) => l.label).join(", ")}). If a preferred language is supplied, use it.
- Never invent donation statistics, totals, beneficiary numbers, names, stories, projects, partnerships, certifications, registration numbers or financial information. If information is not published, say so and suggest contacting the team.
- Campaigns (focus areas, no published targets or totals): ${CAMPAIGNS.map((c) => `${c.name} — ${c.short}: ${c.intendedUse.join(", ")}`).join("; ")}. All campaigns share the same wallets; the donor's preference is recorded with their reference.
- Donations are intended to provide food, shelter, clothing, education and essential support.
- Supported donations: ${ASSETS.map((a) => `${a.name} (${a.symbol}) on ${a.network}`).join("; ")}.
- Always remind donors to match the asset AND network exactly and to verify the address. Crypto transactions are irreversible.
- Never ask for seed phrases, private keys or passwords. No financial, tax or legal advice.
- Contact: ${ORG.email}, ${ORG.phone}, ${ORG.address}, Facebook ${ORG.facebook}.
- Security: HTTPS, security headers, wallet address format checks, no card data, no tracking cookies; privacy settings in the footer. Haven Fund never DMs wallet addresses or asks for seed phrases. Security page: #/security.
- Site pages (hash routes): Home (#/), About Us (#/about), Campaigns (#/campaigns), Donate (#/donate), How Donations Help incl. official wallets & transparency (#/how-donations-help), Updates & News (#/updates), Contact Us incl. FAQ (#/contact), Privacy Policy (#/privacy), Terms & Conditions (#/terms), Security & Trust (#/security).
- Keep answers short, warm, clear and beginner-friendly.`;

const REMOTE = import.meta.env.VITE_AI_ENDPOINT;
export const aiMode: "remote" | "local" = REMOTE ? "remote" : "local";

const norm = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/[^\p{L}\p{N}\s'&-]/gu, " ")
    .replace(/\s+/g, " ");

const isArabic = (s: string) => /[\u0600-\u06FF]/.test(s);

function matchKey(q: string, key: string) {
  const k = norm(key).trim();
  if (!k) return false;
  if (isArabic(k)) return q.includes(k);
  if (k.length <= 3) return q.includes(` ${k} `);
  return q.includes(` ${k}`);
}

function localAnswer(text: string, preferred: Lang | "auto"): Reply {
  const q = ` ${norm(text)} `;
  const langScore: Record<Lang, number> = { en: 0, es: 0, fr: 0, pt: 0, ar: 0 };
  let best: (typeof INTENTS)[number] | null = null;
  let bestScore = 0;

  for (const intent of INTENTS) {
    let score = 0;
    (Object.keys(intent.keys) as Lang[]).forEach((l) => {
      for (const k of intent.keys[l]) {
        if (matchKey(q, k)) {
          const w = k.split(" ").length * 2;
          score += w;
          langScore[l] += w;
        }
      }
    });
    if (score > bestScore) {
      best = intent;
      bestScore = score;
    }
  }

  const keywordLang = (Object.entries(langScore).sort((a, b) => b[1] - a[1])[0][1] > 0
    ? (Object.entries(langScore).sort((a, b) => b[1] - a[1])[0][0] as Lang)
    : null);
  const lang: Lang = preferred !== "auto" ? preferred : detectLang(text) ?? keywordLang ?? "en";

  const resolveActions = (acts?: { key: string; href: string }[]) =>
    acts?.map((a) => ({ label: ACTION[a.key]?.[lang] ?? a.key, href: a.href }));

  // Specific campaign mentioned by name
  const campaign = CAMPAIGNS.find((c) => {
    const full = norm(c.name).trim();
    const noBrand = full.replace(/^haven /, "");
    return q.includes(` ${full}`) || (noBrand !== full && q.includes(` ${noBrand}`)) || q.includes(` ${full.split(" & ")[0]} `);
  });
  if (campaign && bestScore < 6) {
    return {
      lang,
      content: CAMPAIGN_TEMPLATE[lang](campaign.name, CAMPAIGN_SHORT[campaign.id][lang], campaign.intendedUse.map((i) => `• ${i}`).join("\n")),
      actions: resolveActions([{ key: "donate", href: "#donate" }, { key: "campaigns", href: "#campaigns" }]),
    };
  }

  // Specific coin mentioned
  const coin = ASSETS.find((a) => a.id !== "LN" && (q.includes(` ${a.name.toLowerCase()} `) || q.includes(` ${a.id.toLowerCase()} `)));
  if (coin && bestScore < 3) {
    return {
      lang,
      content: COIN_TEMPLATE[lang](coin.name, coin.symbol, coin.network),
      actions: resolveActions([{ key: "donate", href: "#donate" }]),
    };
  }

  if (best) {
    const content = typeof best.text === "function" ? best.text(lang) : best.text[lang];
    return { lang, content, actions: resolveActions(best.actions) };
  }
  return { lang, content: FALLBACK[lang], actions: resolveActions([{ key: "contact", href: "#contact" }]) };
}

export async function askHavenAI(history: ChatMessage[], preferred: Lang | "auto", signal?: AbortSignal): Promise<Reply> {
  const last = history[history.length - 1];
  if (REMOTE) {
    const language = preferred === "auto" ? detectLang(last.content) ?? "auto" : preferred;
    const res = await secureFetch(REMOTE, {
      method: "POST",
      signal,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        system: SYSTEM_PROMPT,
        language,
        messages: history.filter((m) => !m.error).map(({ role, content }) => ({ role, content })),
      }),
    });
    if (!res.ok) throw new Error(`Assistant unavailable (${res.status})`);
    const data = (await res.json()) as { reply?: string };
    if (!data.reply) throw new Error("Empty response from assistant");
    return { content: data.reply, lang: language === "auto" ? undefined : language };
  }
  // Local mode: simulate natural latency
  await new Promise((r) => setTimeout(r, 400 + Math.random() * 450));
  if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
  return localAnswer(last.content, preferred);
}
