#!/usr/bin/env node
/**
 * Website backup — creates a timestamped, checksummed archive of the site.
 *
 *   node scripts/backup.mjs                 Create backup in ./backups (keeps last 14)
 *   node scripts/backup.mjs --keep 30       Keep the last 30 backups
 *   node scripts/backup.mjs --out /mnt/usb  Write to another folder/drive
 *   node scripts/backup.mjs --verify FILE   Verify an archive against its .sha256
 *
 * Follow the 3-2-1 rule: 3 copies, 2 different media, 1 off-site
 * (e.g. an encrypted cloud drive). Test a restore at least every quarter.
 * Backups contain NO private keys or secrets — never put those in this project.
 */
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const args = process.argv.slice(2);
const opt = (name, def) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? args[i + 1] : def;
};

const hashFile = (file) =>
  new Promise((res, rej) => {
    const h = createHash("sha256");
    createReadStream(file).on("data", (d) => h.update(d)).on("end", () => res(h.digest("hex"))).on("error", rej);
  });

async function verify(file) {
  const sumFile = `${file}.sha256`;
  if (!existsSync(sumFile)) throw new Error(`Missing checksum file ${sumFile}`);
  const expected = readFileSync(sumFile, "utf8").split(/\s+/)[0];
  const actual = await hashFile(file);
  if (expected !== actual) throw new Error(`Checksum mismatch for ${basename(file)} — archive may be corrupted or altered.`);
  execFileSync("tar", ["-tzf", file], { stdio: "ignore" });
  console.log(`✓ ${basename(file)} verified (sha256 ${actual.slice(0, 16)}…) and archive is readable`);
}

async function main() {
  const v = opt("--verify");
  if (v) return verify(resolve(v));

  const outDir = resolve(opt("--out", join(ROOT, "backups")));
  const keep = Math.max(1, Number(opt("--keep", 14)) || 14);
  mkdirSync(outDir, { recursive: true });

  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "-");
  const file = join(outDir, `havenfund-${stamp}.tar.gz`);
  const include = ["src", "public", "scripts", "security", "deploy", "index.html", "package.json", "package-lock.json", "tsconfig.json", "vite.config.ts", "vercel.json", "SECURITY.md", "dist"]
    .filter((p) => existsSync(join(ROOT, p)));

  execFileSync("tar", ["-czf", file, "--exclude=node_modules", "--exclude=.env*", "-C", ROOT, ...include], { stdio: "inherit" });
  const sum = await hashFile(file);
  writeFileSync(`${file}.sha256`, `${sum}  ${basename(file)}\n`);
  const kb = Math.round(statSync(file).size / 1024);
  console.log(`✓ Backup created: ${file} (${kb} KB)`);
  console.log(`  sha256: ${sum}`);

  // Retention
  const archives = readdirSync(outDir).filter((f) => /^havenfund-.*\.tar\.gz$/.test(f)).sort();
  for (const old of archives.slice(0, Math.max(0, archives.length - keep))) {
    rmSync(join(outDir, old), { force: true });
    rmSync(join(outDir, `${old}.sha256`), { force: true });
    console.log(`  removed old backup ${old}`);
  }
  await verify(file);
}

main().catch((e) => {
  console.error(`✗ ${e.message}`);
  process.exit(1);
});
