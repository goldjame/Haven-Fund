import { ArrowRight, Cpu, Eye, HandHeart, Newspaper } from "lucide-react";
import Hero from "../components/Hero";
import Campaigns from "../components/Campaigns";
import { HowItWorks } from "../components/InfoSections";
import AssistantSection from "../components/AssistantSection";
import { USES } from "../components/Transparency";
import { CtaBand, PrimaryLink, Section } from "../components/layout";
import { SectionHeading } from "../components/ui";
import { NewsCard } from "./Updates";
import { NEWS } from "../config/news";
import { to } from "../router";

export default function Home() {
  return (
    <>
      <Hero />

      {/* About teaser */}
      <Section labelledBy="home-about">
        <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
          <div>
            <SectionHeading id="home-about" eyebrow="About Haven Fund" title="Where code meets" accent="compassion." center={false}>
              Haven Fund turns digital value into real-world dignity. We connect modern cryptocurrency technology with humanitarian
              support for street children and homeless people.
            </SectionHeading>
            <a href={to("about")} className="reveal -mt-6 inline-flex items-center gap-2 font-semibold text-hope-300 hover:text-hope-200">
              Read our story <ArrowRight className="h-4 w-4" />
            </a>
          </div>
          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
            {[
              { icon: Cpu, t: "Technology", d: "Borderless giving in minutes.", c: "text-tech-300" },
              { icon: HandHeart, t: "Humanity", d: "A person behind every transaction.", c: "text-hope-300" },
              { icon: Eye, t: "Transparency", d: "Every on-chain address is public.", c: "text-aura-400" },
            ].map((p, i) => (
              <div key={p.t} className="reveal glass rounded-3xl p-6 transition duration-500 hover:-translate-y-1" style={{ transitionDelay: `${i * 80}ms` }}>
                <p.icon className={`h-6 w-6 ${p.c}`} />
                <p className="mt-4 text-lg font-bold text-white">{p.t}</p>
                <p className="mt-1 text-sm text-slate-400">{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Campaigns limit={3} id="home-campaigns" />

      <HowItWorks />
      <div className="reveal -mt-10 mb-10 flex justify-center px-5">
        <PrimaryLink href={to("donate")}>Start your donation</PrimaryLink>
      </div>

      {/* Impact teaser */}
      <Section labelledBy="home-impact">
        <div className="reveal glass-strong relative overflow-hidden rounded-[2.25rem] p-7 md:p-12">
          <div aria-hidden className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-hope-500/15 blur-3xl" />
          <div className="relative grid gap-10 lg:grid-cols-[1fr_1.3fr] lg:items-center">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-hope-300">How Donations Help</p>
              <h2 id="home-impact" className="mt-3 font-display text-4xl leading-tight text-white md:text-5xl">
                From your wallet to <em className="text-gradient italic">real needs.</em>
              </h2>
              <p className="mt-4 text-slate-400">
                See how donations are intended to be used, verify our official wallets on-chain, and read our transparency commitments.
              </p>
              <a href={to("impact")} className="mt-6 inline-flex items-center gap-2 font-semibold text-hope-300 hover:text-hope-200">
                See how donations help <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {USES.map((u) => (
                <li key={u.title} className="rounded-2xl border border-white/5 bg-white/[0.03] p-4">
                  <u.icon className="h-5 w-5 text-hope-300" />
                  <p className="mt-3 text-sm font-semibold text-white">{u.title}</p>
                </li>
              ))}
              <li className="grid place-items-center rounded-2xl border border-dashed border-white/10 p-4 text-center text-xs text-slate-500">
                Verified reports published when available
              </li>
            </ul>
          </div>
        </div>
      </Section>

      {/* Latest updates */}
      <Section labelledBy="home-updates">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div className="reveal">
            <p className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-hope-300">
              <Newspaper className="h-3.5 w-3.5" /> Updates & News
            </p>
            <h2 id="home-updates" className="mt-3 font-display text-4xl text-white md:text-5xl">
              Latest from <em className="text-gradient italic">Haven Fund.</em>
            </h2>
          </div>
          <a href={to("updates")} className="reveal inline-flex items-center gap-2 font-semibold text-hope-300 hover:text-hope-200">
            All updates <ArrowRight className="h-4 w-4" />
          </a>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {NEWS.slice(0, 3).map((n) => (
            <NewsCard key={n.slug} post={n} />
          ))}
        </div>
      </Section>

      <AssistantSection />
      <CtaBand />
    </>
  );
}
