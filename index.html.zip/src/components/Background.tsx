import { useEffect, useRef } from "react";

/**
 * Immersive, GPU-friendly canvas background:
 *  - drifting "hope" particles connected by faint network lines (technology)
 *  - warm glowing embers (humanity)
 *  - subtle floating crypto glyphs
 * Automatically pauses when the tab is hidden and respects reduced motion.
 */
const GLYPHS = ["₿", "Ξ", "◎", "₮", "Ł", "⚡", "$"];

export default function Background() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let w = 0, h = 0, dpr = 1, raf = 0, running = true;
    let mx = -9999, my = -9999;

    type P = { x: number; y: number; vx: number; vy: number; r: number; warm: boolean; a: number };
    type G = { x: number; y: number; vy: number; s: number; g: string; a: number; rot: number; vr: number };
    let ps: P[] = [];
    let gs: G[] = [];

    const init = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(90, (w * h) / 16000));
      ps = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.18,
        vy: (Math.random() - 0.5) * 0.18,
        r: Math.random() * 1.6 + 0.4,
        warm: Math.random() < 0.35,
        a: Math.random() * 0.6 + 0.3,
      }));
      const gc = w < 640 ? 7 : 14;
      gs = Array.from({ length: gc }, (_, i) => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vy: -(Math.random() * 0.15 + 0.05),
        s: Math.random() * 18 + 14,
        g: GLYPHS[i % GLYPHS.length],
        a: Math.random() * 0.07 + 0.04,
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.002,
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      // Glyphs
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      for (const g of gs) {
        g.y += g.vy;
        g.rot += g.vr;
        if (g.y < -40) { g.y = h + 40; g.x = Math.random() * w; }
        ctx.save();
        ctx.translate(g.x, g.y);
        ctx.rotate(Math.sin(g.rot) * 0.3);
        ctx.font = `600 ${g.s}px Manrope, sans-serif`;
        ctx.fillStyle = `rgba(252, 211, 77, ${g.a})`;
        ctx.fillText(g.g, 0, 0);
        ctx.restore();
      }
      // Particles + links
      const maxD = 130;
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        // gentle mouse attraction
        const dxm = mx - p.x, dym = my - p.y;
        const dm = Math.hypot(dxm, dym);
        if (dm < 180) { p.x += dxm * 0.0015; p.y += dym * 0.0015; }
        for (let j = i + 1; j < ps.length; j++) {
          const q = ps[j];
          const dx = p.x - q.x, dy = p.y - q.y;
          const d = dx * dx + dy * dy;
          if (d < maxD * maxD) {
            const o = (1 - Math.sqrt(d) / maxD) * 0.14;
            ctx.strokeStyle = p.warm && q.warm ? `rgba(245,180,60,${o})` : `rgba(103,232,249,${o})`;
            ctx.lineWidth = 0.6;
            ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
          }
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.warm ? `rgba(253,230,138,${p.a})` : `rgba(165,243,252,${p.a * 0.8})`;
        ctx.shadowBlur = p.warm ? 12 : 6;
        ctx.shadowColor = p.warm ? "rgba(245,180,60,0.9)" : "rgba(34,211,238,0.7)";
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    };

    const loop = () => {
      if (!running) return;
      draw();
      raf = requestAnimationFrame(loop);
    };

    init();
    if (reduce) draw(); else loop();

    const onResize = () => { init(); if (reduce) draw(); };
    const onMove = (e: PointerEvent) => { mx = e.clientX; my = e.clientY; };
    const onVis = () => {
      running = !document.hidden && !reduce;
      cancelAnimationFrame(raf);
      if (running) loop();
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("visibilitychange", onVis);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onMove);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-950">
      {/* Aurora layers */}
      <div className="absolute -left-40 -top-40 h-[40rem] w-[40rem] rounded-full bg-hope-500/10 blur-[120px] animate-float-slow" />
      <div className="absolute -right-40 top-1/3 h-[36rem] w-[36rem] rounded-full bg-tech-500/10 blur-[130px] animate-float-slow [animation-delay:-5s]" />
      <div className="absolute bottom-[-12rem] left-1/3 h-[34rem] w-[34rem] rounded-full bg-aura-500/10 blur-[140px] animate-float-slow [animation-delay:-9s]" />
      {/* Grid */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
          maskImage: "radial-gradient(ellipse at 50% 30%, black 20%, transparent 70%)",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 30%, black 20%, transparent 70%)",
        }}
      />
      <canvas ref={ref} className="absolute inset-0" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(4,5,13,0.85)_100%)]" />
    </div>
  );
}
