import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
import { ASSETS, AMOUNT, RECEIVED, TX, goToConfirmStep, mockChains, mockEmail, presetConsent, readQr, trackErrors } from "./helpers";

test.describe("Donate buttons lead to the donation panel", () => {
  const entries = [
    { from: "/#/", name: "Donate With Crypto", scope: "main" },
    { from: "/#/about", name: "Donate With Crypto", scope: "main" },
    { from: "/#/campaigns", name: "Donate to this campaign", scope: "main" },
    { from: "/#/how-donations-help", name: "Donate With Crypto", scope: "main" },
    { from: "/#/updates", name: "Donate With Crypto", scope: "main" },
  ];
  for (const e of entries) {
    test(`“${e.name}” on ${e.from}`, async ({ page }) => {
      await presetConsent(page);
      await page.goto(e.from);
      await page.locator(e.scope).getByRole(e.name.startsWith("Donate to") ? "button" : "link", { name: e.name }).first().click();
      await expect(page.locator("h1")).toHaveText(/Give in minutes/);
      await expect(page.locator("#donate-panel")).toBeVisible();
    });
  }

  test("header Donate button (and mobile menu Donate)", async ({ page, isMobile }) => {
    await presetConsent(page);
    await page.goto("/#/about");
    if (isMobile) {
      await page.getByRole("button", { name: "Open menu" }).click();
      await page.locator("#mobile-menu").getByRole("link", { name: "Donate With Crypto" }).click();
    } else {
      await page.getByRole("banner").getByRole("link", { name: "Donate", exact: true }).click();
    }
    await expect(page.locator("#donate-panel")).toBeVisible();
  });

  test("campaign card pre-selects its campaign", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/campaigns");
    await page.locator("article", { hasText: "Meals of Hope" }).getByRole("button", { name: "Donate to this campaign" }).click();
    await expect(page.locator("#donate-panel").getByRole("radio", { name: "Meals of Hope" })).toHaveAttribute("aria-checked", "true");
    await expect(page.getByLabel("Donation summary")).toContainText("Meals of Hope");
  });
});

test.describe("Full donation flow — every cryptocurrency", () => {
  for (const asset of ASSETS) {
    test(`${asset.name} (${asset.network}): address, QR, copy, verify, email, receipt`, async ({ page }) => {
      await presetConsent(page);
      const errors = trackErrors(page);
      await mockChains(page, "paid");
      const email = await mockEmail(page, "ok");
      await page.goto("/#/donate?campaign=education");

      const panel = await goToConfirmStep(page, asset);

      // 1) The exact configured address is displayed
      await expect(panel).toContainText(asset.address);
      await expect(panel).toContainText(asset.network);

      // 2) QR code decodes to the right address (what a phone camera reads)
      const qr = await readQr(page);
      expect(qr, "QR code should be readable").not.toBeNull();
      expect(qr!.toLowerCase()).toContain(asset.address.toLowerCase());
      if (asset.id === "BTC") expect(qr).toBe(`bitcoin:${asset.address}?amount=${AMOUNT.BTC}`);
      if (asset.id === "SOL") expect(qr).toBe(`solana:${asset.address}?amount=${AMOUNT.SOL}`);

      // 3) Copy button puts the exact address on the clipboard
      await panel.getByRole("button", { name: /Copy (address|offer) to clipboard/ }).click();
      await expect(panel.getByRole("button", { name: "Copied to clipboard" }).first()).toBeVisible();
      expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(asset.address);

      // 4) Must confirm network before continuing
      const next = panel.getByRole("button", { name: /I’ve sent my donation/ });
      await expect(next).toBeDisabled();
      await panel.getByRole("checkbox", { name: /I confirm I’m sending/ }).check();
      await next.click();

      // 5) Verify on blockchain
      await panel.locator("#txhash").fill(TX[asset.id]);
      if (asset.id !== "LN") {
        await panel.getByRole("button", { name: "Verify on blockchain" }).click();
        const status = panel.getByTestId("verify-status");
        await expect(status).toHaveAttribute("data-status", "confirmed");
        await expect(panel.getByTestId("verify-amount")).toContainText(String(RECEIVED[asset.id]));
      } else {
        await expect(panel.getByRole("button", { name: "Verify on blockchain" })).toHaveCount(0);
      }

      // 6) Email receipt + team notification
      await panel.getByRole("checkbox", { name: /Email me a copy/ }).check();
      await panel.getByLabel("Your email").fill("donor@example.com");
      await panel.getByRole("button", { name: "Complete donation" }).click();

      // 7) Confirmation screen
      const done = page.getByTestId("donation-complete");
      await expect(done).toBeVisible();
      const ref = await done.getByTestId("reference").innerText();
      expect(ref).toMatch(/^HF-\d{8}-[0-9A-F]{8}$/);
      await expect(done.getByTestId("complete-title")).toHaveText(asset.id === "LN" ? /Thank you for giving hope/ : /Donation confirmed/);
      await expect(done).toContainText("Future Minds");
      await expect(done.getByTestId("email-status")).toHaveAttribute("data-status", "sent");
      await expect(done.getByTestId("email-status")).toContainText("donor@example.com");

      // Email request contents
      expect(email.requests).toHaveLength(1);
      const sent = email.requests[0];
      expect(sent.url).toBe("https://formsubmit.co/ajax/havenfund%40hotmail.com");
      expect(sent.body._cc).toBe("donor@example.com");
      expect(sent.body._replyto).toBe("donor@example.com");
      expect(sent.body._subject).toContain(ref);
      expect(sent.body.Reference).toBe(ref);
      expect(sent.body["Transaction ID"]).toBe(TX[asset.id]);
      expect(sent.body.Receipt).toContain(asset.name);
      expect(sent.referer, "FormSubmit needs the site origin as referrer").toMatch(/^http:\/\/localhost:4173\/?$/);

      // 8) Receipt download
      const [dl] = await Promise.all([page.waitForEvent("download"), done.getByTestId("download-receipt").click()]);
      expect(dl.suggestedFilename()).toBe(`HavenFund-receipt-${ref}.html`);
      const html = readFileSync((await dl.path())!, "utf8");
      expect(html).toContain(ref);
      expect(html).toContain(asset.network);
      expect(html).toContain("23 Charter Oak Place #4, Hartford, CT 06106");
      expect(html).toContain("not a tax receipt");
      if (asset.id !== "LN") expect(html).toContain("Confirmed on the blockchain");

      // 9) Mailto receipt link is well-formed
      const mailto = await done.getByTestId("email-receipt").getAttribute("href");
      expect(mailto).toMatch(/^mailto:donor@example\.com\?subject=/);
      expect(decodeURIComponent(mailto!)).toContain(ref);

      // 10) Start over
      await done.getByRole("button", { name: "Make another donation" }).click();
      await expect(page.locator("#donate-panel").getByText("Which cryptocurrency would you like to give?")).toBeVisible();
      expect(errors).toEqual([]);
    });
  }
});

test.describe("Donation problems are handled clearly", () => {
  test("transaction that pays someone else is flagged", async ({ page }) => {
    await presetConsent(page);
    await mockChains(page, "other");
    await mockEmail(page, "ok");
    await page.goto("/#/donate");
    const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "USDT")!);
    await panel.getByRole("checkbox", { name: /I confirm/ }).check();
    await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
    await panel.locator("#txhash").fill(TX.USDT);
    await panel.getByRole("button", { name: "Verify on blockchain" }).click();
    await expect(panel.getByTestId("verify-status")).toHaveAttribute("data-status", "wrong_recipient");
    await panel.getByRole("button", { name: "Complete donation" }).click();
    await expect(page.getByTestId("complete-title")).toHaveText(/Please check your transaction/);
  });

  test("transaction not found yet", async ({ page }) => {
    await presetConsent(page);
    await mockChains(page, "missing");
    await page.goto("/#/donate");
    const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "BTC")!);
    await panel.getByRole("checkbox", { name: /I confirm/ }).check();
    await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
    await panel.locator("#txhash").fill(TX.BTC);
    await panel.getByRole("button", { name: "Verify on blockchain" }).click();
    await expect(panel.getByTestId("verify-status")).toHaveAttribute("data-status", "not_found");
    await expect(panel.getByTestId("verify-status")).toContainText("wait a minute");
  });

  test("blockchain service down → donor can still finish", async ({ page }) => {
    await presetConsent(page);
    await page.route("https://ethereum-rpc.publicnode.com/**", (r) => r.abort("failed"));
    await mockEmail(page, "ok");
    await page.goto("/#/donate");
    const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "ETH")!);
    await panel.getByRole("checkbox", { name: /I confirm/ }).check();
    await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
    await panel.locator("#txhash").fill(TX.ETH);
    await panel.getByRole("button", { name: "Verify on blockchain" }).click();
    await expect(panel.getByTestId("verify-status")).toHaveAttribute("data-status", "error");
    await panel.getByRole("button", { name: "Complete donation" }).click();
    await expect(page.getByTestId("donation-complete")).toBeVisible();
  });

  test("email service not activated → donation still completes with fallbacks", async ({ page }) => {
    await presetConsent(page);
    await mockEmail(page, "activation");
    await page.goto("/#/donate");
    const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "LTC")!);
    await panel.getByRole("checkbox", { name: /I confirm/ }).check();
    await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
    await panel.getByRole("button", { name: "Complete donation" }).click();
    const done = page.getByTestId("donation-complete");
    await expect(done.getByTestId("email-status")).toHaveAttribute("data-status", "failed");
    await expect(done.getByTestId("download-receipt")).toBeVisible();
    await expect(done.getByTestId("email-receipt")).toHaveAttribute("href", /^mailto:/);
  });

  test("invalid transaction ID and email are rejected", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/donate");
    const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "ETH")!);
    await panel.getByRole("checkbox", { name: /I confirm/ }).check();
    await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
    await panel.locator("#txhash").fill("not-a-real-hash");
    await panel.locator("#txhash").blur();
    await expect(panel.getByText(/doesn’t look like a valid Ethereum Mainnet transaction ID/)).toBeVisible();
    await expect(panel.getByRole("button", { name: "Verify on blockchain" })).toBeDisabled();
    await panel.locator("#txhash").fill("");
    await panel.getByRole("checkbox", { name: /Email me a copy/ }).check();
    await panel.getByLabel("Your email").fill("nope@");
    await panel.getByRole("button", { name: "Complete donation" }).click();
    await expect(panel.getByText("Please enter a valid email address.")).toBeVisible();
    await expect(page.getByTestId("donation-complete")).toHaveCount(0);
  });

  test("amount validation", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/donate");
    const panel = page.locator("#donate-panel");
    await panel.getByRole("radio").filter({ hasText: "Lightning" }).click();
    await panel.getByRole("button", { name: /Continue with/ }).click();
    await panel.getByLabel(/Amount in sats/).fill("10.5");
    await expect(panel.getByText("sats must be a whole number.")).toBeVisible();
    await expect(panel.getByRole("button", { name: "Show wallet address" })).toBeDisabled();
    await panel.getByLabel(/Amount in sats/).fill("-3");
    await expect(panel.getByText(/numbers only|greater than zero/)).toBeVisible();
  });

  test("live USD estimates (when allowed) convert correctly", async ({ page }) => {
    await presetConsent(page, { prices: true });
    await page.route("https://api.coingecko.com/**", (r) => r.fulfill({ json: { bitcoin: { usd: 100000 }, ethereum: { usd: 2500 }, tether: { usd: 1 }, "usd-coin": { usd: 1 }, solana: { usd: 100 }, litecoin: { usd: 50 } } }));
    await page.goto("/#/donate");
    const panel = page.locator("#donate-panel");
    await panel.getByRole("radio").filter({ hasText: "Bitcoin (on-chain)" }).click();
    await panel.getByRole("button", { name: /Continue with BTC/ }).click();
    await panel.getByRole("button", { name: "$100", exact: true }).click();
    await expect(panel).toContainText("0.001 BTC");
  });
});
