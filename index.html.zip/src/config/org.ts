/**
 * Organization information.
 * ------------------------------------------------------------------
 * Values wrapped in [square brackets] are PLACEHOLDERS.
 * Replace them with real, verifiable information before launch.
 * The website intentionally never invents registration numbers,
 * addresses, partners, statistics or testimonials.
 */

export const ORG = {
  name: "Haven Fund",
  tagline: "Technology With Humanity",
  legalName: "[Registered organization name — to be provided]",
  registration: "[Registration / charity number — to be provided]",
  jurisdiction: "[Country / jurisdiction of registration — to be provided]",
  address: "23 Charter Oak Place #4, Hartford, CT 06106",
  addressParts: { street: "23 Charter Oak Place #4", city: "Hartford", region: "CT", postalCode: "06106", country: "US" },
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=23+Charter+Oak+Place+%234%2C+Hartford%2C+CT+06106",
  email: "havenfund@hotmail.com",
  emailHref: "mailto:havenfund@hotmail.com",
  phone: "+1 315 494 5538",
  phoneHref: "tel:+13154945538",
  facebook: "https://www.facebook.com/share/1DZA9K4PpQ/",
  founded: "[Year founded — to be provided]",
  reportsUrl: "", // Link to published financial / impact reports once available
  lastUpdated: "2026",
};

export const isPlaceholder = (v: string) => v.startsWith("[") && v.endsWith("]");
