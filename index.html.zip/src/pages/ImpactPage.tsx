import { Wallet, Eye, Layers, PackageCheck, FileBarChart, AlertCircle } from "lucide-react";
import Stories from "../components/Stories";
import { ImpactReports, IntendedUse, Policies, WalletRegistry } from "../components/Transparency";
import { CtaBand, GhostLink, PageHero, PrimaryLink, Section } from "../components/layout";
import { SectionHeading } from "../components/ui";
import { to } from "../router";

const JOURNEY = [
  { icon: Wallet, t: "You donate", d: "You send crypto from your wallet to an official Haven Fund address, choosing a campaign if you wish." },
  { icon: Eye, t: "Publicly visible", d: "On-chain donations are recorded on a public blockchain and can be viewed by anyone on a block explorer." },
  { icon: Layers, t: "Allocated to needs", d: "Funds are intended to be allocated to the areas of need, guided by donors’ campaign preferences." },
  { icon: PackageCheck, t: "Essentials provided", d: "Support is intended to cover food, shelter, clothing, education and essential care." },
  { icon: FileBarChart, t: "Reported honestly", d: "Verified reports will be published here — never estimated or invented figures." },
];

export default function ImpactPage() {
  return (
    <>
      <PageHero
        eyebrow="How Donations Help"
        title="From your wallet to"
        accent="real needs."
        crumb="How Donations Help"
        actions={
          <>
            <PrimaryLink href={to("donate")}>Donate With Crypto</PrimaryLink>
            <GhostLink href={to("impact", "transparency")}>Verify our wallets</GhostLink>
          </>
        }
      >
        Understand how your crypto donation is intended to be used, verify our official wallets on-chain, and read our transparency commitments.
      </PageHero>

      {/* Journey */}
      <Section className="pt-0" labelledBy="journey-title">
        <SectionHeading id="journey-title" eyebrow="The journey of a donation" title="Five steps," accent="fully in the open.">
          This describes the intended process. Operational details will be published as they are verified.
        </SectionHeading>
        <ol className="relative grid gap-4 lg:grid-cols-5">
          <div aria-hidden className="absolute left-0 right-0 top-9 hidden h-px bg-gradient-to-r from-hope-400/0 via-hope-400/40 to-tech-400/0 lg:block" />
          {JOURNEY.map((j, i) => (
            <li key={j.t} className="reveal glass relative rounded-3xl p-6" style={{ transitionDelay: `${i * 90}ms` }}>
              <div className="flex items-center justify-between">
                <span className="relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-hope-400/25 to-tech-400/10 text-hope-200 ring-1 ring-white/10">
                  <j.icon className="h-5 w-5" />
                </span>
                <span className="font-display text-4xl text-white/10">0{i + 1}</span>
              </div>
              <h3 className="mt-5 font-bold text-white">{j.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{j.d}</p>
            </li>
          ))}
        </ol>
      </Section>

      {/* Intended use + reports */}
      <Section labelledBy="use-title">
        <SectionHeading id="use-title" eyebrow="Where your gift goes" title="Intended use" accent="of donations.">
          Donations are intended to support the following areas of need.
        </SectionHeading>
        <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <IntendedUse />
          <ImpactReports />
        </div>
        <p className="reveal mt-6 flex items-start gap-2 rounded-2xl border border-white/5 bg-white/[0.02] p-4 text-sm text-slate-400">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
          We deliberately don’t show “$X provides Y meals” examples. Cost-per-item figures will only be published once they are verified.
        </p>
      </Section>

      {/* Transparency */}
      <Section id="transparency" labelledBy="transparency-title">
        <SectionHeading id="transparency-title" eyebrow="Transparency" title="Radical openness," accent="by design.">
          Every on-chain donation address is published here so anyone can independently view incoming transactions.
        </SectionHeading>
        <WalletRegistry />
        <div className="mt-6"><Policies /></div>
      </Section>

      <Stories />

      <CtaBand title="Your kindness, verifiable." />
    </>
  );
}
