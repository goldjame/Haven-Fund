/**
 * Hardened fetch wrapper used by every network call on the site.
 *  - HTTPS only (plain http is allowed for localhost during development)
 *  - request timeout
 *  - no cookies / credentials are ever sent to third parties
 *  - no referrer leakage (callers may opt into sending only the site origin)
 */
export class SecurityError extends Error {}

const LOCAL = /^(localhost|127\.0\.0\.1|\[::1\])$/;

export function assertSecureUrl(raw: string): URL {
  const url = new URL(raw, window.location.origin);
  if (url.protocol === "https:") return url;
  if (url.protocol === "http:" && LOCAL.test(url.hostname)) return url;
  throw new SecurityError(`Blocked insecure request to ${url.origin}. Only HTTPS endpoints are allowed.`);
}

export async function secureFetch(
  raw: string,
  init: RequestInit = {},
  { timeoutMs = 15000 }: { timeoutMs?: number } = {}
): Promise<Response> {
  const url = assertSecureUrl(raw);
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(new DOMException("Request timed out", "TimeoutError")), timeoutMs);
  const outer = init.signal;
  const onAbort = () => ctrl.abort(outer?.reason);
  if (outer) {
    if (outer.aborted) ctrl.abort(outer.reason);
    else outer.addEventListener("abort", onAbort, { once: true });
  }
  try {
    return await fetch(url.toString(), {
      ...init,
      signal: ctrl.signal,
      credentials: url.origin === window.location.origin ? "same-origin" : "omit",
      referrerPolicy: init.referrerPolicy ?? "no-referrer",
      mode: "cors",
      cache: init.cache ?? "no-store",
    });
  } finally {
    window.clearTimeout(timer);
    outer?.removeEventListener("abort", onAbort);
  }
}

/** Random, unguessable id (used for idempotency keys). */
export function randomId() {
  const c: Crypto = globalThis.crypto;
  if (typeof c.randomUUID === "function") return c.randomUUID();
  const b = new Uint8Array(16);
  c.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}
