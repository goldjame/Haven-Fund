/**
 * Payment / on-ramp provider abstraction.
 * ------------------------------------------------------------------
 * DEFAULT: direct wallet donations — the donor sends crypto from their own
 * wallet to a published address. No card data, no accounts, nothing custodial
 * touches this website.
 *
 * HOSTED CHECKOUT (optional): set VITE_PAYMENT_ENDPOINT to a backend route YOU
 * control that creates a checkout session server-side with your provider
 * (e.g. BTCPay Server, Coinbase Commerce, NOWPayments) and returns
 * { checkoutUrl }. Security rules enforced here:
 *   • provider secret keys NEVER live in this frontend
 *   • the endpoint must be HTTPS
 *   • the returned checkout URL must be HTTPS AND its host must be listed in
 *     VITE_CHECKOUT_ALLOWED_HOSTS (comma-separated) — prevents open redirects
 *   • every request carries an Idempotency-Key to prevent duplicate charges
 *   • payment status must be confirmed server-side via signed provider
 *     webhooks — never trust the browser redirect alone (see SECURITY.md)
 */
import type { AssetId } from "../config/wallets";
import { prefGet, prefSet } from "./consent";
import { SecurityError, randomId, secureFetch } from "./http";

export interface DonationIntent {
  assetId: AssetId;
  /** Donor's campaign preference (see config/campaigns.ts) */
  campaignId?: string;
  amount?: number;
  usdEstimate?: number;
}

export interface DonationRecord extends DonationIntent {
  reference: string;
  txHash?: string;
  createdAt: string;
}

export interface PaymentProvider {
  readonly name: string;
  readonly hosted: boolean;
  createCheckout?(intent: DonationIntent): Promise<{ checkoutUrl: string }>;
  /** Optionally record a donor-submitted tx reference for reconciliation */
  submitReference(record: DonationRecord): Promise<{ ok: boolean; stored: "remote" | "local" | "none" }>;
}

const ENDPOINT = import.meta.env.VITE_PAYMENT_ENDPOINT?.replace(/\/$/, "");
const ALLOWED_HOSTS = (import.meta.env.VITE_CHECKOUT_ALLOWED_HOSTS ?? "")
  .split(",")
  .map((h) => h.trim().toLowerCase())
  .filter(Boolean);

export function makeReference() {
  const bytes = new Uint8Array(4);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  return `HF-${ymd}-${hex}`;
}

/** Validates a checkout URL returned by the backend before redirecting. */
export function validateCheckoutUrl(raw: unknown): URL {
  if (typeof raw !== "string" || raw.length > 2048) throw new SecurityError("Invalid checkout response.");
  const url = new URL(raw);
  if (url.protocol !== "https:") throw new SecurityError("Checkout must use HTTPS.");
  if (url.username || url.password) throw new SecurityError("Invalid checkout URL.");
  const host = url.hostname.toLowerCase();
  const allowed = ALLOWED_HOSTS.some((h) => host === h || host.endsWith(`.${h}`));
  if (!allowed) throw new SecurityError(`Checkout host "${host}" is not on the allow-list.`);
  return url;
}

const directWallet: PaymentProvider = {
  name: "Direct wallet transfer",
  hosted: false,
  async submitReference(record) {
    if (ENDPOINT) {
      const res = await secureFetch(`${ENDPOINT}/references`, {
        method: "POST",
        headers: { "content-type": "application/json", "idempotency-key": record.reference },
        body: JSON.stringify(record),
      });
      if (!res.ok) throw new Error(`Could not save reference (${res.status})`);
      return { ok: true, stored: "remote" };
    }
    // No backend: keep a private copy on this device only — and only with consent.
    const key = "havenfund.donations";
    const before = prefGet("local", key);
    try {
      const prev = JSON.parse(before || "[]") as DonationRecord[];
      prefSet("local", key, JSON.stringify([record, ...prev].slice(0, 20)));
    } catch {
      /* ignore */
    }
    return { ok: true, stored: prefGet("local", key) !== before ? "local" : "none" };
  },
};

const hostedProvider: PaymentProvider = {
  ...directWallet,
  name: "Hosted checkout",
  hosted: true,
  async createCheckout(intent) {
    const res = await secureFetch(
      `${ENDPOINT}/checkout`,
      {
        method: "POST",
        headers: { "content-type": "application/json", "idempotency-key": randomId() },
        body: JSON.stringify(intent),
      },
      { timeoutMs: 20000 }
    );
    if (!res.ok) throw new Error(`Checkout unavailable (${res.status})`);
    const data = (await res.json()) as { checkoutUrl?: unknown };
    return { checkoutUrl: validateCheckoutUrl(data.checkoutUrl).toString() };
  },
};

export const paymentProvider: PaymentProvider = ENDPOINT ? hostedProvider : directWallet;
export const checkoutAllowList = ALLOWED_HOSTS;
