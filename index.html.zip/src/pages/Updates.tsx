import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2, Clock, Info, Link2, Loader2, Mail, Megaphone, BookOpen, ShieldCheck, Target, MapPin, Share2 } from "lucide-react";
import { NEWS, NEWS_CATEGORIES, categoryLabel, getPost, type NewsCategory, type NewsPost } from "../config/news";
import { ORG } from "../config/org";
import { subscribe } from "../services/newsletter";
import { PageHero, Section, CtaBand } from "../components/layout";
import { FacebookIcon } from "../components/ui";
import { openHavenAI } from "../components/AssistantSection";
import { useCopy } from "../hooks";
import { useRoute, to, navigate } from "../router";
import { cn } from "../utils/cn";

const CAT_STYLE: Record<NewsCategory, { icon: typeof Megaphone; cls: string; grad: string }> = {
  announcement: { icon: Megaphone, cls: "text-hope-300 bg-hope-400/15", grad: "from-hope-500/30 via-amber-500/10" },
  campaigns: { icon: Target, cls: "text-emerald-300 bg-emerald-400/15", grad: "from-emerald-500/25 via-tech-500/10" },
  transparency: { icon: ShieldCheck, cls: "text-tech-300 bg-tech-400/15", grad: "from-tech-500/30 via-aura-500/10" },
  guide: { icon: BookOpen, cls: "text-aura-400 bg-aura-400/15", grad: "from-aura-500/30 via-rose-500/10" },
  field: { icon: MapPin, cls: "text-rose-300 bg-rose-400/15", grad: "from-rose-500/25 via-hope-500/10" },
};

const fmtDate = (d?: string) =>
  d ? new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) : null;

function Meta({ post }: { post: NewsPost }) {
  const s = CAT_STYLE[post.category];
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-bold", s.cls)}>
        <s.icon className="h-3 w-3" /> {categoryLabel(post.category)}
      </span>
      <span className="inline-flex items-center gap-1 text-slate-500"><Clock className="h-3 w-3" /> {post.readMinutes} min read</span>
      {fmtDate(post.date) && <span className="text-slate-500">· {fmtDate(post.date)}</span>}
    </div>
  );
}

export function NewsCard({ post, large }: { post: NewsPost; large?: boolean }) {
  const s = CAT_STYLE[post.category];
  return (
    <article className={cn("group relative animate-fade-up overflow-hidden rounded-[1.75rem] border border-white/10 bg-ink-900/60 transition duration-500 hover:-translate-y-1.5 hover:border-white/20", large && "md:grid md:grid-cols-2")}>
      <div className={cn("relative overflow-hidden bg-gradient-to-br to-transparent", s.grad, large ? "min-h-56 md:min-h-full" : "h-40")}>
        <div aria-hidden className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,.35) 1px, transparent 0)", backgroundSize: "18px 18px" }} />
        <s.icon aria-hidden className={cn("absolute bottom-5 right-5 text-white/15 transition duration-700 group-hover:scale-110 group-hover:text-white/25", large ? "h-32 w-32" : "h-20 w-20")} />
        {post.featured && <span className="absolute left-5 top-5 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-ink-950">Featured</span>}
      </div>
      <div className={cn("flex flex-col p-6", large && "md:p-10")}>
        <Meta post={post} />
        <h3 className={cn("mt-4 font-display leading-tight text-white", large ? "text-3xl md:text-4xl" : "text-2xl")}>
          <a href={to("updates", post.slug)} className="after:absolute after:inset-0 focus:outline-none">{post.title}</a>
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-slate-400">{post.excerpt}</p>
        <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-hope-300 transition group-hover:gap-2.5">
          Read more <ArrowRight className="h-4 w-4" />
        </span>
      </div>
    </article>
  );
}

function Subscribe() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "sent" | "demo" | "error">("idle");
  const [err, setErr] = useState("");
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid) {
      setErr("Please enter a valid email address.");
      setState("error");
      return;
    }
    setState("loading");
    try {
      const r = await subscribe(email.trim());
      setState(r.mode);
      setEmail("");
    } catch {
      setErr(`We couldn’t subscribe you automatically. Please email ${ORG.email} with the subject “Subscribe”.`);
      setState("error");
    }
  };

  return (
    <div className="glass-strong border-gradient relative overflow-hidden rounded-[2rem] p-7 md:p-10">
      <div aria-hidden className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-tech-500/20 blur-3xl" />
      <div className="relative grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-center">
        <div>
          <Mail className="h-7 w-7 text-hope-300" />
          <h2 className="mt-4 font-display text-3xl text-white md:text-4xl">Get updates in your inbox</h2>
          <p className="mt-2 text-sm text-slate-400">Campaign news, transparency reports and verified updates — no spam, unsubscribe anytime.</p>
          <a href={ORG.facebook} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#8db8ff] hover:underline">
            <FacebookIcon className="h-4 w-4" /> Or follow Haven Fund on Facebook
          </a>
        </div>
        {state === "sent" || state === "demo" ? (
          <div role="status" className="rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-5 text-sm text-emerald-100">
            <p className="flex items-center gap-2 font-bold"><CheckCircle2 className="h-5 w-5" /> {state === "sent" ? "You’re subscribed. Thank you!" : "Email validated."}</p>
            {state === "demo" && <p className="mt-2 text-emerald-100/80">Demo mode: no newsletter service is connected yet, so your email was not stored. Connect VITE_NEWSLETTER_ENDPOINT to enable sign-ups.</p>}
          </div>
        ) : (
          <form onSubmit={submit} noValidate>
            <label htmlFor="nl-email" className="text-sm font-semibold text-slate-300">Email address</label>
            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              <input
                id="nl-email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); if (state === "error") setState("idle"); }}
                aria-invalid={state === "error"}
                aria-describedby="nl-help"
                placeholder="you@example.com"
                className={cn("flex-1 rounded-2xl border bg-ink-900/60 px-4 py-3.5 text-white outline-none placeholder:text-slate-600 focus:border-hope-400/60", state === "error" ? "border-rose-400/60" : "border-white/10")}
              />
              <button type="submit" disabled={state === "loading"} className="btn-shine inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-3.5 font-bold text-ink-950 disabled:opacity-60">
                {state === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Subscribe
              </button>
            </div>
            <p id="nl-help" className="mt-2 text-xs" aria-live="polite">
              {state === "error" ? <span className="text-rose-300">{err}</span> : <span className="text-slate-500">By subscribing you agree to our <a href={to("privacy")} className="underline">Privacy Policy</a>.</span>}
            </p>
          </form>
        )}
      </div>
    </div>
  );
}

function PostView({ post }: { post: NewsPost }) {
  const { copied, copy } = useCopy();
  const s = CAT_STYLE[post.category];
  const related = NEWS.filter((n) => n.slug !== post.slug && (n.category === post.category || n.featured)).slice(0, 2);
  const url = window.location.href;

  useEffect(() => {
    document.title = `${post.title} — Haven Fund`;
  }, [post]);

  const share = async () => {
    if ("share" in navigator) {
      try { await navigator.share({ title: post.title, text: post.excerpt, url }); } catch { /* cancelled */ }
    } else copy(url);
  };

  return (
    <>
      <header className="relative isolate overflow-hidden pb-10 pt-32 md:pt-40">
        <div aria-hidden className={cn("absolute inset-0 -z-10 bg-gradient-to-b to-transparent opacity-60", s.grad)} />
        <div className="mx-auto max-w-3xl px-5 sm:px-8">
          <a href={to("updates")} className="inline-flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> All updates
          </a>
          <div className="mt-8"><Meta post={post} /></div>
          <h1 className="mt-5 font-display text-4xl leading-[1.05] text-white md:text-6xl">{post.title}</h1>
          <p className="mt-5 text-lg text-slate-300">{post.excerpt}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            <button onClick={share} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10">
              <Share2 className="h-4 w-4" /> Share
            </button>
            <button onClick={() => copy(url)} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10">
              {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-300" /> : <Link2 className="h-4 w-4" />} {copied ? "Link copied" : "Copy link"}
            </button>
          </div>
        </div>
      </header>

      <article className="mx-auto max-w-3xl px-5 pb-16 sm:px-8">
        <div className="glass animate-fade-up space-y-5 rounded-[2rem] p-6 text-[17px] leading-relaxed text-slate-300 md:p-10">
          {post.body.map((b, i) => {
            if (b.type === "h") return <h2 key={i} className="pt-2 text-xl font-bold text-white">{b.text}</h2>;
            if (b.type === "list")
              return (
                <ul key={i} className="space-y-2">
                  {b.items.map((it) => (
                    <li key={it} className="flex gap-3"><span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-hope-400" />{it}</li>
                  ))}
                </ul>
              );
            if (b.type === "note")
              return (
                <p key={i} className="flex gap-3 rounded-2xl border border-amber-300/25 bg-amber-300/[0.06] p-4 text-sm text-amber-100">
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /> {b.text}
                </p>
              );
            return <p key={i}>{b.text}</p>;
          })}
          {post.cta && (
            <div className="pt-4">
              {post.cta.href === "#ask-haven-ai" ? (
                <button onClick={() => openHavenAI()} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-tech-400 to-aura-500 px-6 py-3.5 font-bold text-white">
                  {post.cta.label} <ArrowRight className="h-4 w-4" />
                </button>
              ) : (
                <a href={post.cta.href} className="btn-shine inline-flex items-center gap-2 rounded-2xl px-6 py-3.5 font-bold text-ink-950">
                  {post.cta.label} <ArrowRight className="h-4 w-4" />
                </a>
              )}
            </div>
          )}
        </div>

        {related.length > 0 && (
          <aside className="mt-14" aria-label="Related updates">
            <h2 className="mb-5 text-sm font-bold uppercase tracking-[0.2em] text-slate-500">Keep reading</h2>
            <div className="grid gap-5 md:grid-cols-2">
              {related.map((r) => <NewsCard key={r.slug} post={r} />)}
            </div>
          </aside>
        )}
      </article>
    </>
  );
}

export default function Updates() {
  const route = useRoute();
  const post = getPost(route.param);
  const [cat, setCat] = useState<NewsCategory | "all">("all");

  const list = useMemo(() => NEWS.filter((n) => cat === "all" || n.category === cat), [cat]);
  const featured = cat === "all" ? NEWS.find((n) => n.featured) : undefined;
  const rest = featured ? list.filter((n) => n.slug !== featured.slug) : list;

  if (route.param && !post) {
    return (
      <Section className="pt-40 text-center">
        <h1 className="font-display text-5xl text-white">Update not found</h1>
        <p className="mt-4 text-slate-400">This update may have been moved or removed.</p>
        <button onClick={() => navigate(to("updates"))} className="mt-8 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-semibold text-white">Back to updates</button>
      </Section>
    );
  }
  if (post) return <PostView post={post} />;

  return (
    <>
      <PageHero eyebrow="Updates & News" title="Stories of progress," accent="told honestly." crumb="Updates">
        Announcements, campaign news, transparency updates and beginner guides. We only publish verified information — field updates will
        appear here once confirmed.
      </PageHero>

      <Section className="pt-0">
        <div role="tablist" aria-label="Filter updates" className="mb-8 flex gap-2 overflow-x-auto pb-2">
          {NEWS_CATEGORIES.map((c) => {
            const count = c.id === "all" ? NEWS.length : NEWS.filter((n) => n.category === c.id).length;
            return (
              <button
                key={c.id}
                role="tab"
                aria-selected={cat === c.id}
                onClick={() => setCat(c.id)}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition",
                  cat === c.id ? "border-hope-400/60 bg-hope-400/15 text-hope-100" : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25"
                )}
              >
                {c.label} <span className="ml-1 text-xs opacity-60">{count}</span>
              </button>
            );
          })}
        </div>

        {featured && <div className="mb-6"><NewsCard post={featured} large /></div>}

        {rest.length > 0 ? (
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3" key={cat}>
            {rest.map((n) => <NewsCard key={n.slug} post={n} />)}
          </div>
        ) : (
          <div className="glass animate-fade-up rounded-[2rem] p-10 text-center">
            <MapPin className="mx-auto h-10 w-10 text-rose-300" />
            <h2 className="mt-4 font-display text-3xl text-white">No {cat === "field" ? "field updates" : "posts"} yet</h2>
            <p className="mx-auto mt-3 max-w-lg text-slate-400">
              {cat === "field"
                ? "Field updates about activities and support will be published only once they are verified — and never with identifying details of children without consent."
                : "Check back soon for new posts in this category."}
            </p>
          </div>
        )}
      </Section>

      <Section className="pt-0">
        <Subscribe />
      </Section>

      <CtaBand title="Be part of the next update." />
    </>
  );
}
