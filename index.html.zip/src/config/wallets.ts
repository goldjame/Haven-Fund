/**
 * Donation wallet configuration.
 * ------------------------------------------------------------------
 * This is the single source of truth for every donation address shown
 * on the website. Each entry is validated at runtime against the expected
 * address format for its network (see `validateWalletConfig`). If a
 * format check ever fails, the donation UI refuses to display that
 * address and shows an error instead — a safety net against typos.
 */

export type AssetId = "BTC" | "LN" | "ETH" | "USDT" | "USDC" | "SOL" | "LTC";

export interface CryptoAsset {
  id: AssetId;
  /** Ticker shown to users */
  symbol: string;
  name: string;
  /** Human-readable network name */
  network: string;
  /** Short network/standard tag */
  networkTag: string;
  address: string;
  /** Brand colour used for accents */
  color: string;
  /** CoinGecko id used for optional USD estimates */
  priceId: string;
  /** Unit used for amount input */
  unit: string;
  /** Decimals to show for amount estimates */
  decimals: number;
  /** Multiplier from asset price to unit (e.g. 1e8 sats per BTC) */
  unitsPerCoin: number;
  addressPattern: RegExp;
  txPattern?: RegExp;
  txHint?: string;
  explorerAddress?: (a: string) => string;
  explorerTx?: (h: string) => string;
  /** Build a payment URI (BIP21 / Solana Pay style) for the QR code */
  buildUri?: (address: string, amount?: number) => string;
  /** Plain-language guidance */
  summary: string;
  warnings: string[];
  feeNote: string;
  beginnerFriendly?: boolean;
}

const BECH32 = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
const BASE58 = "1-9A-HJ-NP-Za-km-z";

const fmtAmount = (n: number, max = 8) =>
  Number(n.toFixed(max)).toString();

export const ASSETS: CryptoAsset[] = [
  {
    id: "BTC",
    symbol: "BTC",
    name: "Bitcoin",
    network: "Bitcoin (on-chain)",
    networkTag: "BTC Network",
    address: "bc1qucxw759hq0n5dagfyqvyf29perajalaejf0atn",
    color: "#F7931A",
    priceId: "bitcoin",
    unit: "BTC",
    decimals: 8,
    unitsPerCoin: 1,
    addressPattern: new RegExp(`^(bc1[${BECH32}]{25,87}|[13][${BASE58}]{25,34})$`),
    txPattern: /^[a-fA-F0-9]{64}$/,
    txHint: "64 hexadecimal characters",
    explorerAddress: (a) => `https://mempool.space/address/${a}`,
    explorerTx: (h) => `https://mempool.space/tx/${h}`,
    buildUri: (a, amt) => (amt && amt > 0 ? `bitcoin:${a}?amount=${fmtAmount(amt, 8)}` : `bitcoin:${a}`),
    summary: "The original cryptocurrency. Sent directly on the Bitcoin blockchain.",
    warnings: ["Send only Bitcoin (BTC) on the Bitcoin network to this address."],
    feeNote: "Network fees vary with demand. Your wallet shows the fee before you confirm.",
  },
  {
    id: "LN",
    symbol: "BTC ⚡",
    name: "Bitcoin Lightning",
    network: "Lightning Network (BOLT12 offer)",
    networkTag: "Lightning",
    address:
      "lno1pgqppmsrse80qf0aara4slvcjxrvu6j2rp5ftmjy4yntlsmsutpkvkt6878sxq57h40fvvy903vl3vpw66w82yuylm7qxahggmh3hys7rn6a8uzqqgpjsmw255rcanldkklg32xgl35rxp934hxckpsre645rxxdjnshrmcqx0t0qmg3msdmscfvl45dekuc205dzxvww7la39ezmp7kclahjyypmsksvzchs33e9f6rnn2qr788pen6vqvsx3q9shflrr5fhthuatzk9wqappgyk0zgu7r2lz50rvyxfg8cv4a9qqefyxyg8ktx4qusar229cas4axv47vwwlp4dvzqpwnuc32273dzqu8a4sqc9qx2q9x7kqfvswv346g0zhxs",
    color: "#FACC15",
    priceId: "bitcoin",
    unit: "sats",
    decimals: 0,
    unitsPerCoin: 100_000_000,
    addressPattern: new RegExp(`^lno1[${BECH32}]{20,}$`),
    txPattern: /^[a-fA-F0-9]{64}$/,
    txHint: "Payment hash / preimage — 64 hexadecimal characters (optional)",
    summary: "Near-instant Bitcoin payments with very low fees. Uses a reusable BOLT12 offer.",
    warnings: [
      "Requires a Lightning wallet that supports BOLT12 offers (for example Phoenix). Some wallets do not support BOLT12 yet.",
      "Do not send on-chain Bitcoin to this Lightning offer — use the Bitcoin (on-chain) option instead.",
    ],
    feeNote: "Lightning fees are usually a tiny fraction of the amount sent.",
  },
  {
    id: "ETH",
    symbol: "ETH",
    name: "Ethereum",
    network: "Ethereum Mainnet",
    networkTag: "ETH Network",
    address: "0xAE36513721336bF94557549Ab08aB5A31e3e2125",
    color: "#8C8FE6",
    priceId: "ethereum",
    unit: "ETH",
    decimals: 6,
    unitsPerCoin: 1,
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
    txHint: "Starts with 0x followed by 64 hexadecimal characters",
    explorerAddress: (a) => `https://etherscan.io/address/${a}`,
    explorerTx: (h) => `https://etherscan.io/tx/${h}`,
    summary: "Native ETH sent on the Ethereum mainnet.",
    warnings: [
      "Send only on Ethereum Mainnet. Do not use other networks (BNB Chain, Polygon, Arbitrum, Base, etc.) unless the organization has confirmed support.",
    ],
    feeNote: "Ethereum charges a gas fee, paid in ETH, which your wallet estimates for you.",
  },
  {
    id: "USDT",
    symbol: "USDT",
    name: "Tether USD",
    network: "TRON (TRC-20)",
    networkTag: "TRX Network",
    address: "TXCtmhq2kAMsQTzH79drmPR8Pz8hpFrxTh",
    color: "#26A17B",
    priceId: "tether",
    unit: "USDT",
    decimals: 2,
    unitsPerCoin: 1,
    addressPattern: new RegExp(`^T[${BASE58}]{33}$`),
    txPattern: /^[a-fA-F0-9]{64}$/,
    txHint: "64 hexadecimal characters",
    explorerAddress: (a) => `https://tronscan.org/#/address/${a}`,
    explorerTx: (h) => `https://tronscan.org/#/transaction/${h}`,
    summary: "A stablecoin designed to track the US dollar, sent on the TRON network.",
    warnings: [
      "Send only USDT on the TRON (TRC-20) network. Choose “TRC-20” or “TRON” when your wallet or exchange asks for the network.",
    ],
    feeNote: "TRON transfers need a small amount of TRX (or energy) in the sending wallet to cover fees.",
    beginnerFriendly: true,
  },
  {
    id: "USDC",
    symbol: "USDC",
    name: "USD Coin",
    network: "Ethereum (ERC-20)",
    networkTag: "ETH Network",
    address: "0xAE36513721336bF94557549Ab08aB5A31e3e2125",
    color: "#2775CA",
    priceId: "usd-coin",
    unit: "USDC",
    decimals: 2,
    unitsPerCoin: 1,
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
    txHint: "Starts with 0x followed by 64 hexadecimal characters",
    explorerAddress: (a) =>
      `https://etherscan.io/token/0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48?a=${a}`,
    explorerTx: (h) => `https://etherscan.io/tx/${h}`,
    summary: "A US-dollar stablecoin, sent as an ERC-20 token on Ethereum.",
    warnings: [
      "Send only USDC on Ethereum (ERC-20). Do not send USDC from other networks.",
    ],
    feeNote: "ERC-20 transfers require ETH in the sending wallet to pay gas.",
    beginnerFriendly: true,
  },
  {
    id: "SOL",
    symbol: "SOL",
    name: "Solana",
    network: "Solana Mainnet",
    networkTag: "SOL Network",
    address: "7BAjxeGKTVtcirVyRqYzzs3XiuwZ94PUU9bYCib2Jbeb",
    color: "#14F195",
    priceId: "solana",
    unit: "SOL",
    decimals: 4,
    unitsPerCoin: 1,
    addressPattern: new RegExp(`^[${BASE58}]{32,44}$`),
    txPattern: new RegExp(`^[${BASE58}]{80,90}$`),
    txHint: "Transaction signature — 87–88 base58 characters",
    explorerAddress: (a) => `https://solscan.io/account/${a}`,
    explorerTx: (h) => `https://solscan.io/tx/${h}`,
    buildUri: (a, amt) => (amt && amt > 0 ? `solana:${a}?amount=${fmtAmount(amt, 9)}` : `solana:${a}`),
    summary: "Fast, low-cost transfers on the Solana network.",
    warnings: ["Send only native SOL on the Solana network to this address."],
    feeNote: "Solana network fees are typically very small.",
  },
  {
    id: "LTC",
    symbol: "LTC",
    name: "Litecoin",
    network: "Litecoin",
    networkTag: "LTC Network",
    address: "LQHN7e29nSWPTyhhz1oVmA4VrPeNuhQSWa",
    color: "#A6A9AA",
    priceId: "litecoin",
    unit: "LTC",
    decimals: 6,
    unitsPerCoin: 1,
    addressPattern: new RegExp(`^([LM3][${BASE58}]{26,33}|ltc1[${BECH32}]{25,87})$`),
    txPattern: /^[a-fA-F0-9]{64}$/,
    txHint: "64 hexadecimal characters",
    explorerAddress: (a) => `https://litecoinspace.org/address/${a}`,
    explorerTx: (h) => `https://litecoinspace.org/tx/${h}`,
    buildUri: (a, amt) => (amt && amt > 0 ? `litecoin:${a}?amount=${fmtAmount(amt, 8)}` : `litecoin:${a}`),
    summary: "A long-running, low-fee cryptocurrency on its own Litecoin network.",
    warnings: ["Send only Litecoin (LTC) on the Litecoin network to this address."],
    feeNote: "Litecoin fees are generally low.",
  },
];

export const getAsset = (id: AssetId) => ASSETS.find((a) => a.id === id)!;

export function isValidAddress(asset: CryptoAsset, address = asset.address) {
  return asset.addressPattern.test(address.trim());
}

export function isValidTx(asset: CryptoAsset, tx: string) {
  if (!asset.txPattern) return true;
  return asset.txPattern.test(tx.trim());
}

export function validateWalletConfig() {
  return ASSETS.map((a) => ({ id: a.id, valid: isValidAddress(a) }));
}

export function shortAddress(a: string, head = 8, tail = 6) {
  if (a.length <= head + tail + 3) return a;
  return `${a.slice(0, head)}…${a.slice(-tail)}`;
}
