import { AlertTriangle, CheckCircle2, Clock, HelpCircle, Search, XCircle, Zap } from "lucide-react";
import type { VerifyResult } from "../../services/verify";
import { STATUS_LABEL } from "../../services/receipt";
import { cn } from "../../utils/cn";

const STYLE: Record<VerifyResult["status"], { icon: typeof CheckCircle2; cls: string; hint: string }> = {
  confirmed: { icon: CheckCircle2, cls: "border-emerald-400/40 bg-emerald-400/10 text-emerald-100", hint: "Your donation has been received by Haven Fund’s address." },
  pending: { icon: Clock, cls: "border-sky-400/40 bg-sky-400/10 text-sky-100", hint: "Your transaction was found and is waiting for network confirmation. This usually takes a few minutes." },
  not_found: { icon: Search, cls: "border-amber-300/40 bg-amber-300/10 text-amber-100", hint: "If you just sent it, wait a minute and check again. Make sure you copied the full transaction ID and chose the right cryptocurrency." },
  wrong_recipient: { icon: XCircle, cls: "border-rose-400/40 bg-rose-400/10 text-rose-100", hint: "This transaction didn’t send funds to the Haven Fund address for this network. Check the cryptocurrency/network you selected, or contact us with the transaction ID." },
  failed: { icon: XCircle, cls: "border-rose-400/40 bg-rose-400/10 text-rose-100", hint: "The network rejected this transaction, so no funds were transferred. Your wallet may show the reason." },
  unsupported: { icon: Zap, cls: "border-white/15 bg-white/5 text-slate-200", hint: "Lightning payments are private by design. Your wallet shows whether the payment succeeded." },
  error: { icon: AlertTriangle, cls: "border-amber-300/40 bg-amber-300/10 text-amber-100", hint: "The public blockchain service couldn’t be reached. You can still complete your donation and verify later on the block explorer." },
};

export function VerificationBadge({ result, compact }: { result: VerifyResult; compact?: boolean }) {
  const s = STYLE[result.status] ?? { icon: HelpCircle, cls: "", hint: "" };
  return (
    <div role="status" data-testid="verify-status" data-status={result.status} className={cn("rounded-2xl border p-4 text-left text-sm", s.cls)}>
      <p className="flex items-center gap-2 font-bold">
        <s.icon className="h-5 w-5 shrink-0" /> {STATUS_LABEL[result.status]}
        {result.received !== undefined && (
          <span className="ml-auto rounded-lg bg-black/20 px-2 py-0.5 font-mono text-xs" data-testid="verify-amount">
            {result.received.toLocaleString(undefined, { maximumFractionDigits: 9 })} {result.unit}
          </span>
        )}
      </p>
      {!compact && <p className="mt-1.5 opacity-85">{result.detail && result.status !== "confirmed" ? `${result.detail} ` : ""}{s.hint}</p>}
      <p className="mt-1.5 text-xs opacity-60">
        Checked {new Date(result.checkedAt).toLocaleTimeString()} {result.source !== "—" && `· ${result.source}`}
        {result.blockHeight ? ` · block ${result.blockHeight.toLocaleString()}` : ""}
      </p>
    </div>
  );
}
