import { useRef, useState, type FormEvent } from "react";
import { AlertTriangle, ArrowLeft, CheckCircle2, Loader2, Mail, SearchCheck } from "lucide-react";
import { getAsset, isValidTx, type AssetId, type CryptoAsset } from "../../config/wallets";
import { getCampaign, type CampaignId } from "../../config/campaigns";
import { makeReference, paymentProvider } from "../../services/payments";
import { canVerify, verifyDonation, type VerifyResult } from "../../services/verify";
import { emailEnabled, sendEmail } from "../../services/email";
import { receiptText } from "../../services/receipt";
import { GhostBtn, NavRow, PrimaryBtn } from "./controls";
import { VerificationBadge } from "./VerificationBadge";
import { cn } from "../../utils/cn";

export interface Confirmation {
  reference: string;
  assetId: AssetId;
  campaignId?: CampaignId;
  amount?: number;
  txHash?: string;
  stored: "remote" | "local" | "none";
  verification?: VerifyResult;
  email: "sent" | "failed" | "skipped";
  donorEmail?: string;
  copySent?: boolean;
  createdAt: string;
}

interface Props {
  asset: CryptoAsset;
  campaignId: CampaignId;
  amount?: number;
  usdEstimate?: number;
  onBack: () => void;
  onDone: (c: Confirmation) => void;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function StepConfirm({ asset, campaignId, amount, usdEstimate, onBack, onDone }: Props) {
  const [tx, setTx] = useState("");
  const [touched, setTouched] = useState(false);
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [stage, setStage] = useState("");
  const [err, setErr] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verification, setVerification] = useState<VerifyResult | null>(null);
  const verifiedFor = useRef<string>("");

  const [notify, setNotify] = useState(emailEnabled);
  const [wantCopy, setWantCopy] = useState(false);
  const [donorEmail, setDonorEmail] = useState("");
  const [emailTouched, setEmailTouched] = useState(false);

  const trimmed = tx.trim();
  const txInvalid = trimmed !== "" && !isValidTx(asset, trimmed);
  const verifiable = canVerify(asset.id);
  const emailInvalid = wantCopy && !EMAIL_RE.test(donorEmail.trim());

  const runVerify = async () => {
    setTouched(true);
    if (!trimmed || txInvalid) return null;
    setVerifying(true);
    const r = await verifyDonation(asset, trimmed);
    verifiedFor.current = trimmed;
    setVerification(r);
    setVerifying(false);
    return r;
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setTouched(true);
    setEmailTouched(true);
    if (txInvalid || emailInvalid) return;
    setState("loading");
    setErr("");
    const reference = makeReference();
    const createdAt = new Date().toISOString();

    // 1) Verify on-chain (if a tx id was given and not already checked)
    let v = verification && verifiedFor.current === trimmed ? verification : null;
    if (trimmed && verifiable && !v) {
      setStage("Checking the blockchain…");
      v = await runVerify();
    }

    // 2) Save the reference (backend or this device, per privacy settings)
    setStage("Saving your reference…");
    let stored: Confirmation["stored"] = "none";
    try {
      stored = (
        await paymentProvider.submitReference({ reference, assetId: asset.id, campaignId, amount, usdEstimate, txHash: trimmed || undefined, createdAt })
      ).stored;
    } catch {
      /* non-blocking: the donation itself is on the blockchain */
    }

    // 3) Email: notify Haven Fund and/or send the donor a copy
    let email: Confirmation["email"] = "skipped";
    const copyTo = wantCopy ? donorEmail.trim() : undefined;
    if (emailEnabled && (notify || copyTo)) {
      setStage("Sending confirmation email…");
      try {
        const text = receiptText({ reference, assetId: asset.id, campaignId, amount, txHash: trimmed || undefined, verification: v ?? undefined, createdAt });
        await sendEmail({
          subject: `Haven Fund donation ${reference} — ${getAsset(asset.id).symbol}${v?.status === "confirmed" ? " (verified on-chain)" : ""}`,
          replyTo: copyTo,
          copyTo,
          fields: {
            Reference: reference,
            Campaign: getCampaign(campaignId).name,
            Cryptocurrency: `${asset.name} (${asset.symbol})`,
            Network: asset.network,
            "Amount entered": amount !== undefined ? `${amount} ${asset.unit}` : "Not specified",
            "Transaction ID": trimmed || "Not provided",
            "Blockchain check": v ? `${v.status}${v.received !== undefined ? ` — ${v.received} ${v.unit} received` : ""}` : "Not checked",
            Receipt: text,
          },
        });
        email = "sent";
      } catch {
        email = "failed";
      }
    }

    onDone({
      reference,
      assetId: asset.id,
      campaignId,
      amount,
      txHash: trimmed || undefined,
      stored,
      verification: v ?? undefined,
      email,
      donorEmail: copyTo,
      copySent: email === "sent" && Boolean(copyTo),
      createdAt,
    });
  };

  return (
    <form onSubmit={submit} noValidate data-testid="confirm-form">
      <h3 className="text-xl font-bold text-white">Almost done — confirm your donation</h3>
      <p className="mt-1 text-sm text-slate-400">
        Paste your transaction ID to verify your donation on the public blockchain and get a receipt. It’s optional, but recommended.
      </p>

      <label htmlFor="txhash" className="mt-6 block text-sm font-semibold text-slate-300">
        Transaction ID / hash <span className="font-normal text-slate-500">(optional)</span>
      </label>
      <div className="mt-2 flex flex-col gap-2 sm:flex-row">
        <input
          id="txhash"
          value={tx}
          onChange={(e) => {
            setTx(e.target.value.slice(0, 140));
            if (verification) setVerification(null);
          }}
          onBlur={() => setTouched(true)}
          autoComplete="off"
          autoCapitalize="off"
          spellCheck={false}
          inputMode="text"
          placeholder={asset.txHint}
          aria-invalid={touched && txInvalid}
          aria-describedby="tx-help"
          className={cn(
            "min-w-0 flex-1 rounded-2xl border bg-ink-900/60 px-4 py-4 font-mono text-sm text-white outline-none transition placeholder:font-sans placeholder:text-slate-600 focus:border-hope-400/60",
            touched && txInvalid ? "border-rose-400/60" : "border-white/10"
          )}
        />
        {verifiable && (
          <button
            type="button"
            onClick={runVerify}
            disabled={!trimmed || txInvalid || verifying}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-tech-400/40 bg-tech-400/10 px-5 py-4 text-sm font-bold text-tech-100 transition hover:bg-tech-400/20 disabled:opacity-40"
          >
            {verifying ? <Loader2 className="h-4 w-4 animate-spin" /> : <SearchCheck className="h-4 w-4" />}
            {verifying ? "Checking…" : "Verify on blockchain"}
          </button>
        )}
      </div>
      <p id="tx-help" className="mt-2 min-h-5 text-sm" aria-live="polite">
        {touched && txInvalid ? (
          <span className="text-rose-300">This doesn’t look like a valid {asset.network} transaction ID. Expected: {asset.txHint}.</span>
        ) : trimmed && !txInvalid ? (
          <span className="inline-flex items-center gap-1.5 text-emerald-300"><CheckCircle2 className="h-4 w-4" /> Valid format for {asset.network}</span>
        ) : (
          <span className="text-slate-500">Find it in your wallet’s transaction history (tap the transaction → copy ID).</span>
        )}
      </p>
      {verification && <div className="mt-3"><VerificationBadge result={verification} /></div>}

      {/* Email & receipt */}
      <fieldset className="mt-6 space-y-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
        <legend className="px-1 text-sm font-semibold text-slate-300">Receipt & notification</legend>
        <label className="flex cursor-pointer items-start gap-3 text-sm text-slate-300">
          <input type="checkbox" checked={wantCopy} onChange={(e) => setWantCopy(e.target.checked)} disabled={!emailEnabled} className="mt-0.5 h-4 w-4 accent-amber-400" />
          <span>Email me a copy of my donation receipt</span>
        </label>
        {wantCopy && (
          <div>
            <label htmlFor="donor-email" className="sr-only">Your email</label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                id="donor-email"
                type="email"
                autoComplete="email"
                value={donorEmail}
                onChange={(e) => setDonorEmail(e.target.value.slice(0, 120))}
                onBlur={() => setEmailTouched(true)}
                aria-invalid={emailTouched && emailInvalid}
                placeholder="you@example.com"
                className={cn("w-full rounded-xl border bg-ink-900/60 py-3 pl-11 pr-4 text-white outline-none placeholder:text-slate-600 focus:border-hope-400/60", emailTouched && emailInvalid ? "border-rose-400/60" : "border-white/10")}
              />
            </div>
            {emailTouched && emailInvalid && <p className="mt-1.5 text-sm text-rose-300">Please enter a valid email address.</p>}
          </div>
        )}
        <label className="flex cursor-pointer items-start gap-3 text-sm text-slate-300">
          <input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} disabled={!emailEnabled} className="mt-0.5 h-4 w-4 accent-amber-400" />
          <span>Send my donation reference to the Haven Fund team <span className="text-slate-500">(helps us thank you and match your campaign choice)</span></span>
        </label>
        <p className="text-xs text-slate-500">Only the details shown here are sent. We never ask for seed phrases, private keys or passwords.</p>
      </fieldset>

      {state === "error" && (
        <p role="alert" className="mt-4 flex gap-2 rounded-2xl border border-rose-400/40 bg-rose-400/10 p-4 text-sm text-rose-100">
          <AlertTriangle className="h-4 w-4 shrink-0" /> {err} Your donation on the blockchain is unaffected — please try again.
        </p>
      )}

      <NavRow>
        <GhostBtn onClick={onBack}>
          <ArrowLeft className="h-4 w-4" /> Back
        </GhostBtn>
        <PrimaryBtn type="submit" disabled={state === "loading" || verifying || (touched && txInvalid)}>
          {state === "loading" ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> {stage || "Confirming…"}
            </>
          ) : (
            <>Complete donation</>
          )}
        </PrimaryBtn>
      </NavRow>
    </form>
  );
}
