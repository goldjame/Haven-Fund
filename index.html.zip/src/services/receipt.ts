/** Donation receipt (acknowledgement) — generated on the donor's device. */
import { getAsset, type AssetId } from "../config/wallets";
import { getCampaign, type CampaignId } from "../config/campaigns";
import { ORG } from "../config/org";
import type { VerifyResult } from "./verify";

export interface ReceiptData {
  reference: string;
  assetId: AssetId;
  campaignId?: CampaignId;
  amount?: number;
  txHash?: string;
  verification?: VerifyResult;
  createdAt: string;
}

export const STATUS_LABEL: Record<string, string> = {
  confirmed: "Confirmed on the blockchain",
  pending: "Found — awaiting confirmation",
  not_found: "Not found on the blockchain yet",
  wrong_recipient: "Does not pay Haven Fund’s address",
  failed: "Failed on-chain",
  unsupported: "Not publicly verifiable (Lightning)",
  error: "Could not be checked",
};

export function receiptLines(d: ReceiptData): [string, string][] {
  const a = getAsset(d.assetId);
  const v = d.verification;
  const rows: [string, string][] = [
    ["Reference", d.reference],
    ["Date", new Date(d.createdAt).toLocaleString()],
    ["Campaign", d.campaignId ? getCampaign(d.campaignId).name : "Haven General Fund"],
    ["Cryptocurrency", `${a.name} (${a.symbol})`],
    ["Network", a.network],
    ["Haven Fund address", a.address.length > 80 ? `${a.address.slice(0, 40)}…${a.address.slice(-20)}` : a.address],
  ];
  if (d.amount !== undefined) rows.push(["Amount (as entered)", `${d.amount} ${a.unit}`]);
  if (d.txHash) rows.push(["Transaction ID", d.txHash]);
  if (v) {
    rows.push(["Blockchain check", STATUS_LABEL[v.status] ?? v.status]);
    if (v.received !== undefined) rows.push(["Amount received (on-chain)", `${v.received} ${v.unit}`]);
    if (v.blockHeight) rows.push(["Block", String(v.blockHeight)]);
    rows.push(["Checked", `${new Date(v.checkedAt).toLocaleString()} via ${v.source}`]);
  }
  if (d.txHash && a.explorerTx) rows.push(["Public record", a.explorerTx(d.txHash)]);
  return rows;
}

const DISCLAIMER =
  "This is an acknowledgement of your donation, not a tax receipt. Tax-deductibility has not been confirmed. Blockchain transactions are final and publicly recorded.";

export function receiptText(d: ReceiptData) {
  return [
    `${ORG.name} — Donation acknowledgement`,
    "",
    ...receiptLines(d).map(([k, v]) => `${k}: ${v}`),
    "",
    "Thank you for giving hope to street children and homeless people.",
    "",
    DISCLAIMER,
    "",
    `${ORG.name} · ${ORG.address} · ${ORG.email} · ${ORG.phone}`,
  ].join("\n");
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export function receiptHtml(d: ReceiptData) {
  const rows = receiptLines(d)
    .map(([k, v]) => `<tr><th>${esc(k)}</th><td>${v.startsWith("https://") ? `<a href="${esc(v)}">${esc(v)}</a>` : esc(v)}</td></tr>`)
    .join("");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(ORG.name)} receipt ${esc(d.reference)}</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:720px;margin:40px auto;padding:0 20px;color:#0f172a}
h1{font-size:22px;margin:0}p.sub{color:#475569;margin:4px 0 24px}table{width:100%;border-collapse:collapse;font-size:14px}
th,td{text-align:left;padding:10px 8px;border-bottom:1px solid #e2e8f0;vertical-align:top;word-break:break-all}th{width:38%;color:#475569;font-weight:600;word-break:normal}
.brand{display:flex;align-items:center;gap:10px;margin-bottom:6px}.dot{width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#fcd34d,#22d3ee)}
.note{margin-top:24px;font-size:12px;color:#64748b}.thanks{margin-top:24px;font-size:16px}@media print{a{color:inherit}}</style></head>
<body><div class="brand"><div class="dot"></div><h1>${esc(ORG.name)} — Donation acknowledgement</h1></div>
<p class="sub">${esc(ORG.tagline)}</p><table>${rows}</table>
<p class="thanks">Thank you for giving hope to street children and homeless people.</p>
<p class="note">${esc(DISCLAIMER)}</p>
<p class="note">${esc(ORG.name)} · ${esc(ORG.address)} · ${esc(ORG.email)} · ${esc(ORG.phone)}</p></body></html>`;
}

export function downloadReceipt(d: ReceiptData) {
  const blob = new Blob([receiptHtml(d)], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `HavenFund-receipt-${d.reference}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
