import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./fonts.css";
import "./index.css";
import App from "./App";

const LOCAL = /^(localhost|127\.0\.0\.1|\[::1\])$/;

/** 1) Force HTTPS (server-side redirects + HSTS are the primary control; this is a fallback). */
function enforceHttps(): boolean {
  const { protocol, hostname, href } = window.location;
  if (protocol === "http:" && !LOCAL.test(hostname)) {
    window.location.replace(href.replace(/^http:/, "https:"));
    return true;
  }
  return false;
}

/** 2) Clickjacking protection fallback (primary control: CSP frame-ancestors / X-Frame-Options headers). */
function isFramed(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function renderFramedWarning(root: HTMLElement) {
  root.innerHTML = "";
  const box = document.createElement("div");
  box.setAttribute("style", "min-height:100vh;display:grid;place-items:center;padding:24px;background:#04050d;color:#e2e8f0;font-family:system-ui,sans-serif;text-align:center");
  const inner = document.createElement("div");
  const h = document.createElement("h1");
  h.textContent = "For your security, Haven Fund can’t be displayed inside another website.";
  h.setAttribute("style", "font-size:20px;margin:0 0 12px");
  const a = document.createElement("a");
  a.href = window.location.href;
  a.target = "_top";
  a.rel = "noopener";
  a.textContent = "Open Haven Fund directly";
  a.setAttribute("style", "color:#fcd34d");
  inner.append(h, a);
  box.append(inner);
  root.append(box);
}

const root = document.getElementById("root")!;

if (!enforceHttps()) {
  if (isFramed()) {
    renderFramedWarning(root);
  } else {
    createRoot(root).render(
      <StrictMode>
        <App />
      </StrictMode>
    );
  }
}
