import { Compass } from "lucide-react";
import { GhostLink, PrimaryLink } from "../components/layout";
import { NAV } from "../components/Navbar";
import { to } from "../router";

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-[80svh] max-w-3xl flex-col items-center justify-center px-5 pt-32 pb-16 text-center">
      <Compass className="h-14 w-14 animate-float text-hope-300" />
      <p className="mt-6 font-mono text-sm text-slate-500">404</p>
      <h1 className="mt-2 font-display text-5xl text-white md:text-6xl">This path leads <em className="text-gradient italic">nowhere… yet.</em></h1>
      <p className="mt-4 text-slate-400">The page you’re looking for doesn’t exist or has moved.</p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <PrimaryLink href={to("home")}>Back to home</PrimaryLink>
        <GhostLink href={to("donate")}>Donate</GhostLink>
      </div>
      <ul className="mt-10 flex flex-wrap justify-center gap-2">
        {NAV.map((n) => (
          <li key={n.page}><a href={to(n.page)} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:text-white">{n.label}</a></li>
        ))}
      </ul>
    </section>
  );
}
