/**
 * On-chain donation verification.
 * ------------------------------------------------------------------
 * Given a transaction ID, checks the PUBLIC blockchain to confirm that the
 * transaction exists, succeeded, and actually paid Haven Fund's address.
 * Read-only public data; no keys, no accounts. Triggered only when the donor
 * clicks "Verify on blockchain".
 *
 *   BTC / LTC   → Esplora API (mempool.space / litecoinspace.org)
 *   ETH / USDC  → Ethereum JSON-RPC (publicnode.com)
 *   USDT TRC-20 → TronGrid
 *   SOL         → Solana JSON-RPC (publicnode.com)
 *   Lightning   → not verifiable publicly (off-chain, private by design)
 */
import type { AssetId, CryptoAsset } from "../config/wallets";
import { secureFetch } from "./http";

export type VerifyStatus = "confirmed" | "pending" | "not_found" | "wrong_recipient" | "failed" | "unsupported" | "error";

export interface VerifyResult {
  status: VerifyStatus;
  /** Amount received by our address, in the asset's display unit */
  received?: number;
  unit: string;
  blockHeight?: number;
  checkedAt: string;
  source: string;
  detail?: string;
}

export const ENDPOINTS = {
  btc: "https://mempool.space/api",
  ltc: "https://litecoinspace.org/api",
  eth: "https://ethereum-rpc.publicnode.com",
  tron: "https://api.trongrid.io",
  sol: "https://solana-rpc.publicnode.com",
};

const USDC_CONTRACT = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48";
const USDT_TRC20_CONTRACT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
const TRANSFER_TOPIC = "ddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

/* ------------------------------- base58 utils ------------------------------ */
const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

export function base58Decode(s: string): Uint8Array {
  let n = 0n;
  for (const ch of s) {
    const i = B58.indexOf(ch);
    if (i < 0) throw new Error("Invalid base58");
    n = n * 58n + BigInt(i);
  }
  const bytes: number[] = [];
  while (n > 0n) {
    bytes.unshift(Number(n % 256n));
    n /= 256n;
  }
  for (const ch of s) {
    if (ch !== "1") break;
    bytes.unshift(0);
  }
  return new Uint8Array(bytes);
}

const toHex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");

/** TRON base58 address → 20-byte hex (without the 0x41 prefix), lowercase. */
export function tronToHex20(addr: string): string {
  const raw = base58Decode(addr); // 0x41 + 20 bytes + 4 checksum
  if (raw.length !== 25 || raw[0] !== 0x41) throw new Error("Invalid TRON address");
  return toHex(raw.slice(1, 21));
}

/* --------------------------------- helpers -------------------------------- */
const now = () => new Date().toISOString();
const clean = (h: string) => h.trim();
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export class BusyError extends Error {}
class NotFoundError extends Error {}

/** Free public APIs rate-limit (HTTP 429). Retry with backoff before giving up. */
async function withRetry(doFetch: () => Promise<Response>): Promise<Response> {
  for (let attempt = 0; ; attempt++) {
    const res = await doFetch();
    if (res.status !== 429 && res.status !== 503) return res;
    if (attempt >= 3) throw new BusyError("The blockchain service is busy right now. Please try again in a minute.");
    await sleep(1200 * 2 ** attempt);
  }
}

async function getJson<T>(url: string): Promise<{ status: number; data: T | null }> {
  const res = await withRetry(() => secureFetch(url, { headers: { accept: "application/json" } }, { timeoutMs: 12000 }));
  if (res.status === 404 || res.status === 400) return { status: res.status, data: null };
  if (!res.ok) throw new Error(`${new URL(url).host} responded ${res.status}`);
  return { status: res.status, data: (await res.json()) as T };
}

async function rpc<T>(url: string, method: string, params: unknown[]): Promise<T> {
  const res = await withRetry(() =>
    secureFetch(
      url,
      { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) },
      { timeoutMs: 12000 }
    )
  );
  if (!res.ok) throw new Error(`${new URL(url).host} responded ${res.status}`);
  const j = (await res.json()) as { result?: T; error?: { message: string } };
  if (j.error) {
    // Malformed / unknown ids are reported as RPC param errors by some nodes.
    if (/invalid (param|argument)|wrongsize|invalid length|not found/i.test(j.error.message)) throw new NotFoundError(j.error.message);
    throw new Error(j.error.message);
  }
  return j.result as T;
}

async function postJson<T>(url: string, body: unknown): Promise<T> {
  const res = await withRetry(() => secureFetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }, { timeoutMs: 12000 }));
  if (!res.ok) throw new Error(`${new URL(url).host} responded ${res.status}`);
  return (await res.json()) as T;
}

/* ------------------------------- per-chain -------------------------------- */
interface EsploraTx {
  vout: { scriptpubkey_address?: string; value: number }[];
  status: { confirmed: boolean; block_height?: number };
}

async function verifyEsplora(base: string, source: string, txid: string, address: string, unit: string): Promise<VerifyResult> {
  const { data } = await getJson<EsploraTx>(`${base}/tx/${txid}`);
  if (!data) return { status: "not_found", unit, checkedAt: now(), source };
  const sats = data.vout.filter((o) => o.scriptpubkey_address === address).reduce((s, o) => s + o.value, 0);
  if (sats === 0) return { status: "wrong_recipient", unit, checkedAt: now(), source, detail: "This transaction does not send any funds to Haven Fund’s address." };
  return {
    status: data.status.confirmed ? "confirmed" : "pending",
    received: sats / 1e8,
    unit,
    blockHeight: data.status.block_height,
    checkedAt: now(),
    source,
  };
}

interface EthTx { to: string | null; value: string; blockNumber: string | null }
interface EthReceipt { status: string; blockNumber: string; logs: { address: string; topics: string[]; data: string }[] }

async function verifyEvm(txhash: string, address: string, token: "ETH" | "USDC"): Promise<VerifyResult> {
  const source = "Ethereum (publicnode.com)";
  const unit = token;
  const tx = await rpc<EthTx | null>(ENDPOINTS.eth, "eth_getTransactionByHash", [txhash]);
  if (!tx) return { status: "not_found", unit, checkedAt: now(), source };
  const receipt = await rpc<EthReceipt | null>(ENDPOINTS.eth, "eth_getTransactionReceipt", [txhash]);
  const me = address.toLowerCase();

  if (token === "ETH") {
    const wei = BigInt(tx.value || "0x0");
    if (!tx.to || tx.to.toLowerCase() !== me || wei === 0n)
      return { status: "wrong_recipient", unit, checkedAt: now(), source, detail: "No direct ETH transfer to Haven Fund’s address was found in this transaction." };
    const received = Number(wei) / 1e18;
    if (!receipt) return { status: "pending", received, unit, checkedAt: now(), source };
    if (receipt.status !== "0x1") return { status: "failed", unit, checkedAt: now(), source, detail: "The transaction failed on-chain." };
    return { status: "confirmed", received, unit, blockHeight: parseInt(receipt.blockNumber, 16), checkedAt: now(), source };
  }

  // USDC (ERC-20)
  if (!receipt) return { status: "pending", unit, checkedAt: now(), source, detail: "Waiting to be included in a block." };
  if (receipt.status !== "0x1") return { status: "failed", unit, checkedAt: now(), source, detail: "The transaction failed on-chain." };
  const padded = `0x${me.slice(2).padStart(64, "0")}`;
  let raw = 0n;
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() === USDC_CONTRACT && log.topics[0]?.toLowerCase() === `0x${TRANSFER_TOPIC}` && log.topics[2]?.toLowerCase() === padded) {
      raw += BigInt(log.data);
    }
  }
  if (raw === 0n) return { status: "wrong_recipient", unit, checkedAt: now(), source, detail: "No USDC transfer to Haven Fund’s address was found in this transaction." };
  return { status: "confirmed", received: Number(raw) / 1e6, unit, blockHeight: parseInt(receipt.blockNumber, 16), checkedAt: now(), source };
}

interface TronInfo {
  id?: string;
  blockNumber?: number;
  receipt?: { result?: string };
  result?: string;
  log?: { address: string; topics: string[]; data: string }[];
}

async function verifyTron(txid: string, address: string): Promise<VerifyResult> {
  const source = "TRON (TronGrid)";
  const unit = "USDT";
  const info = await postJson<TronInfo>(`${ENDPOINTS.tron}/wallet/gettransactioninfobyid`, { value: txid });
  if (!info || !info.id) {
    const tx = await postJson<{ txID?: string }>(`${ENDPOINTS.tron}/wallet/gettransactionbyid`, { value: txid });
    if (!tx?.txID) return { status: "not_found", unit, checkedAt: now(), source };
    return { status: "pending", unit, checkedAt: now(), source, detail: "Waiting to be included in a block." };
  }
  if (info.result === "FAILED" || (info.receipt?.result && info.receipt.result !== "SUCCESS"))
    return { status: "failed", unit, checkedAt: now(), source, detail: `The transaction failed on-chain (${info.receipt?.result ?? info.result}).` };

  const contract = tronToHex20(USDT_TRC20_CONTRACT);
  const me = tronToHex20(address);
  let raw = 0n;
  for (const log of info.log ?? []) {
    const logAddr = log.address.toLowerCase().replace(/^41/, "");
    if (logAddr === contract && log.topics[0]?.toLowerCase() === TRANSFER_TOPIC && log.topics[2]?.toLowerCase().endsWith(me)) {
      raw += BigInt(`0x${log.data}`);
    }
  }
  if (raw === 0n) return { status: "wrong_recipient", unit, checkedAt: now(), source, detail: "No USDT (TRC-20) transfer to Haven Fund’s address was found in this transaction." };
  return { status: "confirmed", received: Number(raw) / 1e6, unit, blockHeight: info.blockNumber, checkedAt: now(), source };
}

interface SolTx {
  slot: number;
  meta: { err: unknown; preBalances: number[]; postBalances: number[] } | null;
  transaction: { message: { accountKeys: ({ pubkey: string } | string)[] } };
}

async function verifySolana(sig: string, address: string): Promise<VerifyResult> {
  const source = "Solana (publicnode.com)";
  const unit = "SOL";
  const tx = await rpc<SolTx | null>(ENDPOINTS.sol, "getTransaction", [sig, { encoding: "jsonParsed", maxSupportedTransactionVersion: 0, commitment: "confirmed" }]);
  if (!tx) return { status: "not_found", unit, checkedAt: now(), source, detail: "Not found yet — very recent transactions can take a few seconds to appear." };
  if (!tx.meta) return { status: "pending", unit, checkedAt: now(), source };
  if (tx.meta.err) return { status: "failed", unit, checkedAt: now(), source, detail: "The transaction failed on-chain." };
  const keys = tx.transaction.message.accountKeys.map((k) => (typeof k === "string" ? k : k.pubkey));
  const i = keys.indexOf(address);
  const delta = i >= 0 ? tx.meta.postBalances[i] - tx.meta.preBalances[i] : 0;
  if (delta <= 0) return { status: "wrong_recipient", unit, checkedAt: now(), source, detail: "This transaction does not increase Haven Fund’s SOL balance." };
  return { status: "confirmed", received: delta / 1e9, unit, blockHeight: tx.slot, checkedAt: now(), source };
}

/* --------------------------------- public --------------------------------- */
export const canVerify = (id: AssetId) => id !== "LN";

export async function verifyDonation(asset: Pick<CryptoAsset, "id" | "address" | "unit">, txid: string): Promise<VerifyResult> {
  const h = clean(txid);
  try {
    switch (asset.id) {
      case "BTC":
        return await verifyEsplora(ENDPOINTS.btc, "Bitcoin (mempool.space)", h, asset.address, "BTC");
      case "LTC":
        return await verifyEsplora(ENDPOINTS.ltc, "Litecoin (litecoinspace.org)", h, asset.address, "LTC");
      case "ETH":
        return await verifyEvm(h, asset.address, "ETH");
      case "USDC":
        return await verifyEvm(h, asset.address, "USDC");
      case "USDT":
        return await verifyTron(h, asset.address);
      case "SOL":
        return await verifySolana(h, asset.address);
      default:
        return { status: "unsupported", unit: asset.unit, checkedAt: now(), source: "—", detail: "Lightning payments are private and cannot be verified on a public blockchain." };
    }
  } catch (e) {
    if (e instanceof NotFoundError) return { status: "not_found", unit: asset.unit, checkedAt: now(), source: "—" };
    return { status: "error", unit: asset.unit, checkedAt: now(), source: "—", detail: e instanceof Error ? e.message : "Verification service unavailable." };
  }
}
