import { Globe2, HeartHandshake, Lock, MessageSquareQuote, ShieldCheck, Sparkles } from "lucide-react";
import { Mission, WhoWeHelp } from "../components/InfoSections";
import { OrgInfo, Policies } from "../components/Transparency";
import { CtaBand, GhostLink, PageHero, PrimaryLink, Section } from "../components/layout";
import { SectionHeading } from "../components/ui";
import { to } from "../router";

const PRINCIPLES = [
  { icon: HeartHandshake, title: "Dignity first", text: "Every person we aim to support is treated with respect. We talk about people, not problems." },
  { icon: ShieldCheck, title: "Radical transparency", text: "Official wallets are public and verifiable on-chain. Reports are published only once verified." },
  { icon: Lock, title: "Consent & child protection", text: "We never publish names, photos or stories of children without informed guardian consent." },
  { icon: MessageSquareQuote, title: "Honest communication", text: "No invented statistics, testimonials, partnerships or claims — placeholders are clearly marked." },
  { icon: Globe2, title: "Borderless giving", text: "Anyone, anywhere, can give directly with cryptocurrency — no bank account required." },
  { icon: Sparkles, title: "Technology with humanity", text: "AI and blockchain are tools to serve people — never a replacement for human care." },
];

export default function About() {
  return (
    <>
      <PageHero
        eyebrow="About Us"
        title="Technology with"
        accent="humanity."
        crumb="About Us"
        actions={
          <>
            <PrimaryLink href={to("donate")}>Donate With Crypto</PrimaryLink>
            <GhostLink href={to("campaigns")}>Explore campaigns</GhostLink>
          </>
        }
      >
        Haven Fund is a cryptocurrency-only donation platform supporting street children and homeless people. Our purpose is simple:
        turn digital value into real-world dignity.
      </PageHero>

      <Mission />

      {/* Why crypto */}
      <Section labelledBy="why-crypto">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="reveal glass-strong relative overflow-hidden rounded-[2rem] p-8 md:p-10">
            <div aria-hidden className="absolute -left-16 -top-16 h-56 w-56 rounded-full bg-tech-500/20 blur-3xl" />
            <p className="relative font-display text-3xl italic leading-snug text-white md:text-4xl">
              “Why crypto only? Because giving should be as borderless as need.”
            </p>
            <ul className="relative mt-8 grid gap-3 text-sm text-slate-300 sm:grid-cols-2">
              {["Give from anywhere in the world", "No bank account or card needed", "Minutes, not days", "Publicly verifiable addresses"].map((t) => (
                <li key={t} className="flex items-center gap-2 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-tech-300" /> {t}
                </li>
              ))}
            </ul>
          </div>
          <SectionHeading id="why-crypto" eyebrow="Why crypto" title="A new way to give," accent="built on trust." center={false}>
            Cryptocurrency lets people support vulnerable communities directly and quickly, across borders. Because on-chain transactions are
            recorded publicly, anyone can independently view incoming donations to our official addresses — a foundation for trust that we
            build on with clear, honest communication.
          </SectionHeading>
        </div>
      </Section>

      <WhoWeHelp />

      {/* Principles */}
      <Section labelledBy="principles">
        <SectionHeading id="principles" eyebrow="Our principles" title="What we" accent="stand for.">
          The commitments that guide how Haven Fund operates and communicates.
        </SectionHeading>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PRINCIPLES.map((p, i) => (
            <article key={p.title} className="reveal glass group rounded-3xl p-7 transition duration-500 hover:-translate-y-1" style={{ transitionDelay: `${(i % 3) * 80}ms` }}>
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-hope-400/15 text-hope-300 transition group-hover:scale-110">
                <p.icon className="h-6 w-6" />
              </span>
              <h3 className="mt-5 text-lg font-bold text-white">{p.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{p.text}</p>
            </article>
          ))}
        </div>
      </Section>

      {/* Organization */}
      <Section id="organization" labelledBy="org-title">
        <SectionHeading id="org-title" eyebrow="Organization" title="Who is" accent="Haven Fund?">
          Official organization details. Anything not yet verified is clearly marked as a placeholder.
        </SectionHeading>
        <div className="grid gap-6 md:grid-cols-2">
          <OrgInfo />
          <Policies />
        </div>
      </Section>

      <CtaBand />
    </>
  );
}
