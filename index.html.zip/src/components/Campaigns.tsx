import { Apple, BookOpen, HeartPulse, Home, Shirt, Sparkles, ArrowRight, MessageCircle } from "lucide-react";
import { CAMPAIGNS, type CampaignId } from "../config/campaigns";
import { SectionHeading } from "./ui";
import { openHavenAI } from "./AssistantSection";
import { navigate, to } from "../router";
import { cn } from "../utils/cn";

const ICONS: Record<CampaignId, typeof Apple> = {
  general: Sparkles,
  food: Apple,
  shelter: Home,
  warmth: Shirt,
  education: BookOpen,
  care: HeartPulse,
};

const ACCENTS = {
  hope: { text: "text-hope-300", bg: "bg-hope-400/15", glow: "from-hope-400/25", line: "via-hope-400/70" },
  tech: { text: "text-tech-300", bg: "bg-tech-400/15", glow: "from-tech-400/25", line: "via-tech-400/70" },
  aura: { text: "text-aura-400", bg: "bg-aura-400/15", glow: "from-aura-400/25", line: "via-aura-400/70" },
  emerald: { text: "text-emerald-300", bg: "bg-emerald-400/15", glow: "from-emerald-400/25", line: "via-emerald-400/70" },
  rose: { text: "text-rose-300", bg: "bg-rose-400/15", glow: "from-rose-400/25", line: "via-rose-400/70" },
};

export const selectCampaign = (id: CampaignId) => navigate(to("donate", undefined, { campaign: id }));

export default function Campaigns({ limit, showHeading = true, id = "campaigns" }: { limit?: number; showHeading?: boolean; id?: string }) {
  const list = limit ? CAMPAIGNS.slice(0, limit) : CAMPAIGNS;
  return (
    <section id={id} aria-labelledby={showHeading ? "campaigns-title" : undefined} aria-label={showHeading ? undefined : "Campaign list"} className={cn("relative scroll-mt-24", showHeading ? "py-24 md:py-32" : "pb-16 md:pb-24")}>
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        {showHeading && (
          <SectionHeading id="campaigns-title" eyebrow="Campaigns" title="Choose where your" accent="kindness goes.">
            Each campaign is a focus area describing how donations are intended to be used. Pick one when you donate — or
            choose the General Fund to support wherever the need is greatest.
          </SectionHeading>
        )}

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((c, i) => {
            const Icon = ICONS[c.id];
            const a = ACCENTS[c.accent];
            return (
              <article
                key={c.id}
                className="reveal glass group relative flex flex-col overflow-hidden rounded-[1.75rem] p-7 transition duration-500 hover:-translate-y-1.5"
                style={{ transitionDelay: `${(i % 3) * 90}ms` }}
              >
                <div className={`absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent ${a.line} to-transparent`} />
                <div className={`absolute -right-12 -top-12 h-40 w-40 rounded-full bg-gradient-to-br ${a.glow} to-transparent blur-2xl transition duration-700 group-hover:scale-150`} />
                <div className="relative flex items-center justify-between">
                  <span className={`grid h-12 w-12 place-items-center rounded-2xl ${a.bg} ${a.text}`}>
                    <Icon className="h-6 w-6" />
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Open
                  </span>
                </div>
                <p className={`relative mt-6 text-xs font-semibold uppercase tracking-[0.18em] ${a.text}`}>{c.short}</p>
                <h3 className="relative mt-1 font-display text-3xl text-white">{c.name}</h3>
                <p className="relative mt-3 text-sm leading-relaxed text-slate-400">{c.description}</p>
                <ul className="relative mt-5 space-y-2 text-sm text-slate-300">
                  {c.intendedUse.map((u) => (
                    <li key={u} className="flex items-center gap-2">
                      <span className={`h-1.5 w-1.5 rounded-full ${a.bg.replace("/15", "")}`} />
                      {u}
                    </li>
                  ))}
                </ul>
                <div className="relative mt-auto flex items-center gap-2 pt-7">
                  <button
                    onClick={() => selectCampaign(c.id)}
                    className="btn-shine inline-flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold text-ink-950 transition hover:scale-[1.02]"
                  >
                    Donate to this campaign <ArrowRight className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => openHavenAI(`Tell me about the ${c.name} campaign`)}
                    aria-label={`Ask Haven AI about ${c.name}`}
                    title="Ask Haven AI"
                    className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-tech-300 transition hover:bg-tech-400/10"
                  >
                    <MessageCircle className="h-4 w-4" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
        {limit && limit < CAMPAIGNS.length ? (
          <div className="reveal mt-10 text-center">
            <a href={to("campaigns")} className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-6 py-3.5 font-semibold text-white transition hover:bg-white/10">
              View all {CAMPAIGNS.length} campaigns <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        ) : (
        <p className="reveal mt-6 text-center text-xs text-slate-500">
          Campaign targets and progress are not shown until verified figures are published. All campaigns share the same secure wallets; your
          campaign preference is recorded with your donation reference.
        </p>
        )}
      </div>
    </section>
  );
}
