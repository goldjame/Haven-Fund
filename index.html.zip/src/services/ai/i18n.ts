/** Languages supported by Haven AI (UI + grounded knowledge base). */
export type Lang = "en" | "es" | "fr" | "pt" | "ar";
export type L<T = string> = Record<Lang, T>;

export const LANGS: { code: Lang; label: string; native: string; speech: string; dir: "ltr" | "rtl" }[] = [
  { code: "en", label: "English", native: "English", speech: "en-US", dir: "ltr" },
  { code: "es", label: "Spanish", native: "Español", speech: "es-ES", dir: "ltr" },
  { code: "fr", label: "French", native: "Français", speech: "fr-FR", dir: "ltr" },
  { code: "pt", label: "Portuguese", native: "Português", speech: "pt-BR", dir: "ltr" },
  { code: "ar", label: "Arabic", native: "العربية", speech: "ar-SA", dir: "rtl" },
];

export const langMeta = (l: Lang) => LANGS.find((x) => x.code === l)!;

/** Detect the language of a message (lightweight heuristic, no network). */
export function detectLang(text: string): Lang | null {
  const t = text.toLowerCase();
  if (/[\u0600-\u06FF]/.test(t)) return "ar";
  if (/[ãõ]|ção|ções/.test(t)) return "pt";
  if (/(^|[\s¿¡])(você|vocês|olá|obrigad[oa]|doar|campanhas?|posso|quais)([\s?!.,]|$)/.test(t) && !/[ñ¿]/.test(t)) return "pt";
  if (/[ñ¿¡]/.test(t)) return "es";
  if (/[èêàùûœëî]|ç(?!ão)/.test(t)) return "fr";
  const words = t.replace(/[^\p{L}\s']/gu, " ").split(/\s+/).filter(Boolean);
  const STOP: Record<Exclude<Lang, "ar">, string[]> = {
    en: ["how", "what", "the", "is", "do", "you", "hello", "hi", "thanks", "donate", "can", "where", "who", "are", "my", "which", "i", "to", "about"],
    es: ["cómo", "como", "qué", "que", "donar", "hola", "gracias", "dónde", "cuál", "puedo", "los", "las", "el", "es", "para", "por", "quién", "usted", "eres", "dinero", "ayuda"],
    fr: ["comment", "je", "quoi", "bonjour", "merci", "vous", "est", "les", "des", "une", "faire", "don", "pourquoi", "où", "quelle", "quel", "êtes", "argent", "aide", "salut"],
    pt: ["como", "você", "voce", "olá", "ola", "obrigado", "obrigada", "doar", "não", "nao", "são", "uma", "para", "quem", "onde", "posso", "é", "dinheiro", "ajuda", "oi"],
  };
  let best: Lang | null = null;
  let bestScore = 0;
  (Object.keys(STOP) as (keyof typeof STOP)[]).forEach((l) => {
    const s = words.filter((w) => STOP[l].includes(w)).length;
    if (s > bestScore) {
      bestScore = s;
      best = l;
    }
  });
  return best;
}

/** Chat UI strings */
export const UI: L<{
  welcome: string;
  placeholder: string;
  listening: string;
  disclaimer: string;
  subtitle: string;
  suggestions: string[];
  error: string;
  retry: string;
  voiceUnsupported: string;
  voiceDenied: string;
  voiceNoSpeech: string;
  listen: string;
  stop: string;
  auto: string;
}> = {
  en: {
    welcome:
      "Hi, I’m **Haven AI** — an AI assistant (not a human). I can explain Haven Fund, our campaigns, how crypto donations work, and help you find your way around.\n\nType or tap the microphone to ask a question — in English, Español, Français, Português or العربية.",
    placeholder: "Ask about donating, campaigns, networks…",
    listening: "Listening… speak now",
    disclaimer: "Haven AI can make mistakes. Never share seed phrases or private keys.",
    subtitle: "AI assistant · not a human",
    suggestions: ["How do I donate?", "What campaigns are available?", "How are funds used?", "I'm new to crypto", "Which coins do you accept?", "Are you a human?"],
    error: "Sorry — I couldn’t respond just now. Please check your connection and try again.",
    retry: "Retry",
    voiceUnsupported: "Voice input isn’t supported in this browser. Please try Chrome, Edge or Safari — or type your question.",
    voiceDenied: "Microphone access was blocked. Please allow microphone permission in your browser settings, or type your question.",
    voiceNoSpeech: "I didn’t catch that. Please try again or type your question.",
    listen: "Listen",
    stop: "Stop",
    auto: "Auto-detect",
  },
  es: {
    welcome:
      "Hola, soy **Haven AI**, un asistente de inteligencia artificial (no una persona). Puedo explicarte Haven Fund, nuestras campañas, cómo funcionan las donaciones en cripto y ayudarte a navegar por el sitio.\n\nEscribe o toca el micrófono para preguntar.",
    placeholder: "Pregunta sobre donaciones, campañas, redes…",
    listening: "Escuchando… habla ahora",
    disclaimer: "Haven AI puede cometer errores. Nunca compartas tu frase semilla ni claves privadas.",
    subtitle: "Asistente de IA · no es una persona",
    suggestions: ["¿Cómo puedo donar?", "¿Qué campañas hay?", "¿Cómo se usan los fondos?", "Soy nuevo en cripto", "¿Qué monedas aceptan?", "¿Eres una persona?"],
    error: "Lo siento, no pude responder ahora. Revisa tu conexión e inténtalo de nuevo.",
    retry: "Reintentar",
    voiceUnsupported: "La entrada por voz no es compatible con este navegador. Prueba Chrome, Edge o Safari, o escribe tu pregunta.",
    voiceDenied: "El acceso al micrófono está bloqueado. Permite el micrófono en tu navegador o escribe tu pregunta.",
    voiceNoSpeech: "No te escuché bien. Inténtalo de nuevo o escribe tu pregunta.",
    listen: "Escuchar",
    stop: "Detener",
    auto: "Detección automática",
  },
  fr: {
    welcome:
      "Bonjour, je suis **Haven AI**, un assistant d’intelligence artificielle (pas un humain). Je peux vous présenter Haven Fund, nos campagnes, le fonctionnement des dons en crypto et vous guider sur le site.\n\nÉcrivez ou touchez le micro pour poser une question.",
    placeholder: "Question sur les dons, campagnes, réseaux…",
    listening: "À l’écoute… parlez maintenant",
    disclaimer: "Haven AI peut se tromper. Ne partagez jamais votre phrase de récupération ni vos clés privées.",
    subtitle: "Assistant IA · pas un humain",
    suggestions: ["Comment faire un don ?", "Quelles campagnes existent ?", "Comment les fonds sont-ils utilisés ?", "Je débute en crypto", "Quelles cryptos acceptez-vous ?", "Êtes-vous humain ?"],
    error: "Désolé, je n’ai pas pu répondre. Vérifiez votre connexion et réessayez.",
    retry: "Réessayer",
    voiceUnsupported: "La saisie vocale n’est pas prise en charge par ce navigateur. Essayez Chrome, Edge ou Safari, ou écrivez votre question.",
    voiceDenied: "L’accès au micro est bloqué. Autorisez le micro dans votre navigateur ou écrivez votre question.",
    voiceNoSpeech: "Je n’ai pas bien entendu. Réessayez ou écrivez votre question.",
    listen: "Écouter",
    stop: "Arrêter",
    auto: "Détection auto",
  },
  pt: {
    welcome:
      "Olá, sou o **Haven AI**, um assistente de inteligência artificial (não um humano). Posso explicar o Haven Fund, nossas campanhas, como funcionam as doações em cripto e ajudar você a navegar pelo site.\n\nDigite ou toque no microfone para perguntar.",
    placeholder: "Pergunte sobre doações, campanhas, redes…",
    listening: "Ouvindo… fale agora",
    disclaimer: "O Haven AI pode cometer erros. Nunca compartilhe sua frase-semente ou chaves privadas.",
    subtitle: "Assistente de IA · não é humano",
    suggestions: ["Como posso doar?", "Quais campanhas existem?", "Como os fundos são usados?", "Sou novo em cripto", "Quais moedas vocês aceitam?", "Você é humano?"],
    error: "Desculpe, não consegui responder agora. Verifique sua conexão e tente novamente.",
    retry: "Tentar novamente",
    voiceUnsupported: "A entrada por voz não é suportada neste navegador. Tente Chrome, Edge ou Safari, ou digite sua pergunta.",
    voiceDenied: "O acesso ao microfone foi bloqueado. Permita o microfone no navegador ou digite sua pergunta.",
    voiceNoSpeech: "Não entendi. Tente novamente ou digite sua pergunta.",
    listen: "Ouvir",
    stop: "Parar",
    auto: "Detecção automática",
  },
  ar: {
    welcome:
      "مرحبًا، أنا **Haven AI**، مساعد ذكاء اصطناعي (ولست إنسانًا). يمكنني التعريف بـ Haven Fund وحملاتنا، وشرح كيفية التبرع بالعملات الرقمية، ومساعدتك في التنقل داخل الموقع.\n\nاكتب سؤالك أو اضغط على الميكروفون للتحدث.",
    placeholder: "اسأل عن التبرع أو الحملات أو الشبكات…",
    listening: "أستمع إليك… تحدّث الآن",
    disclaimer: "قد يخطئ Haven AI. لا تشارك أبدًا عبارة الاسترداد أو المفاتيح الخاصة.",
    subtitle: "مساعد ذكاء اصطناعي · ليس إنسانًا",
    suggestions: ["كيف يمكنني التبرع؟", "ما الحملات المتاحة؟", "كيف تُستخدم التبرعات؟", "أنا جديد في العملات الرقمية", "ما العملات المقبولة؟", "هل أنت إنسان؟"],
    error: "عذرًا، لم أتمكن من الرد الآن. تحقق من اتصالك وحاول مرة أخرى.",
    retry: "إعادة المحاولة",
    voiceUnsupported: "الإدخال الصوتي غير مدعوم في هذا المتصفح. جرّب Chrome أو Edge أو Safari، أو اكتب سؤالك.",
    voiceDenied: "تم حظر الوصول إلى الميكروفون. اسمح بالميكروفون من إعدادات المتصفح أو اكتب سؤالك.",
    voiceNoSpeech: "لم أسمعك جيدًا. حاول مرة أخرى أو اكتب سؤالك.",
    listen: "استماع",
    stop: "إيقاف",
    auto: "اكتشاف تلقائي",
  },
};

/** Action button labels */
export const ACTION: Record<string, L> = {
  donate: { en: "Open donation panel", es: "Abrir panel de donación", fr: "Ouvrir le panneau de don", pt: "Abrir painel de doação", ar: "افتح لوحة التبرع" },
  campaigns: { en: "View campaigns", es: "Ver campañas", fr: "Voir les campagnes", pt: "Ver campanhas", ar: "عرض الحملات" },
  transparency: { en: "Impact & Transparency", es: "Impacto y transparencia", fr: "Impact et transparence", pt: "Impacto e transparência", ar: "الأثر والشفافية" },
  contact: { en: "Contact the team", es: "Contactar al equipo", fr: "Contacter l’équipe", pt: "Falar com a equipe", ar: "تواصل مع الفريق" },
  mission: { en: "Our mission", es: "Nuestra misión", fr: "Notre mission", pt: "Nossa missão", ar: "مهمتنا" },
  who: { en: "Who we help", es: "A quién ayudamos", fr: "Qui nous aidons", pt: "Quem ajudamos", ar: "من نساعد" },
  how: { en: "How donations work", es: "Cómo funcionan las donaciones", fr: "Fonctionnement des dons", pt: "Como funcionam as doações", ar: "كيف يعمل التبرع" },
  faq: { en: "FAQ", es: "Preguntas frecuentes", fr: "FAQ", pt: "Perguntas frequentes", ar: "الأسئلة الشائعة" },
  privacy: { en: "Privacy Policy", es: "Política de privacidad", fr: "Politique de confidentialité", pt: "Política de privacidade", ar: "سياسة الخصوصية" },
  terms: { en: "Terms & Conditions", es: "Términos y condiciones", fr: "Conditions générales", pt: "Termos e condições", ar: "الشروط والأحكام" },
  security: { en: "Security & Trust", es: "Seguridad", fr: "Sécurité", pt: "Segurança", ar: "الأمان والثقة" },
  about: { en: "About Us", es: "Sobre nosotros", fr: "À propos", pt: "Sobre nós", ar: "من نحن" },
  updates: { en: "Updates & News", es: "Novedades", fr: "Actualités", pt: "Atualizações", ar: "المستجدات" },
  facebook: { en: "Facebook page", es: "Página de Facebook", fr: "Page Facebook", pt: "Página do Facebook", ar: "صفحة فيسبوك" },
};
