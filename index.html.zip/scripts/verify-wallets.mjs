#!/usr/bin/env node
/**
 * Wallet integrity checker — detects tampering with donation addresses.
 *
 *   node scripts/verify-wallets.mjs --pin            Pin current addresses (after YOU verify them)
 *   node scripts/verify-wallets.mjs                  Check source + dist/index.html against the pin
 *   node scripts/verify-wallets.mjs https://site.org Check the LIVE website against the pin
 *
 * Exit code 0 = OK, 1 = mismatch/tampering suspected, 2 = usage error.
 * Run the live check on a schedule (e.g. daily cron / GitHub Action) and alert on failure.
 */
import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const SRC = join(ROOT, "src/config/wallets.ts");
const DIST = join(ROOT, "dist/index.html");
const LOCK = join(ROOT, "security/wallets.lock.json");

const sha = (s) => createHash("sha256").update(s).digest("hex");
const red = (s) => `\x1b[31m${s}\x1b[0m`;
const green = (s) => `\x1b[32m${s}\x1b[0m`;

/** Extract { id, address } pairs from wallets.ts */
function readSource() {
  const src = readFileSync(SRC, "utf8");
  const out = [];
  const re = /id:\s*"([A-Z]+)"[\s\S]*?address:\s*\n?\s*"([^"]+)"/g;
  let m;
  while ((m = re.exec(src))) out.push({ id: m[1], address: m[2] });
  return out;
}

/** Address-like strings that should NOT appear unless pinned. */
const SCAN = [
  /\bbc1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{25,87}\b/g,
  /\b0x[a-fA-F0-9]{40}\b/g,
  /\bT[1-9A-HJ-NP-Za-km-z]{33}\b/g,
  /\b[LM][1-9A-HJ-NP-Za-km-z]{33}\b/g,
  /\blno1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{20,}\b/g,
];
/** Known non-wallet values allowed in the bundle (e.g. token contract addresses in explorer links). */
const ALLOW = new Set([
  "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", // USDC token contract (Ethereum) — used for explorer links + verification
  "tr7nhqjekqxgtci8q8zy4pl8otszgjlj6t", // USDT token contract (TRON) — used to verify TRC-20 transfers
]);

function checkContent(label, html, lock) {
  let ok = true;
  for (const w of lock.wallets) {
    if (!html.includes(w.address)) {
      console.log(red(`✗ ${label}: pinned ${w.id} address NOT found`));
      ok = false;
    }
  }
  const pinned = new Set(lock.wallets.map((w) => w.address.toLowerCase()));
  const unexpected = new Set();
  for (const re of SCAN) for (const m of html.matchAll(re)) {
    const v = m[0].toLowerCase();
    if (!pinned.has(v) && !ALLOW.has(v)) unexpected.add(m[0]);
  }
  if (unexpected.size) {
    ok = false;
    console.log(red(`✗ ${label}: unexpected address-like strings found:`));
    for (const u of unexpected) console.log(red(`    ${u}`));
  }
  if (ok) console.log(green(`✓ ${label}: all ${lock.wallets.length} pinned addresses present, no unexpected addresses`));
  return ok;
}

async function main() {
  const arg = process.argv[2];
  const source = readSource();
  if (!source.length) {
    console.error(red("No wallets found in src/config/wallets.ts"));
    process.exit(2);
  }

  if (arg === "--pin") {
    mkdirSync(dirname(LOCK), { recursive: true });
    const lock = {
      note: "Pinned donation addresses. Only update after verifying each address in the wallet app itself.",
      pinnedAt: new Date().toISOString(),
      wallets: source.map((w) => ({ ...w, sha256: sha(w.address) })),
    };
    writeFileSync(LOCK, JSON.stringify(lock, null, 2) + "\n");
    console.log(green(`Pinned ${source.length} addresses → ${LOCK}`));
    for (const w of lock.wallets) console.log(`  ${w.id.padEnd(5)} ${w.address.slice(0, 12)}…${w.address.slice(-8)}  sha256:${w.sha256.slice(0, 16)}`);
    return;
  }

  if (!existsSync(LOCK)) {
    console.error(red("No pin file. Verify the addresses in your wallet apps, then run with --pin."));
    process.exit(2);
  }
  const lock = JSON.parse(readFileSync(LOCK, "utf8"));
  let ok = true;

  // Lock self-consistency
  for (const w of lock.wallets) if (sha(w.address) !== w.sha256) { console.log(red(`✗ lock file: hash mismatch for ${w.id}`)); ok = false; }

  if (arg && /^https?:\/\//.test(arg)) {
    if (!arg.startsWith("https://")) console.log(red("⚠ Live site URL is not HTTPS!"));
    const res = await fetch(arg, { redirect: "follow" });
    if (!res.ok) { console.error(red(`HTTP ${res.status} from ${arg}`)); process.exit(1); }
    if (!res.url.startsWith("https://")) { console.log(red(`✗ Final URL is not HTTPS: ${res.url}`)); ok = false; }
    const hsts = res.headers.get("strict-transport-security");
    console.log(hsts ? green("✓ HSTS header present") : red("✗ HSTS header missing"));
    const csp = res.headers.get("content-security-policy");
    console.log(csp ? green("✓ CSP header present") : red("✗ CSP header missing (meta fallback only)"));
    ok = checkContent(`live ${res.url}`, await res.text(), lock) && ok;
  } else {
    // Source vs lock
    const byId = Object.fromEntries(lock.wallets.map((w) => [w.id, w.address]));
    for (const w of source) {
      if (byId[w.id] !== w.address) { console.log(red(`✗ source: ${w.id} address differs from pinned value`)); ok = false; }
    }
    if (source.length !== lock.wallets.length) { console.log(red("✗ source: number of wallets differs from pin")); ok = false; }
    if (ok) console.log(green("✓ source: src/config/wallets.ts matches pinned addresses"));
    if (existsSync(DIST)) ok = checkContent("dist/index.html", readFileSync(DIST, "utf8"), lock) && ok;
    else console.log("… dist/index.html not found (run npm run build to check the bundle)");
  }

  if (!ok) {
    console.log(red("\nWALLET INTEGRITY CHECK FAILED — do not deploy. Investigate immediately."));
    process.exit(1);
  }
  console.log(green("\nWallet integrity check passed."));
}

main().catch((e) => {
  console.error(red(e.message));
  process.exit(1);
});
