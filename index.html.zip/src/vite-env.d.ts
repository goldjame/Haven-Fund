/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Optional: URL of your backend AI proxy (never put provider API keys in the frontend). */
  readonly VITE_AI_ENDPOINT?: string;
  /** Optional: URL of your backend contact-form handler. */
  readonly VITE_CONTACT_ENDPOINT?: string;
  /** Optional: URL of your backend crypto payment / on-ramp session endpoint. */
  readonly VITE_PAYMENT_ENDPOINT?: string;
  /** Required with VITE_PAYMENT_ENDPOINT: comma-separated hosts allowed for checkout redirects. */
  readonly VITE_CHECKOUT_ALLOWED_HOSTS?: string;
  /** Optional: HTTPS form-to-email endpoint (default: FormSubmit to the org email). Use "off" to disable. */
  readonly VITE_FORM_ENDPOINT?: string;
  /** Optional: URL of your backend newsletter subscription handler. */
  readonly VITE_NEWSLETTER_ENDPOINT?: string;
  /** Optional: override crypto price endpoint. */
  readonly VITE_PRICE_ENDPOINT?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
