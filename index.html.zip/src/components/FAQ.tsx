import { useMemo, useState } from "react";
import { ChevronDown, Search } from "lucide-react";
import { SectionHeading } from "./ui";
import { cn } from "../utils/cn";

const FAQS = [
  {
    topic: "general",
    q: "Why do you only accept cryptocurrency?",
    a: "Crypto lets anyone, anywhere, give directly and quickly without banks or card processors, and on-chain donations are publicly verifiable. It’s central to our “Technology With Humanity” approach.",
  },
  {
    topic: "crypto",
    q: "I’ve never used crypto. Can I still donate?",
    a: "Yes. Get crypto from a reputable exchange or wallet app in your country, then use its Send/Withdraw feature. Stablecoins like USDT (TRC-20) or USDC (ERC-20) are often simplest because they track the US dollar. Our donation panel walks you through every step, and Haven AI can answer questions along the way.",
  },
  {
    topic: "crypto",
    q: "Which cryptocurrencies and networks are supported?",
    a: "Bitcoin (on-chain), Bitcoin Lightning (BOLT12 offer), Ethereum (Mainnet), Tether USDT (TRON TRC-20), USD Coin USDC (Ethereum ERC-20), Solana, and Litecoin.",
  },
  {
    topic: "crypto",
    q: "What happens if I send on the wrong network?",
    a: "Funds sent on an unsupported network may be permanently lost, because blockchain transactions cannot be reversed. Always choose exactly the network shown on the donation card.",
  },
  {
    topic: "crypto",
    q: "Are there fees?",
    a: "Blockchain networks charge a transaction fee that goes to the network, not to us. Your wallet shows the fee before you confirm. USDT on TRON needs a little TRX (or energy), and USDC on Ethereum needs ETH for gas.",
  },
  {
    topic: "general",
    q: "How will my donation be used?",
    a: "Donations are intended to support food, shelter, clothing, education and essential support for street children and homeless people. A verified allocation breakdown and impact reports will be published in the Transparency section once available.",
  },
  {
    topic: "general",
    q: "What campaigns can I support?",
    a: "Haven General Fund (where it’s needed most), Meals of Hope (food & clean water), Safe Haven (shelter), Warmth & Dignity (clothing & hygiene), Future Minds (education for street children) and Essential Care (basic care & support). All campaigns share the same wallets; the campaign you choose is recorded with your donation reference.",
  },
  {
    topic: "crypto",
    q: "Can I verify my donation?",
    a: "Yes. All on-chain donation addresses are public — you can view incoming transactions on block explorers linked in the Transparency section. You can also paste your transaction ID on the confirmation step for a direct link.",
  },
  {
    topic: "general",
    q: "Is my donation tax-deductible?",
    a: "This hasn’t been confirmed, and the site doesn’t issue tax receipts. Tax rules depend on your country — please consult a qualified tax professional.",
  },
  {
    topic: "general",
    q: "Do you store my personal data?",
    a: "No account is needed to donate. If you choose to enter a transaction ID without a connected backend, it’s stored only on your device. See our Privacy Policy for details.",
  },
  {
    topic: "general",
    q: "Which languages does Haven AI speak, and can I use my voice?",
    a: "Haven AI understands English, Español, Français, Português and العربية, and detects your language automatically. Tap the microphone to ask by voice (supported in most modern browsers such as Chrome, Edge and Safari), and tap “Listen” on any reply to hear it read aloud.",
  },
  {
    topic: "general",
    q: "Is Haven AI a real person?",
    a: "No. Haven AI is an AI assistant. It explains how donations work and helps you navigate the site, and it’s designed never to invent statistics, partnerships or financial information.",
  },
];

export default function FAQ({ topic, showHeading = true, title, accent, intro }: { topic?: "crypto" | "general"; showHeading?: boolean; title?: string; accent?: string; intro?: string }) {
  const [open, setOpen] = useState<number | null>(0);
  const [query, setQuery] = useState("");
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return FAQS.map((f, i) => ({ ...f, i })).filter((f) => !topic || f.topic === topic).filter((f) => !q || f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q));
  }, [query, topic]);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.filter((f) => !topic || f.topic === topic).map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
  };

  return (
    <section id="faq" aria-labelledby="faq-title" className="relative scroll-mt-24 py-24 md:py-32">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="mx-auto max-w-4xl px-5 sm:px-8">
        {showHeading && (
          <SectionHeading id="faq-title" eyebrow="FAQ" title={title ?? "Questions,"} accent={accent ?? "answered."}>
            {intro ?? "Everything you need to know before you give."}
          </SectionHeading>
        )}

        <div className="reveal relative mb-6">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <label htmlFor="faq-search" className="sr-only">Search questions</label>
          <input
            id="faq-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions…"
            className="glass w-full rounded-2xl py-4 pl-11 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-hope-400/50"
          />
        </div>

        <div className="reveal space-y-3">
          {list.length === 0 && (
            <p className="glass rounded-2xl p-6 text-center text-slate-400">
              No matching questions. Try asking <strong className="text-white">Haven AI</strong> using the chat button.
            </p>
          )}
          {list.map((f) => {
            const isOpen = open === f.i;
            return (
              <div key={f.q} className={cn("glass overflow-hidden rounded-2xl transition", isOpen && "border-hope-400/30")}>
                <h3>
                  <button
                    type="button"
                    id={`faq-q-${f.i}`}
                    aria-expanded={isOpen}
                    aria-controls={`faq-a-${f.i}`}
                    onClick={() => setOpen(isOpen ? null : f.i)}
                    className="flex w-full items-center justify-between gap-4 p-5 text-left font-semibold text-white md:p-6"
                  >
                    {f.q}
                    <ChevronDown className={cn("h-5 w-5 shrink-0 text-hope-300 transition-transform duration-300", isOpen && "rotate-180")} />
                  </button>
                </h3>
                <div
                  id={`faq-a-${f.i}`}
                  role="region"
                  aria-labelledby={`faq-q-${f.i}`}
                  className={cn("grid transition-all duration-500", isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-6 leading-relaxed text-slate-400 md:px-6">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
