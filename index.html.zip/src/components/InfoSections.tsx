import {
  Apple, BookOpen, Cpu, Eye, Globe2, HandHeart, Home, Shirt, Stethoscope, Wallet, QrCode, Send, BadgeCheck, Baby, Users,
} from "lucide-react";
import { SectionHeading } from "./ui";

/* ---------------------------------- Mission --------------------------------- */
export function Mission() {
  const pillars = [
    {
      icon: Cpu,
      title: "Technology",
      text: "Cryptocurrency lets anyone send support across borders in minutes — no bank account, no intermediaries, no geography limits.",
      tone: "from-tech-400/20 to-transparent text-tech-300",
    },
    {
      icon: HandHeart,
      title: "Humanity",
      text: "Behind every transaction is a person: a child who needs a meal tonight, an adult who needs a safe place to sleep.",
      tone: "from-hope-400/20 to-transparent text-hope-300",
    },
    {
      icon: Eye,
      title: "Transparency",
      text: "Every on-chain donation address is public. Anyone can independently view incoming transactions on a block explorer.",
      tone: "from-aura-400/20 to-transparent text-aura-400",
    },
  ];
  return (
    <section id="mission" aria-labelledby="mission-title" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-end gap-10 lg:grid-cols-2">
          <SectionHeading id="mission-title" eyebrow="Our Mission" title="Where code meets" accent="compassion." center={false}>
            We believe modern technology should serve the people society too often overlooks. Haven Fund exists to turn
            digital value into real-world dignity — food, shelter, clothing, education and essential support for street
            children and homeless people.
          </SectionHeading>
          <blockquote className="reveal glass relative mb-12 rounded-3xl p-7 md:mb-16">
            <span className="absolute -top-6 left-6 font-display text-8xl leading-none text-hope-400/40">“</span>
            <p className="font-display text-2xl italic leading-snug text-white md:text-3xl">
              Technology is only as meaningful as the humanity it serves.
            </p>
            <footer className="mt-4 text-sm text-slate-400">— The Haven Fund principle</footer>
          </blockquote>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {pillars.map((p, i) => (
            <article
              key={p.title}
              className="reveal glass group relative overflow-hidden rounded-3xl p-7 transition duration-500 hover:-translate-y-1.5"
              style={{ transitionDelay: `${i * 90}ms` }}
            >
              <div className={`absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gradient-to-br ${p.tone} blur-2xl transition duration-700 group-hover:scale-150`} />
              <div className={`relative mb-6 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/5 ${p.tone.split(" ").pop()}`}>
                <p.icon className="h-6 w-6" />
              </div>
              <h3 className="relative text-xl font-bold text-white">{p.title}</h3>
              <p className="relative mt-3 leading-relaxed text-slate-400">{p.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------- Who We Help -------------------------------- */
export function WhoWeHelp() {
  const groups = [
    {
      icon: Baby,
      title: "Street Children",
      text: "Children and young people living or working on the streets, often without stable care, safety or access to school.",
      needs: ["Nutritious meals", "Safe shelter", "School access", "Protection & care"],
      accent: "hope",
    },
    {
      icon: Users,
      title: "Homeless People",
      text: "Individuals and families without secure housing, facing exposure, hunger and isolation every day.",
      needs: ["Warm clothing", "Hygiene kits", "Emergency shelter", "Essential support"],
      accent: "tech",
    },
  ];
  const needs = [
    { icon: Apple, label: "Food" },
    { icon: Home, label: "Shelter" },
    { icon: Shirt, label: "Clothing" },
    { icon: BookOpen, label: "Education" },
    { icon: Stethoscope, label: "Essential care" },
    { icon: Globe2, label: "Dignity" },
  ];
  return (
    <section id="who-we-help" aria-labelledby="help-title" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading id="help-title" eyebrow="Who We Help" title="Every person deserves" accent="a safe tomorrow.">
          Our focus is on two groups who face the harshest conditions in our cities.
        </SectionHeading>
        <div className="grid gap-6 lg:grid-cols-2">
          {groups.map((g, i) => (
            <article
              key={g.title}
              className="reveal glass group relative overflow-hidden rounded-[2rem] p-8 md:p-10"
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              <div
                className={`absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent ${g.accent === "hope" ? "via-hope-400/70" : "via-tech-400/70"} to-transparent`}
              />
              <div className="flex items-start gap-5">
                <div
                  className={`grid h-14 w-14 shrink-0 place-items-center rounded-2xl ${g.accent === "hope" ? "bg-hope-400/15 text-hope-300" : "bg-tech-400/15 text-tech-300"}`}
                >
                  <g.icon className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="font-display text-3xl text-white md:text-4xl">{g.title}</h3>
                  <p className="mt-3 leading-relaxed text-slate-400">{g.text}</p>
                </div>
              </div>
              <ul className="mt-8 grid grid-cols-2 gap-3">
                {g.needs.map((n) => (
                  <li key={n} className="flex items-center gap-2 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5 text-sm text-slate-200">
                    <span className={`h-1.5 w-1.5 rounded-full ${g.accent === "hope" ? "bg-hope-400" : "bg-tech-400"}`} />
                    {n}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className="reveal mt-8 grid grid-cols-3 gap-3 sm:grid-cols-6">
          {needs.map((n) => (
            <div key={n.label} className="glass group flex flex-col items-center gap-2 rounded-2xl p-4 text-center transition hover:-translate-y-1 hover:border-hope-400/30">
              <n.icon className="h-6 w-6 text-hope-300 transition group-hover:scale-110" />
              <span className="text-xs font-semibold text-slate-300">{n.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------- How It Works -------------------------------- */
export function HowItWorks() {
  const steps = [
    { icon: Wallet, title: "Choose a crypto", text: "Pick from Bitcoin, Lightning, Ethereum, USDT, USDC, Solana or Litecoin — each shown with its exact network." },
    { icon: QrCode, title: "Scan or copy", text: "Scan the QR code with your wallet app, or copy the address with one tap. No account or sign-up needed." },
    { icon: Send, title: "Send from your wallet", text: "Confirm the network matches, review the fee your wallet shows, and send. The transfer is recorded on-chain." },
    { icon: BadgeCheck, title: "Get your reference", text: "Optionally paste your transaction ID to receive a donation reference and a public explorer link." },
  ];
  return (
    <section id="how-it-works" aria-labelledby="how-title" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading id="how-title" eyebrow="How Donations Work" title="Four steps." accent="Zero complexity.">
          Designed so that someone who has never used cryptocurrency can give with confidence.
        </SectionHeading>
        <ol className="relative grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <div aria-hidden className="absolute left-0 right-0 top-[52px] hidden h-px bg-gradient-to-r from-hope-400/0 via-hope-400/40 to-tech-400/0 lg:block" />
          {steps.map((s, i) => (
            <li
              key={s.title}
              className="reveal glass group relative rounded-3xl p-7 transition duration-500 hover:-translate-y-1.5 hover:border-white/20"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="relative mb-6 flex items-center justify-between">
                <div className="relative grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-hope-400/25 to-tech-400/10 text-hope-200 ring-1 ring-white/10">
                  <s.icon className="h-6 w-6" />
                </div>
                <span className="font-display text-5xl text-white/10 transition group-hover:text-hope-400/30">0{i + 1}</span>
              </div>
              <h3 className="text-lg font-bold text-white">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
