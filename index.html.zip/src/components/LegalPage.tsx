import type { ReactNode } from "react";
import { ArrowLeft } from "lucide-react";
import { ORG } from "../config/org";
import { Placeholder } from "./ui";

type Section = { h: string; p: (string | ReactNode)[] };

const contact = (
  <a href={ORG.emailHref} className="text-hope-300 underline">{ORG.email}</a>
);

const PRIVACY: Section[] = [
  {
    h: "1. Overview",
    p: [
      `This Privacy Policy explains how ${ORG.name} (“we”, “us”) handles information when you visit this website or donate cryptocurrency. We aim to collect as little personal data as possible.`,
    ],
  },
  {
    h: "2. Donations and blockchain data",
    p: [
      "No account or personal details are required to donate. Cryptocurrency transactions are recorded on public blockchains by design. Anyone — including us — can view public transaction data such as sending address, amount and time. We cannot alter or delete blockchain records.",
      "Lightning Network payments are settled off-chain and are not published on a public explorer.",
    ],
  },
  {
    h: "3. Information you choose to provide",
    p: [
      "Transaction IDs: if you enter a transaction ID on the confirmation step and no backend is connected, it is saved in your browser’s local storage on your device only if you allowed “Remember my preferences”. If a backend is connected, it is transmitted over HTTPS to help reconcile donations.",
      "Contact form, updates sign-up and donation emails: when you send a message, subscribe, or choose to email a donation reference/receipt, the details you entered are delivered to our inbox (havenfund@hotmail.com) through the FormSubmit email-forwarding service (formsubmit.co). If you ask for a copy of your receipt, it is sent to the email address you provide. We use these details solely to respond and to acknowledge your donation. We do not sell or rent your data.",
      "Blockchain verification: if you click “Verify on blockchain”, your public transaction ID is looked up on public blockchain services (mempool.space, litecoinspace.org, publicnode.com, trongrid.io). These services can see your IP address. Transaction data is public by nature.",
      "Haven AI: messages you type into the assistant are processed to generate answers. In local mode they stay in your browser. If an AI provider is connected, messages are sent to that provider via our server to produce a response. Please do not share sensitive personal information, seed phrases or private keys.",
      "Voice questions (optional, off until you allow it): if you use the microphone, speech is converted to text by your browser’s built-in speech recognition. Depending on your browser, audio may be processed by the browser vendor’s speech service. Read-aloud replies use your device’s text-to-speech. Microphone access is only requested when you tap the microphone button, and you can revoke it at any time in your browser settings.",
    ],
  },
  {
    h: "4. Third-party services",
    p: [
      "Live price estimates (optional, off until you allow it): your browser requests public price data from CoinGecko, which can see your IP address. Block-explorer links and our Facebook page open third-party websites with their own privacy policies. Fonts are self-hosted — no requests are made to Google Fonts or other font services.",
    ],
  },
  {
    h: "5. Cookies, local storage and your controls",
    p: [
      "This website sets no cookies and uses no analytics, advertising or tracking technologies.",
      "Strictly necessary: your privacy choice is stored in local storage (key “havenfund.consent”) so we don’t ask again.",
      "Optional — “Remember my preferences”: Haven AI chat history for the current browser session, your chosen language, and donation references on this device. Turning this off immediately deletes this data from your device.",
      "Optional — “Live price estimates” and “Voice questions”, described above.",
      "Optional features are off until you choose. If your browser sends a Global Privacy Control signal, they remain off unless you enable them. You can change your choices at any time using “Privacy settings” in the website footer.",
    ],
  },
  {
    h: "6. Your rights",
    p: [
      "Depending on your jurisdiction, you may have rights to access, correct or delete personal data we hold (such as contact-form messages). Contact us to make a request: ",
      contact,
    ],
  },
  {
    h: "7. Security",
    p: [
      "The website is served over HTTPS with security headers (including a Content-Security-Policy and HSTS). Network requests are restricted to HTTPS services and never include cookies for third parties. We never ask for seed phrases, private keys or passwords. See our Security & Trust page for details.",
    ],
  },
  {
    h: "8. Children’s privacy",
    p: ["We never publish names, images or stories of children without informed consent from an appropriate guardian and with identities protected."],
  },
  { h: "9. Changes & contact", p: [`Contact: ${ORG.name}, ${ORG.address}. We may update this policy. The latest version is always published on this page. Last updated: ${ORG.lastUpdated}.`] },
];

const TERMS: Section[] = [
  {
    h: "1. Acceptance",
    p: [`By using this website you agree to these Terms & Conditions. If you do not agree, please do not use the site.`],
  },
  {
    h: "2. Nature of donations",
    p: [
      "Donations are voluntary gifts made in cryptocurrency. Donations are intended to support food, shelter, clothing, education and essential support for street children and homeless people. We do not guarantee any specific allocation of an individual donation.",
      "Donations are generally non-refundable because blockchain transactions are irreversible.",
    ],
  },
  {
    h: "3. Your responsibility when sending crypto",
    p: [
      "You are responsible for selecting the correct cryptocurrency, network, address and amount. Funds sent using an unsupported asset or network, or to an incorrect address, may be permanently lost and cannot be recovered by us.",
      "Network fees are set by the blockchain and paid by the sender.",
    ],
  },
  {
    h: "4. Price estimates",
    p: ["USD values shown are estimates from third-party data and may be inaccurate or delayed. They are provided for convenience only."],
  },
  {
    h: "5. Haven AI assistant",
    p: [
      "Haven AI is an automated AI assistant, not a human. Its answers are for general information only and are not financial, legal or tax advice. It may make mistakes; always verify important information, especially wallet addresses and networks, directly in the donation panel.",
    ],
  },
  {
    h: "6. Tax",
    p: ["Tax-deductibility has not been confirmed. This website does not issue tax receipts. Consult a qualified professional regarding your tax obligations."],
  },
  {
    h: "7. Compliance",
    p: [
      "You agree not to use this website for unlawful purposes, including money laundering or sanctions evasion. We may decline or report donations where required by applicable law.",
    ],
  },
  {
    h: "8. Organization information",
    p: [
      "Organization name, registration and jurisdiction: ",
      <Placeholder key="org">to be provided</Placeholder>,
      " — until published, no registered-charity status is claimed.",
    ],
  },
  {
    h: "9. Limitation of liability",
    p: ["The website is provided “as is”. To the extent permitted by law, we are not liable for losses arising from user error, third-party services, network failures or market volatility."],
  },
  { h: "10. Contact", p: ["Questions about these terms: ", contact] },
];

export default function LegalPage({ kind }: { kind: "privacy" | "terms" }) {
  const isPrivacy = kind === "privacy";
  const sections = isPrivacy ? PRIVACY : TERMS;

  return (
    <article className="mx-auto max-w-3xl px-5 pb-20 pt-32 sm:px-8 md:pt-40" aria-labelledby="legal-title">
      <a href="#/" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-white">
        <ArrowLeft className="h-4 w-4" /> Back to home
      </a>
      <p className="mt-8 text-xs font-semibold uppercase tracking-[0.22em] text-hope-300">Legal</p>
      <h1 id="legal-title" className="mt-3 font-display text-5xl text-white md:text-6xl">
        {isPrivacy ? "Privacy Policy" : "Terms & Conditions"}
      </h1>
      <p className="mt-4 text-sm text-slate-500">Last updated: {ORG.lastUpdated}. This document is a template and should be reviewed by qualified legal counsel before launch.</p>
      <div className="glass mt-10 space-y-8 rounded-[2rem] p-6 md:p-10">
        {sections.map((s) => (
          <section key={s.h}>
            <h2 className="text-lg font-bold text-white">{s.h}</h2>
            <div className="mt-3 space-y-3 leading-relaxed text-slate-400">
              {s.p.every((x) => typeof x === "string") ? (
                s.p.map((x, i) => <p key={i}>{x}</p>)
              ) : (
                <p>{s.p.map((x, i) => <span key={i}>{x}</span>)}</p>
              )}
            </div>
          </section>
        ))}
      </div>
    </article>
  );
}
