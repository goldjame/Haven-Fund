import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, Download, ExternalLink, Mail, Info, Loader2, Lock, RefreshCw, ShieldCheck, Sparkles,
} from "lucide-react";
import { ASSETS, getAsset, isValidAddress, type AssetId, type CryptoAsset } from "../../config/wallets";
import { ConsentRequiredError, fetchPrices, type PriceMap } from "../../services/prices";
import { setConsent, useConsent } from "../../services/consent";
import { SecureConnection } from "../security/SecureConnection";
import { SectionHeading } from "../ui";
import { useRoute } from "../../router";
import { CryptoIcon } from "../CryptoIcon";
import { cn } from "../../utils/cn";
import { StepSend } from "./StepSend";
import { Row, NavRow, PrimaryBtn, GhostBtn } from "./controls";
import { CAMPAIGNS, getCampaign, type CampaignId } from "../../config/campaigns";
import { StepConfirm, type Confirmation } from "./StepConfirm";
import { VerificationBadge } from "./VerificationBadge";
import { downloadReceipt, receiptText } from "../../services/receipt";
import { mailtoLink } from "../../services/email";

const STEPS = ["Choose crypto", "Amount", "Send", "Confirm"];
const PRESETS = [10, 25, 50, 100, 250, 500];

export type AmountMode = "usd" | "crypto";

export default function DonateSection({ showHeading = true }: { showHeading?: boolean }) {
  const [step, setStep] = useState(0);
  const [assetId, setAssetId] = useState<AssetId>("USDT");
  const asset = getAsset(assetId);

  const [mode, setMode] = useState<AmountMode>("usd");
  const [raw, setRaw] = useState("50");
  const [prices, setPrices] = useState<PriceMap | null>(null);
  const [priceState, setPriceState] = useState<"idle" | "loading" | "error" | "ok" | "consent">("idle");
  const consent = useConsent();
  const [done, setDone] = useState<Confirmation | null>(null);
  const route = useRoute();
  const validCampaign = (id: string | null): id is CampaignId => !!id && CAMPAIGNS.some((c) => c.id === id);
  const [campaignId, setCampaignId] = useState<CampaignId>(() => {
    const q = route.query.get("campaign");
    return validCampaign(q) ? q : "general";
  });
  const campaign = getCampaign(campaignId);

  // Links such as #/donate?campaign=food pre-select a campaign.
  useEffect(() => {
    const q = route.query.get("campaign");
    if (validCampaign(q)) {
      setCampaignId(q);
      setDone(null);
      setStep(0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route.nonce]);

  const loadPrices = () => {
    const ac = new AbortController();
    setPriceState("loading");
    fetchPrices(ac.signal)
      .then((p) => {
        setPrices(p);
        setPriceState("ok");
      })
      .catch((e) => {
        if (e?.name === "AbortError") return;
        setPriceState(e instanceof ConsentRequiredError ? "consent" : "error");
      });
    return ac;
  };

  useEffect(() => {
    if (step !== 1 || priceState === "ok") return;
    const ac = loadPrices();
    return () => ac.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, consent.prices]);

  // If prices fail, switch to crypto-unit entry so the donor can still proceed.
  useEffect(() => {
    if ((priceState === "error" || priceState === "consent") && mode === "usd") setMode("crypto");
  }, [priceState, mode]);

  const price = prices?.[asset.priceId];
  const parsed = Number(raw.replace(",", "."));
  const amountError = useMemo(() => {
    if (raw.trim() === "") return null; // amount is optional
    if (!/^\d*[.,]?\d*$/.test(raw.trim())) return "Please enter numbers only.";
    if (!Number.isFinite(parsed) || parsed <= 0) return "Amount must be greater than zero.";
    if (mode === "usd" && parsed > 1_000_000) return "For very large donations, please contact the team first.";
    const decimals = raw.split(/[.,]/)[1]?.length ?? 0;
    const maxDec = mode === "usd" ? 2 : asset.decimals === 0 ? 0 : 9;
    if (decimals > maxDec) return maxDec === 0 ? `${asset.unit} must be a whole number.` : `Up to ${maxDec} decimal places allowed.`;
    return null;
  }, [raw, parsed, mode, asset]);

  const cryptoAmount = useMemo(() => {
    if (raw.trim() === "" || amountError) return undefined;
    if (mode === "crypto") return parsed;
    if (!price) return undefined;
    const v = (parsed / price) * asset.unitsPerCoin;
    return Number(v.toFixed(asset.decimals));
  }, [raw, amountError, mode, parsed, price, asset]);

  const usdEstimate = useMemo(() => {
    if (raw.trim() === "" || amountError) return undefined;
    if (mode === "usd") return parsed;
    if (!price) return undefined;
    return (parsed / asset.unitsPerCoin) * price;
  }, [raw, amountError, mode, parsed, price, asset]);

  const addressOk = isValidAddress(asset);

  const reset = () => {
    setDone(null);
    setStep(0);
    setRaw("50");
    setMode(priceState === "error" || priceState === "consent" ? "crypto" : "usd");
  };

  const go = (n: number) => {
    setStep(n);
    document.getElementById("donate-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="donate" aria-labelledby={showHeading ? "donate-title" : undefined} aria-label={showHeading ? undefined : "Donation panel"} className={cn("relative scroll-mt-24", showHeading ? "py-24 md:py-32" : "pb-20 md:pb-28")}>
      <div aria-hidden className="absolute inset-x-0 top-1/3 -z-10 mx-auto h-[500px] max-w-4xl rounded-full bg-hope-500/10 blur-[140px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        {showHeading && (
          <SectionHeading id="donate-title" eyebrow="Crypto Donations" title="Give in minutes." accent="Change a life.">
            Choose a cryptocurrency, scan the QR code, and send. We guide you through every step — even if it’s your first
            time using crypto.
          </SectionHeading>
        )}

        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          {/* Main panel */}
          <div id="donate-panel" className="reveal glass-strong border-gradient relative scroll-mt-28 overflow-hidden rounded-[2rem] p-5 sm:p-8">
            <SecureConnection />
            {done ? (
              <DonationComplete conf={done} onReset={reset} />
            ) : (
              <>
                <Stepper step={step} onJump={(n) => n < step && go(n)} />

                <div className="mt-8" key={step}>
                  {step === 0 && (
                    <div className="animate-fade-up">
                      <div className="mb-8">
                        <label htmlFor="campaign" className="text-sm font-semibold text-slate-300">Campaign <span className="font-normal text-slate-500">(optional)</span></label>
                        <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="Choose campaign" id="campaign">
                          {CAMPAIGNS.map((c) => (
                            <button
                              key={c.id}
                              type="button"
                              role="radio"
                              aria-checked={campaignId === c.id}
                              onClick={() => setCampaignId(c.id)}
                              className={cn(
                                "rounded-full border px-3.5 py-2 text-xs font-semibold transition",
                                campaignId === c.id
                                  ? "border-hope-400/60 bg-hope-400/15 text-hope-100"
                                  : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25"
                              )}
                            >
                              {c.name}
                            </button>
                          ))}
                        </div>
                        <p className="mt-2 text-xs text-slate-500">{campaign.description}</p>
                      </div>
                      <h3 className="text-xl font-bold text-white">Which cryptocurrency would you like to give?</h3>
                      <p className="mt-1 text-sm text-slate-400">
                        New to crypto? Stablecoins (<span className="text-slate-200">USDT</span>, <span className="text-slate-200">USDC</span>) track the US dollar and are often the easiest.
                      </p>
                      <div role="radiogroup" aria-label="Select cryptocurrency" className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
                        {ASSETS.map((a) => (
                          <AssetOption key={a.id} asset={a} selected={a.id === assetId} onSelect={() => setAssetId(a.id)} />
                        ))}
                      </div>
                      <NavRow>
                        <span />
                        <PrimaryBtn onClick={() => go(1)}>
                          Continue with {asset.symbol} <ArrowRight className="h-4 w-4" />
                        </PrimaryBtn>
                      </NavRow>
                    </div>
                  )}

                  {step === 1 && (
                    <div className="animate-fade-up">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="text-xl font-bold text-white">How much would you like to give?</h3>
                          <p className="mt-1 text-sm text-slate-400">Optional — it helps you plan and pre-fills compatible wallets. You can also decide inside your wallet.</p>
                        </div>
                        <div className="inline-flex rounded-xl border border-white/10 bg-white/5 p-1 text-xs font-semibold" role="tablist" aria-label="Amount currency">
                          <button
                            role="tab"
                            aria-selected={mode === "usd"}
                            disabled={priceState === "error" || priceState === "consent"}
                            onClick={() => { setMode("usd"); setRaw("50"); }}
                            className={cn("rounded-lg px-3 py-1.5 transition disabled:opacity-40", mode === "usd" ? "bg-white text-ink-950" : "text-slate-300")}
                          >
                            USD
                          </button>
                          <button
                            role="tab"
                            aria-selected={mode === "crypto"}
                            onClick={() => { setMode("crypto"); setRaw(""); }}
                            className={cn("rounded-lg px-3 py-1.5 transition", mode === "crypto" ? "bg-white text-ink-950" : "text-slate-300")}
                          >
                            {asset.unit}
                          </button>
                        </div>
                      </div>

                      {mode === "usd" && (
                        <div className="mt-6 grid grid-cols-3 gap-2 sm:grid-cols-6">
                          {PRESETS.map((p) => (
                            <button
                              key={p}
                              type="button"
                              onClick={() => setRaw(String(p))}
                              aria-pressed={parsed === p}
                              className={cn(
                                "rounded-xl border py-3 text-sm font-bold transition",
                                parsed === p
                                  ? "border-hope-400/60 bg-hope-400/15 text-hope-200 shadow-[0_0_24px_-6px_rgba(245,180,60,0.6)]"
                                  : "border-white/10 bg-white/[0.03] text-slate-200 hover:border-white/25"
                              )}
                            >
                              ${p}
                            </button>
                          ))}
                        </div>
                      )}

                      <label htmlFor="amount" className="mt-6 block text-sm font-semibold text-slate-300">
                        {mode === "usd" ? "Custom amount (USD)" : `Amount in ${asset.unit}`}
                      </label>
                      <div className={cn("mt-2 flex items-center rounded-2xl border bg-ink-900/60 px-4 transition focus-within:border-hope-400/60", amountError ? "border-rose-400/60" : "border-white/10")}>
                        <span className="text-lg font-semibold text-slate-500">{mode === "usd" ? "$" : ""}</span>
                        <input
                          id="amount"
                          inputMode="decimal"
                          autoComplete="off"
                          value={raw}
                          onChange={(e) => setRaw(e.target.value.slice(0, 18))}
                          placeholder={mode === "usd" ? "50" : asset.decimals === 0 ? "10000" : "0.00"}
                          aria-invalid={!!amountError}
                          aria-describedby="amount-help"
                          className="w-full bg-transparent px-2 py-4 text-2xl font-bold text-white outline-none placeholder:text-slate-600"
                        />
                        <span className="text-sm font-semibold text-slate-400">{mode === "usd" ? "USD" : asset.unit}</span>
                      </div>
                      <div id="amount-help" className="mt-2 min-h-6 text-sm" aria-live="polite">
                        {amountError ? (
                          <span className="text-rose-300">{amountError}</span>
                        ) : priceState === "loading" ? (
                          <span className="inline-flex items-center gap-2 text-slate-400"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Fetching live estimate…</span>
                        ) : priceState === "consent" ? (
                          <span className="inline-flex flex-wrap items-center gap-2 text-slate-300">
                            Live USD estimates are off (they use the CoinGecko price service).
                            <button onClick={() => setConsent({ prices: true })} className="font-semibold text-hope-300 underline underline-offset-2">Turn on estimates</button>
                          </span>
                        ) : priceState === "error" ? (
                          <span className="inline-flex flex-wrap items-center gap-2 text-amber-200">
                            <AlertTriangle className="h-3.5 w-3.5" /> Live price unavailable — enter the amount in {asset.unit}.
                            <button onClick={loadPrices} className="inline-flex items-center gap-1 underline underline-offset-2"><RefreshCw className="h-3 w-3" /> Retry</button>
                          </span>
                        ) : mode === "usd" && cryptoAmount !== undefined ? (
                          <span className="text-slate-300">≈ <strong className="text-white">{cryptoAmount.toLocaleString(undefined, { maximumFractionDigits: asset.decimals })} {asset.unit}</strong> <span className="text-slate-500">(estimate at current price)</span></span>
                        ) : mode === "crypto" && usdEstimate !== undefined ? (
                          <span className="text-slate-300">≈ <strong className="text-white">${usdEstimate.toLocaleString(undefined, { maximumFractionDigits: 2 })}</strong> <span className="text-slate-500">(estimate)</span></span>
                        ) : (
                          <span className="text-slate-500">Leave empty to choose the amount in your wallet.</span>
                        )}
                      </div>

                      <div className="mt-4 flex items-start gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-sm text-slate-400">
                        <Info className="mt-0.5 h-4 w-4 shrink-0 text-tech-300" />
                        Prices move constantly. Estimates come from a public price feed and are for guidance only — the amount you send in your wallet is what counts.
                      </div>

                      <NavRow>
                        <GhostBtn onClick={() => go(0)}><ArrowLeft className="h-4 w-4" /> Back</GhostBtn>
                        <PrimaryBtn disabled={!!amountError} onClick={() => go(2)}>
                          Show wallet address <ArrowRight className="h-4 w-4" />
                        </PrimaryBtn>
                      </NavRow>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="animate-fade-up">
                      {addressOk ? (
                        <StepSend asset={asset} amount={cryptoAmount} usdEstimate={usdEstimate} onBack={() => go(1)} onNext={() => go(3)} />
                      ) : (
                        <div role="alert" className="rounded-2xl border border-rose-400/40 bg-rose-400/10 p-6 text-rose-100">
                          <p className="flex items-center gap-2 font-bold"><AlertTriangle className="h-5 w-5" /> Address safety check failed</p>
                          <p className="mt-2 text-sm">The configured {asset.name} address did not pass format validation, so it has been hidden to protect you. Please choose another cryptocurrency or contact the team.</p>
                          <GhostBtn className="mt-4" onClick={() => go(0)}><ArrowLeft className="h-4 w-4" /> Choose another</GhostBtn>
                        </div>
                      )}
                    </div>
                  )}

                  {step === 3 && (
                    <div className="animate-fade-up">
                      <StepConfirm asset={asset} campaignId={campaignId} amount={cryptoAmount} usdEstimate={usdEstimate} onBack={() => go(2)} onDone={setDone} />
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Summary side */}
          <aside className="reveal space-y-4 lg:sticky lg:top-28 lg:self-start" aria-label="Donation summary">
            <div className="glass rounded-3xl p-6">
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">Your donation</p>
              <div className="mt-4 flex items-center gap-3">
                <CryptoIcon id={asset.id} size={44} />
                <div>
                  <p className="font-bold text-white">{asset.name}</p>
                  <p className="text-sm text-slate-400">{asset.symbol}</p>
                </div>
              </div>
              <dl className="mt-5 space-y-3 text-sm">
                <Row k="Campaign"><span className="font-semibold text-hope-200">{campaign.name}</span></Row>
                <Row k="Network"><span className="rounded-md bg-tech-400/10 px-2 py-0.5 font-semibold text-tech-200">{asset.network}</span></Row>
                <Row k="Amount">
                  {cryptoAmount !== undefined ? (
                    <span className="font-semibold text-white">{cryptoAmount.toLocaleString(undefined, { maximumFractionDigits: asset.decimals })} {asset.unit}</span>
                  ) : (
                    <span className="text-slate-500">Set in wallet</span>
                  )}
                </Row>
                {usdEstimate !== undefined && <Row k="≈ USD"><span className="text-slate-300">${usdEstimate.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span></Row>}
                <Row k="Address check">
                  {addressOk ? (
                    <span className="inline-flex items-center gap-1 font-semibold text-emerald-300"><ShieldCheck className="h-4 w-4" /> Format valid</span>
                  ) : (
                    <span className="text-rose-300">Failed</span>
                  )}
                </Row>
              </dl>
            </div>
            <div className="glass rounded-3xl p-6">
              <p className="flex items-center gap-2 text-sm font-bold text-white"><Lock className="h-4 w-4 text-hope-300" /> Safety first</p>
              <ul className="mt-3 space-y-2.5 text-sm text-slate-400">
                <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> Match the coin <em>and</em> the network.</li>
                <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> Check the first & last 6 characters after pasting.</li>
                <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> We never ask for seed phrases or private keys.</li>
                <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> Crypto transfers can’t be reversed.</li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ subcomponents ------------------------------ */

function Stepper({ step, onJump }: { step: number; onJump: (n: number) => void }) {
  return (
    <ol className="flex items-center gap-2" aria-label="Donation progress">
      {STEPS.map((s, i) => (
        <li key={s} className="flex flex-1 items-center gap-2">
          <button
            type="button"
            onClick={() => onJump(i)}
            disabled={i >= step}
            aria-current={i === step ? "step" : undefined}
            className="group flex items-center gap-2 disabled:cursor-default"
          >
            <span
              className={cn(
                "grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-bold transition",
                i < step && "bg-emerald-400/20 text-emerald-300 ring-1 ring-emerald-400/40",
                i === step && "bg-hope-400 text-ink-950 shadow-[0_0_20px_-2px_rgba(245,180,60,0.8)]",
                i > step && "bg-white/5 text-slate-500 ring-1 ring-white/10"
              )}
            >
              {i < step ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
            </span>
            <span className={cn("hidden text-xs font-semibold sm:block", i === step ? "text-white" : "text-slate-500")}>{s}</span>
          </button>
          {i < STEPS.length - 1 && <span className={cn("h-px flex-1 transition", i < step ? "bg-emerald-400/40" : "bg-white/10")} />}
        </li>
      ))}
    </ol>
  );
}

function AssetOption({ asset, selected, onSelect }: { asset: CryptoAsset; selected: boolean; onSelect: () => void }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        "group relative flex items-center gap-4 rounded-2xl border p-4 text-left transition duration-300",
        selected
          ? "border-hope-400/60 bg-hope-400/[0.08] shadow-[0_0_40px_-12px_rgba(245,180,60,0.6)]"
          : "border-white/10 bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.05]"
      )}
    >
      <CryptoIcon id={asset.id} size={40} className="shrink-0 transition group-hover:scale-110" />
      <div className="min-w-0 flex-1">
        <p className="flex flex-wrap items-center gap-2 font-bold text-white">
          {asset.name}
          {asset.beginnerFriendly && (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-300">
              <Sparkles className="h-2.5 w-2.5" /> Beginner friendly
            </span>
          )}
        </p>
        <p className="truncate text-xs text-slate-400">
          {asset.symbol} · <span className="text-tech-200">{asset.network}</span>
        </p>
      </div>
      <span
        className={cn(
          "grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition",
          selected ? "border-hope-400 bg-hope-400" : "border-white/25"
        )}
      >
        {selected && <span className="h-2 w-2 rounded-full bg-ink-950" />}
      </span>
    </button>
  );
}

function DonationComplete({ conf, onReset }: { conf: Confirmation; onReset: () => void }) {
  const asset = getAsset(conf.assetId);
  const v = conf.verification;
  const receipt = { reference: conf.reference, assetId: conf.assetId, campaignId: conf.campaignId, amount: conf.amount, txHash: conf.txHash, verification: v, createdAt: conf.createdAt };
  const headline =
    v?.status === "confirmed" ? ["Donation", "confirmed."] :
    v?.status === "pending" ? ["Donation found —", "confirming."] :
    ["Thank you for", "giving hope."];
  const bad = v && (v.status === "wrong_recipient" || v.status === "failed");
  return (
    <div className="animate-fade-up py-4 text-center" role="status" aria-live="polite" data-testid="donation-complete">
      <div className="relative mx-auto grid h-24 w-24 place-items-center">
        <span className={cn("absolute inset-0 rounded-full animate-pulse-ring", bad ? "bg-amber-400/30" : "bg-emerald-400/30")} />
        <span className={cn("absolute inset-2 rounded-full animate-pulse-ring [animation-delay:0.6s]", bad ? "bg-amber-400/20" : "bg-emerald-400/20")} />
        <span className={cn("relative grid h-20 w-20 place-items-center rounded-full shadow-[0_0_60px_-10px_rgba(52,211,153,0.9)]", bad ? "bg-gradient-to-br from-amber-300 to-rose-400" : "bg-gradient-to-br from-emerald-300 to-tech-400")}>
          {bad ? <AlertTriangle className="h-10 w-10 text-ink-950" /> : <CheckCircle2 className="h-10 w-10 text-ink-950" />}
        </span>
      </div>
      <h3 className="mt-8 font-display text-4xl text-white sm:text-5xl" data-testid="complete-title">
        {bad ? <>Please check <em className="text-gradient italic">your transaction.</em></> : <>{headline[0]} <em className="text-gradient italic">{headline[1]}</em></>}
      </h3>
      <p className="mx-auto mt-4 max-w-lg text-slate-400">
        {v?.status === "confirmed"
          ? `Haven Fund’s ${asset.network} address has received your donation. Your generosity is intended to help provide food, shelter, clothing, education and essential support.`
          : bad
            ? "Your reference was created, but the blockchain check found a problem (see below). If you believe this is a mistake, contact us with your reference and transaction ID."
            : `Once your transaction is confirmed on the ${asset.network} network, it will be publicly visible. Your generosity is intended to help provide food, shelter, clothing, education and essential support.`}
      </p>

      {v && <div className="mx-auto mt-6 max-w-md"><VerificationBadge result={v} /></div>}

      <dl className="mx-auto mt-6 max-w-md space-y-3 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-left text-sm">
        <Row k="Reference"><span className="font-mono font-semibold text-hope-200" data-testid="reference">{conf.reference}</span></Row>
        {conf.campaignId && <Row k="Campaign"><span className="text-white">{getCampaign(conf.campaignId).name}</span></Row>}
        <Row k="Asset"><span className="text-white">{asset.name} ({asset.symbol})</span></Row>
        <Row k="Network"><span className="text-white">{asset.network}</span></Row>
        {conf.amount !== undefined && (
          <Row k="Amount"><span className="text-white">{conf.amount.toLocaleString(undefined, { maximumFractionDigits: asset.decimals })} {asset.unit}</span></Row>
        )}
        {conf.txHash && (
          <div>
            <dt className="text-slate-500">Transaction</dt>
            <dd className="mono-break mt-1 font-mono text-xs text-slate-300">{conf.txHash}</dd>
          </div>
        )}
        <Row k="Email">
          <span className="text-slate-300" data-testid="email-status" data-status={conf.email}>
            {conf.email === "sent" ? (conf.copySent ? `Receipt sent to ${conf.donorEmail}` : "Haven Fund notified") : conf.email === "failed" ? "Couldn’t send — use the buttons below" : "Not sent"}
          </span>
        </Row>
      </dl>

      <div className="mx-auto mt-6 grid max-w-md gap-2 sm:grid-cols-2">
        <button type="button" onClick={() => downloadReceipt(receipt)} data-testid="download-receipt" className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-semibold text-white hover:bg-white/10">
          <Download className="h-4 w-4" /> Download receipt
        </button>
        <a
          href={mailtoLink(conf.donorEmail ?? "", `My Haven Fund donation receipt ${conf.reference}`, receiptText(receipt))}
          data-testid="email-receipt"
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-semibold text-white hover:bg-white/10"
        >
          <Mail className="h-4 w-4" /> Email receipt to myself
        </a>
        {conf.txHash && asset.explorerTx && (
          <a
            href={asset.explorerTx(conf.txHash)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-semibold text-white hover:bg-white/10 sm:col-span-2"
          >
            View on block explorer <ExternalLink className="h-4 w-4" />
          </a>
        )}
      </div>
      <div className="mt-6"><PrimaryBtn onClick={onReset}>Make another donation</PrimaryBtn></div>
      <p className="mt-6 text-xs text-slate-500">Keep your reference and transaction ID for your records. This is an acknowledgement, not a tax receipt.</p>
    </div>
  );
}

