/** Newsletter subscription — custom backend (VITE_NEWSLETTER_ENDPOINT) or email to the team. */
import { secureFetch } from "./http";
import { emailEnabled, sendEmail } from "./email";

const ENDPOINT = import.meta.env.VITE_NEWSLETTER_ENDPOINT;

export const newsletterConfigured = Boolean(ENDPOINT) || emailEnabled;

export async function subscribe(email: string): Promise<{ mode: "sent" | "demo" }> {
  if (ENDPOINT) {
    const res = await secureFetch(ENDPOINT, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email }),
    });
    if (!res.ok) throw new Error(`Subscription failed (${res.status}). Please try again.`);
    return { mode: "sent" };
  }
  if (emailEnabled) {
    await sendEmail({ subject: "Haven Fund — new updates subscriber", replyTo: email, fields: { Email: email, Request: "Please add me to Haven Fund updates" } });
    return { mode: "sent" };
  }
  await new Promise((r) => setTimeout(r, 800));
  return { mode: "demo" };
}
