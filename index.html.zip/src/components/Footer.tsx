import { Cookie, Lock, Mail, MapPin, Phone, Sparkles } from "lucide-react";
import { openPrivacySettings } from "../services/consent";
import { ASSETS } from "../config/wallets";
import { ORG } from "../config/org";
import { to } from "../router";
import { CryptoIcon } from "./CryptoIcon";
import { Logo } from "./Navbar";
import { FacebookIcon } from "./ui";
import { openHavenAI } from "./AssistantSection";

export default function Footer() {
  const cols = [
    {
      title: "Explore",
      links: [
        ["Home", to("home")],
        ["About Us", to("about")],
        ["Our Causes & Campaigns", to("campaigns")],
        ["How Donations Help", to("impact")],
        ["Updates & News", to("updates")],
      ],
    },
    {
      title: "Give",
      links: [
        ["Donate Crypto", to("donate")],
        ["How It Works", to("donate", "how-it-works")],
        ["Official Wallets", to("impact", "transparency")],
        ["Stories of Hope", to("impact", "stories")],
        ["FAQ", to("contact", "faq")],
      ],
    },
    {
      title: "Support",
      links: [
        ["Contact Us", to("contact")],
        ["Security & Trust", to("security")],
        ["Privacy Policy", to("privacy")],
        ["Terms & Conditions", to("terms")],
      ],
    },
  ];
  return (
    <footer className="relative mt-10 border-t border-white/5 bg-ink-950/70 backdrop-blur">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-400">
              {ORG.tagline}. A cryptocurrency-only donation platform supporting street children and homeless people.
            </p>
            <ul className="mt-6 space-y-2.5 text-sm">
              <li><a href={ORG.emailHref} className="inline-flex items-center gap-2 text-slate-300 hover:text-hope-300"><Mail className="h-4 w-4 text-hope-300" /> {ORG.email}</a></li>
              <li><a href={ORG.phoneHref} className="inline-flex items-center gap-2 text-slate-300 hover:text-hope-300" dir="ltr"><Phone className="h-4 w-4 text-hope-300" /> {ORG.phone}</a></li>
              <li className="flex items-start gap-2 text-slate-300"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-hope-300" /> {ORG.address}</li>
              <li><a href={ORG.facebook} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-slate-300 hover:text-hope-300"><FacebookIcon className="h-4 w-4 text-[#6ea8ff]" /> Haven Fund on Facebook</a></li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-2">
              {ASSETS.map((a) => (
                <span key={a.id} title={`${a.name} · ${a.network}`} className="rounded-full bg-white/5 p-1.5 ring-1 ring-white/10">
                  <CryptoIcon id={a.id} size={22} />
                </span>
              ))}
            </div>
          </div>
          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {cols.map((c) => (
              <div key={c.title}>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">{c.title}</p>
                <ul className="mt-4 space-y-2.5">
                  {c.links.map(([l, h]) => (
                    <li key={l}>
                      <a href={h} className="text-sm text-slate-300 transition hover:text-hope-300">{l}</a>
                    </li>
                  ))}
                  {c.title === "Support" && (
                    <li>
                      <button onClick={openPrivacySettings} className="inline-flex items-center gap-1.5 text-sm text-slate-300 transition hover:text-hope-300">
                        <Cookie className="h-3.5 w-3.5" /> Privacy settings
                      </button>
                    </li>
                  )}
                  {c.title === "Support" && (
                    <li>
                      <button onClick={() => openHavenAI()} className="inline-flex items-center gap-1.5 text-sm text-tech-300 transition hover:text-tech-100">
                        <Sparkles className="h-3.5 w-3.5" /> Ask Haven AI
                      </button>
                    </li>
                  )}
                </ul>
              </div>
            ))}
          </nav>
        </div>
        <div className="mt-12 border-t border-white/5 pt-8 text-xs leading-relaxed text-slate-500">
          <p>
            Disclaimer: Cryptocurrency transactions are irreversible. Always verify the asset, network and address before sending.
            USD values are estimates only. This website does not provide financial, legal or tax advice and does not issue tax receipts.
            No certifications, registrations or partnerships are claimed unless explicitly published with verifiable details.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <p>© {new Date().getFullYear()} {ORG.name}. All rights reserved.</p>
            <a href={to("security")} className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/[0.06] px-3 py-1 text-emerald-300 hover:bg-emerald-400/10">
              <Lock className="h-3 w-3" /> HTTPS · No tracking cookies · Privacy controls
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
