import { Lock, ShieldAlert, Wrench } from "lucide-react";

/**
 * Shows donors whether they are on a secure (HTTPS) connection before they
 * copy any wallet address — a visible safeguard against tampering.
 */
export function connectionState(): "secure" | "dev" | "insecure" {
  if (typeof window === "undefined") return "secure";
  const local = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(window.location.hostname);
  if (window.location.protocol === "https:" && window.isSecureContext) return "secure";
  if (local || window.location.protocol === "file:") return "dev";
  return "insecure";
}

export function SecureConnection() {
  const state = connectionState();
  if (state === "secure")
    return (
      <p className="mb-5 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-emerald-400/20 bg-emerald-400/[0.06] px-3.5 py-2 text-xs text-emerald-200">
        <span className="inline-flex items-center gap-1.5 font-semibold"><Lock className="h-3.5 w-3.5" /> Secure HTTPS connection</span>
        <span className="text-emerald-200/70">Encrypted · addresses format-verified · no card data collected</span>
      </p>
    );
  if (state === "dev")
    return (
      <p className="mb-5 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2 text-xs text-slate-400">
        <Wrench className="h-3.5 w-3.5" /> Local preview — the live website must be served over HTTPS.
      </p>
    );
  return (
    <div role="alert" className="mb-5 rounded-xl border border-rose-400/40 bg-rose-400/10 p-4 text-sm text-rose-100">
      <p className="flex items-center gap-2 font-bold"><ShieldAlert className="h-4 w-4" /> This connection is not secure</p>
      <p className="mt-1 text-rose-100/80">
        Do not copy wallet addresses from an insecure page. Reload the site using <strong>https://</strong> before donating.
      </p>
    </div>
  );
}
