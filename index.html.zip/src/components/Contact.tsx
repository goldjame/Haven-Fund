import { useRef, useState, type FormEvent } from "react";
import { AlertTriangle, CheckCircle2, ExternalLink, Loader2, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { FacebookIcon } from "./ui";
import { SectionHeading } from "./ui";
import { ORG } from "../config/org";
import { sendContact, type ContactPayload } from "../services/contact";
import { EmailNotActivatedError, mailtoLink } from "../services/email";
import { openHavenAI } from "./AssistantSection";
import { cn } from "../utils/cn";
import { to } from "../router";

type Errors = Partial<Record<keyof ContactPayload | "consent", string>>;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const TOPICS = ["General question", "Donation help", "Transparency & reports", "Partnership enquiry", "Media", "Other"];

function validate(v: ContactPayload, consent: boolean): Errors {
  const e: Errors = {};
  if (v.name.trim().length < 2) e.name = "Please enter your name (at least 2 characters).";
  if (!EMAIL_RE.test(v.email.trim())) e.email = "Please enter a valid email address.";
  if (!TOPICS.includes(v.topic)) e.topic = "Please choose a topic.";
  if (v.message.trim().length < 20) e.message = "Please write at least 20 characters.";
  if (v.message.length > 2000) e.message = "Please keep your message under 2000 characters.";
  if (!consent) e.consent = "Please agree so we can reply to you.";
  return e;
}

export default function Contact({ showHeading = true }: { showHeading?: boolean }) {
  const [v, setV] = useState<ContactPayload>({ name: "", email: "", topic: "", message: "" });
  const [consent, setConsent] = useState(false);
  const [hp, setHp] = useState(""); // honeypot
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "sent" | "demo" | "error">("idle");
  const [err, setErr] = useState("");
  const [fallback, setFallback] = useState<string | null>(null);
  // Abuse protection: bots submit instantly and repeatedly.
  const mountedAt = useRef(Date.now());
  const lastSentAt = useRef(0);
  const COOLDOWN_MS = 60_000;

  const set = (k: keyof ContactPayload) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setV((p) => ({ ...p, [k]: e.target.value }));
    if (errors[k]) setErrors((p) => ({ ...p, [k]: undefined }));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (hp) return; // honeypot filled → bot
    const found = validate(v, consent);
    setErrors(found);
    if (Object.keys(found).length) {
      document.getElementById(`c-${Object.keys(found)[0]}`)?.focus();
      return;
    }
    if (Date.now() - mountedAt.current < 3000) {
      setErr("That was quick! Please take a moment to review your message, then send again.");
      setState("error");
      return;
    }
    const wait = COOLDOWN_MS - (Date.now() - lastSentAt.current);
    if (wait > 0) {
      setErr(`Please wait ${Math.ceil(wait / 1000)} seconds before sending another message.`);
      setState("error");
      return;
    }
    setState("loading");
    setFallback(null);
    try {
      const { mode } = await sendContact({ ...v, name: v.name.trim(), email: v.email.trim(), message: v.message.trim() });
      lastSentAt.current = Date.now();
      setState(mode);
      setV({ name: "", email: "", topic: "", message: "" });
      setConsent(false);
    } catch (e) {
      if (e instanceof EmailNotActivatedError) console.warn("[Haven Fund] Email form not activated yet — check havenfund@hotmail.com for the FormSubmit activation link.");
      setErr("We couldn’t send your message automatically. Please use the button below to email us directly — your message is already filled in.");
      setFallback(mailtoLink(ORG.email, `Haven Fund website — ${v.topic || "Message"} — from ${v.name}`, `${v.message}\n\n— ${v.name} (${v.email})`));
      setState("error");
    }
  };

  const field = "w-full rounded-2xl border bg-ink-900/60 px-4 py-3.5 text-white outline-none transition placeholder:text-slate-600 focus:border-hope-400/60";

  return (
    <section id="contact" aria-labelledby={showHeading ? "contact-title" : undefined} aria-label={showHeading ? undefined : "Contact details and form"} className={cn("relative scroll-mt-24", showHeading ? "py-24 md:py-32" : "pb-16 md:pb-24")}>
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        {showHeading && (
        <SectionHeading id="contact-title" eyebrow="Contact" title="Let’s talk" accent="about hope.">
          Questions about donating, transparency or getting involved? We’d love to hear from you.
        </SectionHeading>
        )}
        <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="reveal space-y-4">
            <a href={ORG.emailHref} className="glass group flex items-center gap-4 rounded-3xl p-5 transition hover:border-hope-400/40">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-hope-400/15 text-hope-300"><Mail className="h-5 w-5" /></span>
              <span className="min-w-0">
                <span className="block text-xs text-slate-500">Email</span>
                <span className="block truncate font-semibold text-white group-hover:text-hope-200">{ORG.email}</span>
              </span>
            </a>
            <a href={ORG.phoneHref} className="glass group flex items-center gap-4 rounded-3xl p-5 transition hover:border-hope-400/40">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-400/15 text-emerald-300"><Phone className="h-5 w-5" /></span>
              <span>
                <span className="block text-xs text-slate-500">Phone</span>
                <span className="block font-semibold text-white group-hover:text-hope-200" dir="ltr">{ORG.phone}</span>
              </span>
            </a>
            <a href={ORG.facebook} target="_blank" rel="noopener noreferrer" className="glass group flex items-center gap-4 rounded-3xl p-5 transition hover:border-[#1877F2]/50">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1877F2]/20 text-[#6ea8ff]"><FacebookIcon className="h-5 w-5" /></span>
              <span className="mr-auto">
                <span className="block text-xs text-slate-500">Facebook</span>
                <span className="block font-semibold text-white group-hover:text-hope-200">Follow Haven Fund</span>
              </span>
              <ExternalLink className="h-4 w-4 text-slate-500" />
            </a>
            <a href={ORG.mapsUrl} target="_blank" rel="noopener noreferrer" className="glass group flex items-center gap-4 rounded-3xl p-5 transition hover:border-hope-400/40">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-aura-400/15 text-aura-400"><MapPin className="h-5 w-5" /></span>
              <span className="mr-auto">
                <span className="block text-xs text-slate-500">Postal address</span>
                <span className="block font-semibold text-white group-hover:text-hope-200">{ORG.addressParts.street}</span>
                <span className="block text-sm text-slate-400">{ORG.addressParts.city}, {ORG.addressParts.region} {ORG.addressParts.postalCode}</span>
              </span>
              <ExternalLink className="h-4 w-4 text-slate-500" />
            </a>
            <button onClick={() => openHavenAI()} className="glass group flex w-full items-center gap-4 rounded-3xl p-6 text-left transition hover:border-tech-400/40">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-tech-400 to-aura-500 text-white">
                <MessageCircle className="h-5 w-5" />
              </span>
              <span>
                <span className="block font-bold text-white">Need a quick answer?</span>
                <span className="text-sm text-slate-400">Ask Haven AI — text or voice, 5 languages.</span>
              </span>
            </button>
          </div>

          <div className="reveal glass-strong rounded-[2rem] p-6 md:p-8">
            {state === "sent" || state === "demo" ? (
              <div className="animate-fade-up py-10 text-center" role="status">
                <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-400" />
                <h3 className="mt-5 font-display text-4xl text-white">Message received.</h3>
                <p className="mx-auto mt-3 max-w-md text-slate-400">
                  {state === "sent"
                    ? "Thank you for reaching out. The team will get back to you as soon as possible."
                    : "Your form was validated successfully. Demo mode: no contact backend is connected yet, so the message was not transmitted. Connect VITE_CONTACT_ENDPOINT to enable delivery."}
                </p>
                <button onClick={() => setState("idle")} className="mt-6 rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10">
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2" data-testid="contact-form">
                <div className="hidden" aria-hidden>
                  <label>Leave empty<input tabIndex={-1} autoComplete="off" value={hp} onChange={(e) => setHp(e.target.value)} /></label>
                </div>
                <Field id="c-name" label="Your name" error={errors.name}>
                  <input id="c-name" autoComplete="name" value={v.name} onChange={set("name")} maxLength={80} aria-invalid={!!errors.name} aria-describedby="c-name-err" className={cn(field, errors.name ? "border-rose-400/60" : "border-white/10")} placeholder="Jane Doe" />
                </Field>
                <Field id="c-email" label="Email" error={errors.email}>
                  <input id="c-email" type="email" autoComplete="email" value={v.email} onChange={set("email")} maxLength={120} aria-invalid={!!errors.email} aria-describedby="c-email-err" className={cn(field, errors.email ? "border-rose-400/60" : "border-white/10")} placeholder="you@example.com" />
                </Field>
                <Field id="c-topic" label="Topic" error={errors.topic} full>
                  <select id="c-topic" value={v.topic} onChange={set("topic")} aria-invalid={!!errors.topic} aria-describedby="c-topic-err" className={cn(field, "appearance-none", errors.topic ? "border-rose-400/60" : "border-white/10", !v.topic && "text-slate-500")}>
                    <option value="" disabled>Choose a topic…</option>
                    {TOPICS.map((t) => <option key={t} value={t} className="bg-ink-900 text-white">{t}</option>)}
                  </select>
                </Field>
                <Field id="c-message" label="Message" error={errors.message} full hint={`${v.message.length}/2000`}>
                  <textarea id="c-message" rows={5} value={v.message} onChange={set("message")} maxLength={2000} aria-invalid={!!errors.message} aria-describedby="c-message-err" className={cn(field, "resize-y", errors.message ? "border-rose-400/60" : "border-white/10")} placeholder="How can we help?" />
                </Field>
                <div className="sm:col-span-2">
                  <label className="flex cursor-pointer items-start gap-3 text-sm text-slate-400">
                    <input id="c-consent" type="checkbox" checked={consent} onChange={(e) => { setConsent(e.target.checked); setErrors((p) => ({ ...p, consent: undefined })); }} className="mt-0.5 h-4 w-4 accent-amber-400" />
                    <span>I agree that my details will be used only to respond to this message, as described in the <a href={to("privacy")} className="text-hope-300 underline">Privacy Policy</a>.</span>
                  </label>
                  {errors.consent && <p className="mt-1.5 text-sm text-rose-300">{errors.consent}</p>}
                  <p className="mt-3 text-xs text-slate-500">Never share seed phrases, private keys or passwords in this form.</p>
                </div>
                {state === "error" && (
                  <p role="alert" className="flex gap-2 rounded-2xl border border-rose-400/40 bg-rose-400/10 p-4 text-sm text-rose-100 sm:col-span-2">
                    <AlertTriangle className="h-4 w-4 shrink-0" />
                    <span>
                      {err}
                      {fallback && (
                        <a href={fallback} className="mt-3 flex w-fit items-center gap-2 rounded-xl bg-white px-4 py-2.5 font-bold text-ink-950">
                          <Mail className="h-4 w-4" /> Email us directly
                        </a>
                      )}
                    </span>
                  </p>
                )}
                <div className="sm:col-span-2">
                  <button type="submit" disabled={state === "loading"} className="btn-shine inline-flex w-full items-center justify-center gap-2 rounded-xl px-6 py-4 font-bold text-ink-950 transition hover:scale-[1.01] disabled:opacity-60 sm:w-auto">
                    {state === "loading" ? <><Loader2 className="h-5 w-5 animate-spin" /> Sending…</> : <><Send className="h-5 w-5" /> Send message</>}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({ id, label, error, children, full, hint }: { id: string; label: string; error?: string; children: React.ReactNode; full?: boolean; hint?: string }) {
  return (
    <div className={cn(full && "sm:col-span-2")}>
      <div className="mb-2 flex items-center justify-between">
        <label htmlFor={id} className="text-sm font-semibold text-slate-300">{label}</label>
        {hint && <span className="text-xs text-slate-500">{hint}</span>}
      </div>
      {children}
      <p id={`${id}-err`} className="mt-1.5 min-h-0 text-sm text-rose-300" aria-live="polite">{error}</p>
    </div>
  );
}
