/**
 * Haven AI grounded knowledge base.
 * Every answer is written from verified site content only.
 * Nothing here contains statistics, beneficiary numbers, projects,
 * partners or financial figures — by design.
 */
import { ASSETS } from "../../config/wallets";
import { CAMPAIGNS, type CampaignId } from "../../config/campaigns";
import { ORG } from "../../config/org";
import type { L, Lang } from "./i18n";

export interface Intent {
  id: string;
  /** Keywords (lowercase, accents removed) per language */
  keys: L<string[]>;
  text: L<string> | ((lang: Lang) => string);
  actions?: { key: string; href: string }[];
}

const assetList = () => ASSETS.map((a) => `• **${a.name}** (${a.symbol}) — ${a.network}`).join("\n");

export const CAMPAIGN_SHORT: Record<CampaignId, L> = {
  general: { en: "where it’s needed most", es: "donde más se necesita", fr: "là où c’est le plus nécessaire", pt: "onde é mais necessário", ar: "حيث تشتد الحاجة" },
  food: { en: "food & clean water", es: "comida y agua potable", fr: "nourriture et eau potable", pt: "comida e água potável", ar: "الطعام والمياه النظيفة" },
  shelter: { en: "shelter & safe nights", es: "refugio y noches seguras", fr: "abri et nuits en sécurité", pt: "abrigo e noites seguras", ar: "المأوى وليالٍ آمنة" },
  warmth: { en: "clothing & hygiene", es: "ropa e higiene", fr: "vêtements et hygiène", pt: "roupas e higiene", ar: "الملابس والنظافة الشخصية" },
  education: { en: "education for street children", es: "educación para niños de la calle", fr: "éducation des enfants des rues", pt: "educação para crianças de rua", ar: "تعليم أطفال الشوارع" },
  care: { en: "basic care & essential support", es: "cuidado básico y apoyo esencial", fr: "soins de base et soutien essentiel", pt: "cuidados básicos e apoio essencial", ar: "الرعاية الأساسية والدعم الضروري" },
};

const campaignList = (l: Lang) => CAMPAIGNS.map((c) => `• **${c.name}** — ${CAMPAIGN_SHORT[c.id][l]}`).join("\n");

export const INTENTS: Intent[] = [
  {
    id: "identity",
    keys: {
      en: ["are you human", "are you a human", "human", "a person", "real person", "are you a bot", "are you ai", "who are you", "your name", "robot", "talking to a"],
      es: ["eres humano", "humano", "eres una persona", "persona real", "eres un bot", "quien eres", "eres ia", "robot"],
      fr: ["etes-vous humain", "humain", "etes vous humain", "es-tu humain", "vraie personne", "qui etes-vous", "qui es-tu", "robot"],
      pt: ["voce e humano", "humano", "e humano", "pessoa real", "voce e um bot", "quem e voce", "robo"],
      ar: ["هل أنت إنسان", "إنسان", "انت انسان", "شخص حقيقي", "من أنت", "روبوت", "هل انت"],
    },
    text: {
      en: "I’m **Haven AI**, an AI assistant — not a human. I can answer questions about Haven Fund, explain crypto donations and campaigns, and help you navigate the site.\n\nFor anything that needs a person, please contact the team.",
      es: "Soy **Haven AI**, un asistente de inteligencia artificial — no una persona. Puedo responder preguntas sobre Haven Fund, explicar las donaciones en cripto y las campañas, y ayudarte a navegar por el sitio.\n\nSi necesitas hablar con una persona, contacta al equipo.",
      fr: "Je suis **Haven AI**, un assistant d’intelligence artificielle — pas un humain. Je peux répondre à vos questions sur Haven Fund, expliquer les dons en crypto et les campagnes, et vous guider sur le site.\n\nPour parler à une personne, contactez l’équipe.",
      pt: "Sou o **Haven AI**, um assistente de inteligência artificial — não um humano. Posso responder perguntas sobre o Haven Fund, explicar doações em cripto e campanhas, e ajudar você a navegar pelo site.\n\nPara falar com uma pessoa, entre em contato com a equipe.",
      ar: "أنا **Haven AI**، مساعد ذكاء اصطناعي — ولست إنسانًا. يمكنني الإجابة عن أسئلتك حول Haven Fund، وشرح التبرع بالعملات الرقمية والحملات، ومساعدتك في التنقل داخل الموقع.\n\nللتحدث مع شخص، يرجى التواصل مع الفريق.",
    },
    actions: [{ key: "contact", href: "#contact" }],
  },
  {
    id: "campaigns",
    keys: {
      en: ["campaign", "campaigns", "causes", "projects", "programs", "programmes", "funds available", "what can i support", "designate"],
      es: ["campana", "campanas", "causas", "proyectos", "programas"],
      fr: ["campagne", "campagnes", "causes", "projets", "programmes"],
      pt: ["campanha", "campanhas", "causas", "projetos", "programas"],
      ar: ["حملة", "حملات", "الحملات", "مشاريع", "برامج"],
    },
    text: (l) =>
      ({
        en: `Haven Fund currently offers these donation campaigns (focus areas):\n\n${campaignList(l)}\n\nAll campaigns use the same secure wallets. You can choose a campaign in the donation panel — your preference is recorded with your donation reference. Verified progress for each campaign will be published once available.`,
        es: `Haven Fund ofrece actualmente estas campañas de donación (áreas de enfoque):\n\n${campaignList(l)}\n\nTodas las campañas usan las mismas billeteras seguras. Puedes elegir una campaña en el panel de donación; tu preferencia se registra con tu referencia. El progreso verificado se publicará cuando esté disponible.`,
        fr: `Haven Fund propose actuellement ces campagnes de dons (domaines d’action) :\n\n${campaignList(l)}\n\nToutes les campagnes utilisent les mêmes portefeuilles sécurisés. Vous pouvez choisir une campagne dans le panneau de don ; votre préférence est enregistrée avec votre référence. Les progrès vérifiés seront publiés dès qu’ils seront disponibles.`,
        pt: `O Haven Fund oferece atualmente estas campanhas de doação (áreas de foco):\n\n${campaignList(l)}\n\nTodas as campanhas usam as mesmas carteiras seguras. Você pode escolher uma campanha no painel de doação; sua preferência é registrada com sua referência. O progresso verificado será publicado quando disponível.`,
        ar: `يقدّم Haven Fund حاليًا حملات التبرع التالية (مجالات التركيز):\n\n${campaignList(l)}\n\nتستخدم جميع الحملات المحافظ الآمنة نفسها. يمكنك اختيار حملة في لوحة التبرع، ويتم تسجيل اختيارك مع مرجع التبرع. سيتم نشر التقدم الموثّق لكل حملة عند توفره.`,
      })[l],
    actions: [
      { key: "campaigns", href: "#campaigns" },
      { key: "donate", href: "#donate" },
    ],
  },
  {
    id: "donate",
    keys: {
      en: ["how do i donate", "how to donate", "how can i donate", "donate", "donation process", "steps", "give", "send crypto", "how does it work"],
      es: ["como donar", "como puedo donar", "donar", "donacion", "pasos", "enviar cripto", "como funciona"],
      fr: ["comment faire un don", "comment donner", "faire un don", "donner", "don", "etapes", "comment ca marche"],
      pt: ["como doar", "como posso doar", "doar", "doacao", "passos", "enviar cripto", "como funciona"],
      ar: ["كيف أتبرع", "كيف يمكنني التبرع", "التبرع", "تبرع", "خطوات", "كيف يعمل"],
    },
    text: {
      en: "Donating takes four simple steps:\n\n1. **Choose a cryptocurrency** (and its network).\n2. **Pick an amount and campaign** — both optional.\n3. **Send** from your wallet by scanning the QR code or copying the address.\n4. **Confirm** — optionally paste your transaction ID to get a reference.\n\nAlways check that the network in your wallet matches the one shown on the donation card.",
      es: "Donar tiene cuatro pasos sencillos:\n\n1. **Elige una criptomoneda** (y su red).\n2. **Elige un monto y una campaña** — ambos opcionales.\n3. **Envía** desde tu billetera escaneando el código QR o copiando la dirección.\n4. **Confirma** — si quieres, pega el ID de tu transacción para obtener una referencia.\n\nVerifica siempre que la red en tu billetera coincida con la indicada.",
      fr: "Faire un don se fait en quatre étapes :\n\n1. **Choisissez une cryptomonnaie** (et son réseau).\n2. **Choisissez un montant et une campagne** — facultatif.\n3. **Envoyez** depuis votre portefeuille en scannant le QR code ou en copiant l’adresse.\n4. **Confirmez** — collez éventuellement l’ID de transaction pour obtenir une référence.\n\nVérifiez toujours que le réseau de votre portefeuille correspond à celui affiché.",
      pt: "Doar leva quatro passos simples:\n\n1. **Escolha uma criptomoeda** (e sua rede).\n2. **Escolha um valor e uma campanha** — ambos opcionais.\n3. **Envie** da sua carteira escaneando o QR code ou copiando o endereço.\n4. **Confirme** — se quiser, cole o ID da transação para obter uma referência.\n\nSempre confira se a rede na sua carteira é a mesma mostrada no cartão de doação.",
      ar: "يتم التبرع في أربع خطوات بسيطة:\n\n1. **اختر عملة رقمية** (وشبكتها).\n2. **اختر المبلغ والحملة** — كلاهما اختياري.\n3. **أرسل** من محفظتك بمسح رمز QR أو نسخ العنوان.\n4. **أكّد** — يمكنك لصق معرّف المعاملة للحصول على رقم مرجعي.\n\nتأكد دائمًا من أن الشبكة في محفظتك تطابق الشبكة المعروضة.",
    },
    actions: [{ key: "donate", href: "#donate" }],
  },
  {
    id: "use",
    keys: {
      en: ["used for", "where does", "money go", "funds used", "spend", "use of funds", "allocation", "how are funds", "how is my donation used", "food", "shelter", "clothing", "education"],
      es: ["como se usan", "en que se usa", "a donde va", "uso de fondos", "destino", "comida", "refugio", "ropa", "educacion"],
      fr: ["comment les fonds", "utilises", "ou va l'argent", "ou va", "utilisation des fonds", "nourriture", "abri", "vetements", "education"],
      pt: ["como os fundos", "como sao usados", "para onde vai", "uso dos fundos", "comida", "abrigo", "roupas", "educacao"],
      ar: ["كيف تستخدم", "كيف تُستخدم", "أين تذهب", "استخدام التبرعات", "طعام", "مأوى", "ملابس", "تعليم"],
    },
    text: {
      en: "Donations are **intended** to support essentials for street children and homeless people:\n\n• Food and clean water\n• Safe shelter\n• Clothing and hygiene supplies\n• Education and learning materials\n• Access to basic care and essential support\n\nA verified allocation breakdown hasn’t been published yet. When it is, it will appear in Impact & Transparency.",
      es: "Las donaciones están **destinadas** a cubrir necesidades básicas de niños de la calle y personas sin hogar:\n\n• Comida y agua potable\n• Refugio seguro\n• Ropa e higiene\n• Educación y materiales de aprendizaje\n• Acceso a cuidado básico y apoyo esencial\n\nAún no se ha publicado un desglose verificado. Cuando exista, aparecerá en Impacto y transparencia.",
      fr: "Les dons sont **destinés** à couvrir les besoins essentiels des enfants des rues et des personnes sans abri :\n\n• Nourriture et eau potable\n• Abri sûr\n• Vêtements et hygiène\n• Éducation et fournitures scolaires\n• Accès aux soins de base et soutien essentiel\n\nAucune répartition vérifiée n’a encore été publiée. Elle apparaîtra dans la section Impact et transparence.",
      pt: "As doações são **destinadas** a apoiar necessidades essenciais de crianças de rua e pessoas em situação de rua:\n\n• Comida e água potável\n• Abrigo seguro\n• Roupas e higiene\n• Educação e materiais escolares\n• Acesso a cuidados básicos e apoio essencial\n\nAinda não foi publicada uma divisão verificada. Quando houver, aparecerá em Impacto e transparência.",
      ar: "التبرعات **مخصّصة** لدعم الاحتياجات الأساسية لأطفال الشوارع والأشخاص بلا مأوى:\n\n• الطعام والمياه النظيفة\n• المأوى الآمن\n• الملابس ومستلزمات النظافة\n• التعليم والمواد الدراسية\n• الرعاية الأساسية والدعم الضروري\n\nلم يُنشر بعد توزيع موثّق للأموال، وسيظهر في قسم الأثر والشفافية عند توفره.",
    },
    actions: [
      { key: "campaigns", href: "#campaigns" },
      { key: "transparency", href: "#transparency" },
    ],
  },
  {
    id: "supported",
    keys: {
      en: ["which crypto", "supported", "accept", "coins", "currencies", "tokens", "what crypto", "networks"],
      es: ["que monedas", "aceptan", "criptomonedas", "monedas", "redes", "tokens"],
      fr: ["quelles cryptos", "acceptez", "cryptomonnaies", "monnaies", "reseaux", "jetons"],
      pt: ["quais moedas", "aceitam", "criptomoedas", "moedas", "redes", "tokens"],
      ar: ["ما العملات", "العملات المقبولة", "تقبلون", "عملات", "الشبكات"],
    },
    text: (l) =>
      ({
        en: `We currently accept:\n\n${assetList()}\n\nHaven Fund is crypto-only — card and bank payments are not accepted.`,
        es: `Actualmente aceptamos:\n\n${assetList()}\n\nHaven Fund solo acepta criptomonedas — no se aceptan tarjetas ni transferencias bancarias.`,
        fr: `Nous acceptons actuellement :\n\n${assetList()}\n\nHaven Fund accepte uniquement les cryptomonnaies — pas de carte ni de virement bancaire.`,
        pt: `Atualmente aceitamos:\n\n${assetList()}\n\nO Haven Fund aceita apenas cripto — não aceitamos cartão nem transferência bancária.`,
        ar: `نقبل حاليًا:\n\n${assetList()}\n\nيقبل Haven Fund العملات الرقمية فقط — لا نقبل البطاقات أو التحويلات البنكية.`,
      })[l],
    actions: [
      { key: "donate", href: "#donate" },
      { key: "transparency", href: "#transparency" },
    ],
  },
  {
    id: "beginner",
    keys: {
      en: ["new to crypto", "beginner", "never used", "first time", "don't have crypto", "buy crypto", "get crypto", "exchange", "wallet app"],
      es: ["nuevo en cripto", "principiante", "primera vez", "comprar cripto", "no tengo cripto", "billetera", "exchange"],
      fr: ["debute", "debutant", "premiere fois", "acheter de la crypto", "pas de crypto", "portefeuille", "plateforme"],
      pt: ["novo em cripto", "iniciante", "primeira vez", "comprar cripto", "nao tenho cripto", "carteira", "corretora"],
      ar: ["جديد", "مبتدئ", "أول مرة", "شراء عملات", "لا أملك", "محفظة", "منصة"],
    },
    text: {
      en: "Welcome! If you’ve never used crypto:\n\n1. Get crypto from a reputable exchange or wallet app available in your country.\n2. Stablecoins like **USDT (TRC-20)** or **USDC (ERC-20)** are often easiest — they track the US dollar.\n3. Choose **Send / Withdraw**, pick the matching network, then paste our address or scan the QR code.\n4. Send a small test amount first if you’re unsure.\n\nI can’t recommend a specific exchange, and this isn’t financial advice.",
      es: "¡Bienvenido! Si nunca has usado cripto:\n\n1. Obtén cripto en un exchange o app de billetera confiable disponible en tu país.\n2. Las stablecoins como **USDT (TRC-20)** o **USDC (ERC-20)** suelen ser lo más fácil: siguen al dólar.\n3. Elige **Enviar / Retirar**, selecciona la red correcta y pega nuestra dirección o escanea el QR.\n4. Si tienes dudas, envía primero una cantidad pequeña de prueba.\n\nNo puedo recomendar un exchange específico y esto no es asesoría financiera.",
      fr: "Bienvenue ! Si vous n’avez jamais utilisé de crypto :\n\n1. Procurez-vous de la crypto via une plateforme ou une application de portefeuille fiable dans votre pays.\n2. Les stablecoins comme **USDT (TRC-20)** ou **USDC (ERC-20)** sont souvent les plus simples : ils suivent le dollar.\n3. Choisissez **Envoyer / Retirer**, sélectionnez le bon réseau, puis collez notre adresse ou scannez le QR code.\n4. En cas de doute, envoyez d’abord un petit montant test.\n\nJe ne peux pas recommander de plateforme précise, et ceci n’est pas un conseil financier.",
      pt: "Bem-vindo! Se você nunca usou cripto:\n\n1. Obtenha cripto em uma corretora ou app de carteira confiável disponível no seu país.\n2. Stablecoins como **USDT (TRC-20)** ou **USDC (ERC-20)** costumam ser mais fáceis — acompanham o dólar.\n3. Escolha **Enviar / Sacar**, selecione a rede correta e cole nosso endereço ou escaneie o QR code.\n4. Se tiver dúvidas, envie primeiro um valor pequeno de teste.\n\nNão posso recomendar uma corretora específica, e isto não é aconselhamento financeiro.",
      ar: "أهلًا بك! إذا لم تستخدم العملات الرقمية من قبل:\n\n1. احصل على العملات من منصة أو تطبيق محفظة موثوق متاح في بلدك.\n2. العملات المستقرة مثل **USDT (TRC-20)** أو **USDC (ERC-20)** هي الأسهل غالبًا لأنها تتبع الدولار.\n3. اختر **إرسال / سحب**، وحدد الشبكة المطابقة، ثم الصق عنواننا أو امسح رمز QR.\n4. أرسل مبلغًا تجريبيًا صغيرًا أولًا إذا لم تكن متأكدًا.\n\nلا يمكنني التوصية بمنصة معينة، وهذه ليست نصيحة مالية.",
    },
    actions: [{ key: "donate", href: "#donate" }],
  },
  {
    id: "network",
    keys: {
      en: ["network", "wrong network", "trc20", "trc-20", "erc20", "erc-20", "bep20", "chain", "lost", "stablecoin", "usdt", "usdc", "tether"],
      es: ["red", "red equivocada", "trc20", "trc-20", "erc20", "erc-20", "cadena", "perdido", "usdt", "usdc"],
      fr: ["reseau", "mauvais reseau", "trc20", "trc-20", "erc20", "erc-20", "chaine", "perdu", "usdt", "usdc"],
      pt: ["rede", "rede errada", "trc20", "trc-20", "erc20", "erc-20", "perdido", "usdt", "usdc"],
      ar: ["شبكة", "الشبكة", "شبكة خاطئة", "trc20", "erc20", "usdt", "usdc"],
    },
    text: {
      en: "The **network matters as much as the coin**. Our USDT address is on **TRON (TRC-20)** and our USDC address is on **Ethereum (ERC-20)**.\n\nIf you send on the wrong network, funds may be lost permanently, because blockchain transactions cannot be reversed. Always choose exactly the network shown on the donation card.",
      es: "**La red importa tanto como la moneda**. Nuestra dirección de USDT está en **TRON (TRC-20)** y la de USDC en **Ethereum (ERC-20)**.\n\nSi envías por la red equivocada, los fondos pueden perderse para siempre, porque las transacciones no se pueden revertir. Elige siempre exactamente la red indicada.",
      fr: "**Le réseau compte autant que la monnaie**. Notre adresse USDT est sur **TRON (TRC-20)** et notre adresse USDC sur **Ethereum (ERC-20)**.\n\nUn envoi sur le mauvais réseau peut entraîner une perte définitive, car les transactions sont irréversibles. Choisissez toujours exactement le réseau indiqué.",
      pt: "**A rede importa tanto quanto a moeda**. Nosso endereço de USDT está na **TRON (TRC-20)** e o de USDC na **Ethereum (ERC-20)**.\n\nSe você enviar pela rede errada, os fundos podem ser perdidos para sempre, pois transações não podem ser revertidas. Escolha sempre exatamente a rede indicada.",
      ar: "**الشبكة لا تقل أهمية عن العملة**. عنوان USDT لدينا على شبكة **TRON (TRC-20)**، وعنوان USDC على **Ethereum (ERC-20)**.\n\nإذا أرسلت عبر شبكة خاطئة فقد تضيع الأموال نهائيًا لأن المعاملات لا يمكن عكسها. اختر دائمًا الشبكة المعروضة بالضبط.",
    },
    actions: [{ key: "donate", href: "#donate" }],
  },
  {
    id: "lightning",
    keys: {
      en: ["lightning", "bolt12", "sats", "phoenix", "lno"],
      es: ["lightning", "bolt12", "sats", "relampago"],
      fr: ["lightning", "bolt12", "sats", "eclair"],
      pt: ["lightning", "bolt12", "sats", "relampago"],
      ar: ["lightning", "البرق", "bolt12", "ساتوشي"],
    },
    text: {
      en: "Our **Lightning** option uses a reusable **BOLT12 offer** (starting with `lno1…`) for near-instant, low-fee Bitcoin payments.\n\nYou’ll need a wallet that supports BOLT12 offers — for example Phoenix. If your wallet doesn’t recognise it, use the regular Bitcoin (on-chain) option.",
      es: "Nuestra opción **Lightning** usa una **oferta BOLT12** reutilizable (empieza con `lno1…`) para pagos en Bitcoin casi instantáneos y con comisiones bajas.\n\nNecesitas una billetera compatible con BOLT12, por ejemplo Phoenix. Si tu billetera no la reconoce, usa Bitcoin (on-chain).",
      fr: "Notre option **Lightning** utilise une **offre BOLT12** réutilisable (commençant par `lno1…`) pour des paiements Bitcoin quasi instantanés et peu coûteux.\n\nIl vous faut un portefeuille compatible BOLT12, par exemple Phoenix. Sinon, utilisez l’option Bitcoin (on-chain).",
      pt: "Nossa opção **Lightning** usa uma **oferta BOLT12** reutilizável (começa com `lno1…`) para pagamentos em Bitcoin quase instantâneos e com taxas baixas.\n\nVocê precisa de uma carteira compatível com BOLT12, como a Phoenix. Se não for reconhecida, use Bitcoin (on-chain).",
      ar: "يستخدم خيار **Lightning** لدينا **عرض BOLT12** قابلًا لإعادة الاستخدام (يبدأ بـ `lno1…`) لمدفوعات بيتكوين شبه فورية وبرسوم منخفضة.\n\nتحتاج إلى محفظة تدعم BOLT12 مثل Phoenix. إذا لم تتعرف محفظتك عليه، استخدم خيار بيتكوين العادي.",
    },
    actions: [{ key: "donate", href: "#donate" }],
  },
  {
    id: "fees",
    keys: {
      en: ["fee", "fees", "gas", "cost", "energy"],
      es: ["comision", "comisiones", "tarifa", "gas", "costo"],
      fr: ["frais", "gas", "cout", "commission"],
      pt: ["taxa", "taxas", "gas", "custo"],
      ar: ["رسوم", "الرسوم", "غاز", "تكلفة"],
    },
    text: {
      en: "Network fees are charged by the blockchain, not by Haven Fund, and your wallet shows them before you confirm:\n\n• **Bitcoin** — varies with demand\n• **Lightning / Solana / Litecoin** — usually very low\n• **Ethereum & USDC (ERC-20)** — gas paid in ETH\n• **USDT (TRC-20)** — needs a little TRX or energy in the sending wallet",
      es: "Las comisiones de red las cobra la blockchain, no Haven Fund, y tu billetera las muestra antes de confirmar:\n\n• **Bitcoin** — varían según la demanda\n• **Lightning / Solana / Litecoin** — normalmente muy bajas\n• **Ethereum y USDC (ERC-20)** — gas pagado en ETH\n• **USDT (TRC-20)** — requiere algo de TRX o energía",
      fr: "Les frais de réseau sont prélevés par la blockchain, pas par Haven Fund, et votre portefeuille les affiche avant confirmation :\n\n• **Bitcoin** — variables selon la demande\n• **Lightning / Solana / Litecoin** — généralement très faibles\n• **Ethereum et USDC (ERC-20)** — gas payé en ETH\n• **USDT (TRC-20)** — nécessite un peu de TRX ou d’énergie",
      pt: "As taxas de rede são cobradas pela blockchain, não pelo Haven Fund, e sua carteira as mostra antes de confirmar:\n\n• **Bitcoin** — variam conforme a demanda\n• **Lightning / Solana / Litecoin** — geralmente muito baixas\n• **Ethereum e USDC (ERC-20)** — gas pago em ETH\n• **USDT (TRC-20)** — precisa de um pouco de TRX ou energia",
      ar: "رسوم الشبكة تفرضها البلوكشين وليس Haven Fund، وتعرضها محفظتك قبل التأكيد:\n\n• **بيتكوين** — تختلف حسب الطلب\n• **Lightning / Solana / Litecoin** — منخفضة جدًا عادةً\n• **Ethereum و USDC (ERC-20)** — رسوم غاز تُدفع بـ ETH\n• **USDT (TRC-20)** — تحتاج إلى قليل من TRX أو الطاقة",
    },
  },
  {
    id: "safety",
    keys: {
      en: ["safe", "scam", "verify", "trust", "legit", "check address", "refund", "reverse", "cancel", "mistake"],
      es: ["seguro", "estafa", "verificar", "confiable", "reembolso", "revertir", "cancelar", "error"],
      fr: ["securise", "sur", "arnaque", "verifier", "fiable", "remboursement", "annuler", "erreur"],
      pt: ["seguro", "golpe", "verificar", "confiavel", "reembolso", "reverter", "cancelar", "erro"],
      ar: ["آمن", "احتيال", "تحقق", "موثوق", "استرداد", "إلغاء", "خطأ"],
    },
    text: {
      en: "Good safety habits:\n\n• Compare the **first and last 6 characters** of the address after pasting.\n• Only use addresses shown on this site.\n• Haven Fund will **never** ask for your seed phrase, private key or password.\n• Crypto transactions are **irreversible**, so refunds can’t be guaranteed — double-check before sending.\n\nEvery on-chain address can be viewed publicly from the Transparency section.",
      es: "Buenos hábitos de seguridad:\n\n• Compara los **primeros y últimos 6 caracteres** de la dirección al pegarla.\n• Usa solo direcciones mostradas en este sitio.\n• Haven Fund **nunca** te pedirá tu frase semilla, clave privada o contraseña.\n• Las transacciones son **irreversibles**, así que no se pueden garantizar reembolsos: revisa antes de enviar.",
      fr: "Bonnes pratiques de sécurité :\n\n• Comparez les **6 premiers et 6 derniers caractères** de l’adresse après l’avoir collée.\n• Utilisez uniquement les adresses affichées sur ce site.\n• Haven Fund ne vous demandera **jamais** votre phrase de récupération, clé privée ou mot de passe.\n• Les transactions sont **irréversibles** : les remboursements ne peuvent être garantis — vérifiez avant d’envoyer.",
      pt: "Bons hábitos de segurança:\n\n• Compare os **6 primeiros e 6 últimos caracteres** do endereço ao colar.\n• Use apenas endereços mostrados neste site.\n• O Haven Fund **nunca** pedirá sua frase-semente, chave privada ou senha.\n• Transações são **irreversíveis**, então reembolsos não podem ser garantidos — confira antes de enviar.",
      ar: "عادات أمان مهمة:\n\n• قارن **أول وآخر 6 أحرف** من العنوان بعد لصقه.\n• استخدم فقط العناوين المعروضة في هذا الموقع.\n• لن يطلب Haven Fund **أبدًا** عبارة الاسترداد أو المفتاح الخاص أو كلمة المرور.\n• المعاملات **غير قابلة للعكس**، لذا لا يمكن ضمان الاسترداد — تحقق قبل الإرسال.",
    },
    actions: [{ key: "transparency", href: "#transparency" }],
  },
  {
    id: "stats",
    keys: {
      en: ["how many", "statistic", "stats", "numbers", "raised", "total", "impact so far", "helped so far", "beneficiaries", "how much money"],
      es: ["cuantos", "cuantas", "estadisticas", "cifras", "recaudado", "total", "beneficiarios"],
      fr: ["combien", "statistiques", "chiffres", "collecte", "total", "beneficiaires"],
      pt: ["quantos", "quantas", "estatisticas", "numeros", "arrecadado", "total", "beneficiarios"],
      ar: ["كم", "إحصائيات", "أرقام", "المبلغ المجموع", "إجمالي", "المستفيدين"],
    },
    text: {
      en: "I don’t have verified statistics, donation totals or beneficiary numbers to share — and I won’t guess. Verified figures will appear in Impact & Transparency once published.\n\nYou can independently view each on-chain donation address on its public block explorer.",
      es: "No tengo estadísticas verificadas, totales de donaciones ni número de beneficiarios — y no voy a inventarlos. Las cifras verificadas aparecerán en Impacto y transparencia cuando se publiquen.",
      fr: "Je ne dispose d’aucune statistique vérifiée, total des dons ou nombre de bénéficiaires — et je ne ferai pas de suppositions. Les chiffres vérifiés apparaîtront dans Impact et transparence une fois publiés.",
      pt: "Não tenho estatísticas verificadas, totais de doações ou número de beneficiários — e não vou inventar. Os números verificados aparecerão em Impacto e transparência quando forem publicados.",
      ar: "لا تتوفر لديّ إحصائيات موثّقة أو إجمالي التبرعات أو عدد المستفيدين — ولن أخمّن. ستظهر الأرقام الموثّقة في قسم الأثر والشفافية عند نشرها.",
    },
    actions: [{ key: "transparency", href: "#transparency" }],
  },
  {
    id: "org",
    keys: {
      en: ["partner", "certified", "registered", "registration", "charity number", "license", "licence", "nonprofit", "tax", "receipt", "deductible"],
      es: ["socio", "certificado", "registrado", "registro", "licencia", "sin fines de lucro", "impuesto", "recibo", "deducible"],
      fr: ["partenaire", "certifie", "enregistre", "enregistrement", "licence", "association", "impot", "recu", "deductible"],
      pt: ["parceiro", "certificado", "registrado", "registro", "licenca", "sem fins lucrativos", "imposto", "recibo", "dedutivel"],
      ar: ["شريك", "شركاء", "معتمد", "مسجل", "تسجيل", "ترخيص", "ضريبة", "إيصال"],
    },
    text: {
      en: "Registration details, certifications and partnerships have not been published on this site yet — they’re marked as placeholders in the Transparency section. Tax-deductibility hasn’t been confirmed and this site doesn’t issue tax receipts; please consult a tax professional.\n\nFor official documentation, contact the team directly.",
      es: "Los datos de registro, certificaciones y alianzas aún no se han publicado — aparecen como marcadores en la sección de Transparencia. La deducibilidad fiscal no está confirmada y el sitio no emite recibos fiscales; consulta a un profesional.",
      fr: "Les informations d’enregistrement, certifications et partenariats ne sont pas encore publiés — ils apparaissent comme espaces réservés dans la section Transparence. La déductibilité fiscale n’est pas confirmée et le site n’émet pas de reçus fiscaux ; consultez un professionnel.",
      pt: "Dados de registro, certificações e parcerias ainda não foram publicados — aparecem como espaços reservados na seção de Transparência. A dedutibilidade fiscal não foi confirmada e o site não emite recibos fiscais; consulte um profissional.",
      ar: "لم تُنشر بعد بيانات التسجيل أو الشهادات أو الشراكات — وهي معروضة كحقول مؤقتة في قسم الشفافية. لم يتم تأكيد الإعفاء الضريبي ولا يصدر الموقع إيصالات ضريبية؛ يرجى استشارة مختص.",
    },
    actions: [
      { key: "transparency", href: "#transparency" },
      { key: "contact", href: "#contact" },
    ],
  },
  {
    id: "txid",
    keys: {
      en: ["transaction id", "tx hash", "txid", "hash", "reference", "confirmation"],
      es: ["id de transaccion", "hash", "referencia", "confirmacion"],
      fr: ["id de transaction", "hash", "reference", "confirmation"],
      pt: ["id da transacao", "hash", "referencia", "confirmacao"],
      ar: ["معرف المعاملة", "هاش", "مرجع", "تأكيد"],
    },
    text: {
      en: "A **transaction ID (hash)** is a unique code your wallet shows after sending. You can paste it on the confirmation step to receive a donation reference and a link to view it on a public block explorer. It’s optional.",
      es: "Un **ID de transacción (hash)** es un código único que muestra tu billetera tras enviar. Puedes pegarlo en el paso de confirmación para obtener una referencia y un enlace al explorador público. Es opcional.",
      fr: "Un **ID de transaction (hash)** est un code unique affiché par votre portefeuille après l’envoi. Collez-le à l’étape de confirmation pour obtenir une référence et un lien vers l’explorateur public. C’est facultatif.",
      pt: "Um **ID de transação (hash)** é um código único que sua carteira mostra após o envio. Cole-o na etapa de confirmação para receber uma referência e um link para o explorador público. É opcional.",
      ar: "**معرّف المعاملة (hash)** هو رمز فريد تعرضه محفظتك بعد الإرسال. يمكنك لصقه في خطوة التأكيد للحصول على رقم مرجعي ورابط لعرضها على مستكشف عام. هذا اختياري.",
    },
  },
  {
    id: "who",
    keys: {
      en: ["who do you help", "who we help", "children", "street kids", "homeless", "beneficiar"],
      es: ["a quien ayudan", "ninos", "ninos de la calle", "sin hogar", "personas sin hogar"],
      fr: ["qui aidez", "enfants", "enfants des rues", "sans abri", "sans-abri", "sdf"],
      pt: ["quem voces ajudam", "criancas", "criancas de rua", "sem-teto", "em situacao de rua", "moradores de rua"],
      ar: ["من تساعدون", "الأطفال", "أطفال الشوارع", "المشردين", "بلا مأوى"],
    },
    text: {
      en: "Haven Fund focuses on two groups:\n\n• **Street children** — young people living or working on the streets without stable care.\n• **Homeless people** — individuals and families without secure housing.\n\nSupport is intended to cover immediate needs (food, shelter, clothing) and longer-term paths (education, essential support).",
      es: "Haven Fund se enfoca en dos grupos:\n\n• **Niños de la calle** — jóvenes que viven o trabajan en la calle sin cuidado estable.\n• **Personas sin hogar** — individuos y familias sin vivienda segura.\n\nEl apoyo está destinado a necesidades inmediatas (comida, refugio, ropa) y caminos a largo plazo (educación, apoyo esencial).",
      fr: "Haven Fund se concentre sur deux groupes :\n\n• **Les enfants des rues** — jeunes vivant ou travaillant dans la rue sans soutien stable.\n• **Les personnes sans abri** — individus et familles sans logement sûr.\n\nLe soutien vise les besoins immédiats (nourriture, abri, vêtements) et le long terme (éducation, soutien essentiel).",
      pt: "O Haven Fund foca em dois grupos:\n\n• **Crianças de rua** — jovens que vivem ou trabalham nas ruas sem cuidado estável.\n• **Pessoas em situação de rua** — indivíduos e famílias sem moradia segura.\n\nO apoio é destinado a necessidades imediatas (comida, abrigo, roupas) e caminhos de longo prazo (educação, apoio essencial).",
      ar: "يركّز Haven Fund على فئتين:\n\n• **أطفال الشوارع** — صغار يعيشون أو يعملون في الشوارع دون رعاية مستقرة.\n• **الأشخاص بلا مأوى** — أفراد وعائلات بلا سكن آمن.\n\nالدعم مخصّص للاحتياجات العاجلة (الطعام، المأوى، الملابس) والمسارات طويلة الأمد (التعليم، الدعم الأساسي).",
    },
    actions: [{ key: "who", href: "#who-we-help" }],
  },
  {
    id: "about",
    keys: {
      en: ["mission", "about", "organization", "organisation", "what is haven", "haven fund", "technology with humanity"],
      es: ["mision", "sobre", "organizacion", "que es haven", "haven fund"],
      fr: ["mission", "a propos", "organisation", "qu'est-ce que haven", "haven fund"],
      pt: ["missao", "sobre", "organizacao", "o que e haven", "haven fund"],
      ar: ["مهمة", "مهمتكم", "عن", "المنظمة", "ما هو haven", "haven fund"],
    },
    text: {
      en: `**${ORG.name}** connects modern technology with humanitarian support — *${ORG.tagline}*. Cryptocurrency lets anyone, anywhere, give directly, and every on-chain donation is publicly verifiable. Donations are intended to provide food, shelter, clothing, education and essential support to street children and homeless people.`,
      es: `**${ORG.name}** une la tecnología moderna con la ayuda humanitaria — *Tecnología con Humanidad*. Las criptomonedas permiten que cualquiera done directamente desde cualquier lugar, y cada donación on-chain es verificable públicamente.`,
      fr: `**${ORG.name}** relie la technologie moderne à l’aide humanitaire — *La technologie au service de l’humanité*. La crypto permet à chacun de donner directement, de partout, et chaque don on-chain est vérifiable publiquement.`,
      pt: `**${ORG.name}** conecta tecnologia moderna e apoio humanitário — *Tecnologia com Humanidade*. As criptomoedas permitem que qualquer pessoa doe diretamente, de qualquer lugar, e cada doação on-chain é publicamente verificável.`,
      ar: `**${ORG.name}** يربط التكنولوجيا الحديثة بالدعم الإنساني — *تكنولوجيا بروح إنسانية*. تتيح العملات الرقمية لأي شخص في أي مكان التبرع مباشرة، وكل تبرع على البلوكشين قابل للتحقق علنًا.`,
    },
    actions: [{ key: "mission", href: "#mission" }],
  },
  {
    id: "contact",
    keys: {
      en: ["contact", "email", "reach", "talk to", "phone", "call", "facebook", "support team", "address", "your address", "where are you located", "where are you based", "located", "location", "office", "mail a letter"],
      es: ["contacto", "contactar", "correo", "telefono", "llamar", "facebook", "direccion", "ubicacion", "ubicados", "donde estan ubicados", "donde se encuentran", "oficina"],
      fr: ["contact", "contacter", "e-mail", "courriel", "telephone", "appeler", "facebook", "adresse", "votre adresse", "ou etes-vous situes", "situes", "bureau"],
      pt: ["contato", "contatar", "e-mail", "telefone", "ligar", "facebook", "endereco", "localizacao", "onde voces ficam", "onde fica o escritorio", "localizados", "escritorio"],
      ar: ["تواصل", "اتصال", "بريد", "هاتف", "فيسبوك", "عنوان", "العنوان", "موقع", "مكتب"],
    },
    text: (l) => {
      const d = `• ✉️ **${ORG.email}**\n• 📞 **${ORG.phone}**\n• 📍 ${ORG.address}\n• Facebook: Haven Fund`;
      return {
        en: `You can reach the Haven Fund team here:\n\n${d}\n\nOr use the contact form on this page.`,
        es: `Puedes contactar al equipo de Haven Fund aquí:\n\n${d}\n\nO usa el formulario de contacto de esta página.`,
        fr: `Vous pouvez joindre l’équipe Haven Fund ici :\n\n${d}\n\nOu utilisez le formulaire de contact de cette page.`,
        pt: `Você pode falar com a equipe do Haven Fund aqui:\n\n${d}\n\nOu use o formulário de contato desta página.`,
        ar: `يمكنك التواصل مع فريق Haven Fund عبر:\n\n${d}\n\nأو استخدم نموذج التواصل في هذه الصفحة.`,
      }[l];
    },
    actions: [
      { key: "contact", href: "#contact" },
      { key: "facebook", href: ORG.facebook },
    ],
  },
  {
    id: "navigate",
    keys: {
      en: ["navigate", "where can i find", "where is", "menu", "pages", "sections", "site map", "guide me", "show me around"],
      es: ["navegar", "donde encuentro", "donde esta", "menu", "paginas", "secciones", "guiame"],
      fr: ["naviguer", "ou trouver", "ou est", "menu", "pages", "sections", "guidez-moi"],
      pt: ["navegar", "onde encontro", "onde fica", "menu", "paginas", "secoes", "me guie"],
      ar: ["تنقل", "أين أجد", "أين", "القائمة", "الصفحات", "الأقسام", "أرشدني"],
    },
    text: {
      en: "Here are the main pages:\n\n• **Home** — overview\n• **About Us** — mission, values, who we help\n• **Campaigns** — causes you can support\n• **Donate** — the 4-step crypto donation panel\n• **How Donations Help** — intended use, official wallets, transparency\n• **Updates** — news and beginner guides\n• **Contact Us** — email, phone, Facebook and FAQ\n\nTap a button below to go there.",
      es: "Estas son las páginas principales:\n\n• **Inicio**\n• **Sobre nosotros** — misión y valores\n• **Campañas** — causas que puedes apoyar\n• **Donar** — panel de donación en 4 pasos\n• **Cómo ayudan las donaciones** — uso previsto, billeteras oficiales\n• **Novedades** — noticias y guías\n• **Contacto** — correo, teléfono, Facebook y preguntas frecuentes",
      fr: "Voici les pages principales :\n\n• **Accueil**\n• **À propos** — mission et valeurs\n• **Campagnes** — causes à soutenir\n• **Faire un don** — panneau en 4 étapes\n• **Comment les dons aident** — utilisation prévue, portefeuilles officiels\n• **Actualités** — nouvelles et guides\n• **Contact** — e-mail, téléphone, Facebook et FAQ",
      pt: "Estas são as páginas principais:\n\n• **Início**\n• **Sobre nós** — missão e valores\n• **Campanhas** — causas que você pode apoiar\n• **Doar** — painel de doação em 4 passos\n• **Como as doações ajudam** — uso previsto, carteiras oficiais\n• **Atualizações** — notícias e guias\n• **Contato** — e-mail, telefone, Facebook e perguntas frequentes",
      ar: "هذه هي الصفحات الرئيسية:\n\n• **الرئيسية**\n• **من نحن** — المهمة والقيم\n• **الحملات** — قضايا يمكنك دعمها\n• **تبرع** — لوحة التبرع من 4 خطوات\n• **كيف تساعد التبرعات** — الاستخدام المقصود والمحافظ الرسمية\n• **المستجدات** — الأخبار والأدلة\n• **تواصل معنا** — البريد والهاتف وفيسبوك والأسئلة الشائعة",
    },
    actions: [
      { key: "about", href: "#/about" },
      { key: "campaigns", href: "#/campaigns" },
      { key: "donate", href: "#/donate" },
      { key: "updates", href: "#/updates" },
    ],
  },
  {
    id: "updates",
    keys: {
      en: ["news", "updates", "blog", "latest", "announcements", "guide", "newsletter"],
      es: ["noticias", "novedades", "actualizaciones", "blog", "boletin"],
      fr: ["actualites", "nouvelles", "mises a jour", "blog", "newsletter"],
      pt: ["noticias", "novidades", "atualizacoes", "blog", "boletim"],
      ar: ["أخبار", "الأخبار", "مستجدات", "تحديثات", "مدونة", "نشرة"],
    },
    text: {
      en: "The **Updates** page shares announcements, campaign news, transparency updates and beginner guides. Only verified information is published — field updates will appear once confirmed. You can also subscribe or follow Haven Fund on Facebook.",
      es: "La página de **Novedades** comparte anuncios, noticias de campañas, transparencia y guías para principiantes. Solo se publica información verificada. También puedes suscribirte o seguir a Haven Fund en Facebook.",
      fr: "La page **Actualités** présente annonces, nouvelles des campagnes, transparence et guides pour débutants. Seules les informations vérifiées sont publiées. Vous pouvez aussi vous abonner ou suivre Haven Fund sur Facebook.",
      pt: "A página de **Atualizações** traz anúncios, notícias das campanhas, transparência e guias para iniciantes. Só publicamos informações verificadas. Você também pode se inscrever ou seguir o Haven Fund no Facebook.",
      ar: "تعرض صفحة **المستجدات** الإعلانات وأخبار الحملات وتحديثات الشفافية وأدلة المبتدئين. ننشر المعلومات الموثّقة فقط. يمكنك أيضًا الاشتراك أو متابعة Haven Fund على فيسبوك.",
    },
    actions: [
      { key: "updates", href: "#/updates" },
      { key: "facebook", href: "https://www.facebook.com/share/1DZA9K4PpQ/" },
    ],
  },
  {
    id: "language",
    keys: {
      en: ["language", "languages", "voice", "speak", "microphone", "translate"],
      es: ["idioma", "idiomas", "voz", "hablar", "microfono"],
      fr: ["langue", "langues", "voix", "parler", "micro"],
      pt: ["idioma", "idiomas", "voz", "falar", "microfone"],
      ar: ["لغة", "اللغات", "صوت", "تحدث", "ميكروفون"],
    },
    text: {
      en: "I understand **English, Español, Français, Português and العربية**. I detect your language automatically, or you can choose one from the language menu.\n\nTo ask by **voice**, tap the microphone and speak — your browser converts speech to text. Tap **Listen** on any reply to hear it read aloud.",
      es: "Entiendo **English, Español, Français, Português y العربية**. Detecto tu idioma automáticamente o puedes elegirlo en el menú.\n\nPara preguntar por **voz**, toca el micrófono y habla. Toca **Escuchar** en cualquier respuesta para oírla.",
      fr: "Je comprends **English, Español, Français, Português et العربية**. Je détecte votre langue automatiquement, ou choisissez-la dans le menu.\n\nPour poser une question **à voix haute**, touchez le micro et parlez. Touchez **Écouter** pour entendre une réponse.",
      pt: "Eu entendo **English, Español, Français, Português e العربية**. Detecto seu idioma automaticamente ou você pode escolher no menu.\n\nPara perguntar por **voz**, toque no microfone e fale. Toque em **Ouvir** em qualquer resposta para escutá-la.",
      ar: "أفهم **English وEspañol وFrançais وPortuguês والعربية**. أكتشف لغتك تلقائيًا، أو يمكنك اختيارها من قائمة اللغات.\n\nللسؤال **بالصوت**، اضغط على الميكروفون وتحدث. اضغط **استماع** لسماع أي رد.",
    },
  },
  {
    id: "legal",
    keys: {
      en: ["privacy", "data", "cookies", "terms", "legal", "disclaimer"],
      es: ["privacidad", "datos", "cookies", "terminos", "legal"],
      fr: ["confidentialite", "donnees", "cookies", "conditions", "mentions legales"],
      pt: ["privacidade", "dados", "cookies", "termos", "legal"],
      ar: ["الخصوصية", "البيانات", "الشروط", "قانوني"],
    },
    text: {
      en: "No account is needed to donate and we don’t ask for personal data to give. Blockchain transactions are public by nature. See the Privacy Policy and Terms & Conditions for details.",
      es: "No necesitas cuenta para donar ni pedimos datos personales. Las transacciones en blockchain son públicas por naturaleza. Consulta la Política de privacidad y los Términos de uso.",
      fr: "Aucun compte n’est nécessaire pour donner et nous ne demandons pas de données personnelles. Les transactions blockchain sont publiques par nature. Consultez la Politique de confidentialité et les Conditions d’utilisation.",
      pt: "Não é preciso conta para doar e não pedimos dados pessoais. Transações em blockchain são públicas por natureza. Veja a Política de privacidade e os Termos de uso.",
      ar: "لا تحتاج إلى حساب للتبرع ولا نطلب بيانات شخصية. معاملات البلوكشين علنية بطبيعتها. راجع سياسة الخصوصية وشروط الاستخدام.",
    },
    actions: [
      { key: "privacy", href: "#/privacy" },
      { key: "terms", href: "#/terms" },
    ],
  },
  {
    id: "security",
    keys: {
      en: ["security", "secure website", "website secure", "site secure", "is this site secure", "is this website secure", "secure", "https", "ssl", "hacked", "phishing", "fake site", "privacy settings", "cookies", "tracking"],
      es: ["seguridad", "sitio seguro", "es seguro este sitio", "https", "ssl", "phishing", "sitio falso", "cookies", "rastreo", "configuracion de privacidad"],
      fr: ["securite", "site securise", "https", "ssl", "hameconnage", "faux site", "cookies", "suivi", "parametres de confidentialite"],
      pt: ["seguranca", "site seguro", "https", "ssl", "phishing", "site falso", "cookies", "rastreamento", "configuracoes de privacidade"],
      ar: ["الأمان", "أمان", "https", "تصيد", "موقع مزيف", "ملفات تعريف", "تتبع", "إعدادات الخصوصية"],
    },
    text: {
      en: "Haven Fund protects donors with:\n\n• **HTTPS encryption** and strict security headers\n• **Wallet address format checks** before any address is shown\n• **No card data** — donations go wallet-to-wallet\n• **No tracking cookies or analytics** — optional features need your permission\n\nWe will **never** DM you a different address or ask for your seed phrase. You can change privacy settings any time from the footer.",
      es: "Haven Fund protege a los donantes con:\n\n• **Cifrado HTTPS** y cabeceras de seguridad estrictas\n• **Verificación del formato** de cada dirección\n• **Sin datos de tarjeta** — de billetera a billetera\n• **Sin cookies de rastreo ni analíticas**\n\n**Nunca** te enviaremos otra dirección por mensaje ni pediremos tu frase semilla.",
      fr: "Haven Fund protège les donateurs avec :\n\n• **Chiffrement HTTPS** et en-têtes de sécurité stricts\n• **Vérification du format** de chaque adresse\n• **Aucune donnée de carte** — de portefeuille à portefeuille\n• **Aucun cookie de suivi ni analytique**\n\nNous ne vous enverrons **jamais** une autre adresse par message et ne demanderons jamais votre phrase de récupération.",
      pt: "O Haven Fund protege os doadores com:\n\n• **Criptografia HTTPS** e cabeçalhos de segurança rígidos\n• **Verificação do formato** de cada endereço\n• **Nenhum dado de cartão** — de carteira para carteira\n• **Sem cookies de rastreamento nem análises**\n\n**Nunca** enviaremos outro endereço por mensagem nem pediremos sua frase-semente.",
      ar: "يحمي Haven Fund المتبرعين عبر:\n\n• **تشفير HTTPS** وترويسات أمان صارمة\n• **التحقق من صيغة** كل عنوان محفظة\n• **لا بيانات بطاقات** — من محفظة إلى محفظة\n• **لا ملفات تتبع ولا تحليلات**\n\nلن نرسل إليك **أبدًا** عنوانًا مختلفًا في رسالة خاصة ولن نطلب عبارة الاسترداد.",
    },
    actions: [
      { key: "security", href: "#/security" },
      { key: "privacy", href: "#/privacy" },
    ],
  },
  {
    id: "greeting",
    keys: {
      en: ["hello", "hi", "hey", "good morning", "good evening"],
      es: ["hola", "buenos dias", "buenas tardes", "buenas noches"],
      fr: ["bonjour", "salut", "bonsoir", "coucou"],
      pt: ["ola", "oi", "bom dia", "boa tarde", "boa noite"],
      ar: ["مرحبا", "مرحبًا", "السلام عليكم", "أهلا", "اهلا", "صباح الخير", "مساء الخير"],
    },
    text: {
      en: "Hello, and thank you for being here. I’m Haven AI — an AI assistant. I can help you donate with crypto, explain our campaigns, networks and fees, or show you around. What would you like to know?",
      es: "Hola, gracias por estar aquí. Soy Haven AI, un asistente de IA. Puedo ayudarte a donar con cripto, explicarte nuestras campañas, redes y comisiones, o guiarte por el sitio. ¿Qué te gustaría saber?",
      fr: "Bonjour et merci d’être là. Je suis Haven AI, un assistant IA. Je peux vous aider à donner en crypto, expliquer nos campagnes, réseaux et frais, ou vous guider sur le site. Que souhaitez-vous savoir ?",
      pt: "Olá, obrigado por estar aqui. Sou o Haven AI, um assistente de IA. Posso ajudar você a doar com cripto, explicar nossas campanhas, redes e taxas, ou guiar você pelo site. O que você gostaria de saber?",
      ar: "مرحبًا، وشكرًا لوجودك هنا. أنا Haven AI، مساعد ذكاء اصطناعي. يمكنني مساعدتك في التبرع بالعملات الرقمية، وشرح حملاتنا والشبكات والرسوم، أو إرشادك في الموقع. ماذا تود أن تعرف؟",
    },
  },
  {
    id: "thanks",
    keys: {
      en: ["thank", "thanks", "appreciate"],
      es: ["gracias"],
      fr: ["merci"],
      pt: ["obrigado", "obrigada"],
      ar: ["شكرا", "شكرًا"],
    },
    text: {
      en: "Thank you for caring. Every act of kindness matters. Is there anything else I can help with?",
      es: "Gracias por tu generosidad. Cada gesto cuenta. ¿Puedo ayudarte con algo más?",
      fr: "Merci pour votre générosité. Chaque geste compte. Puis-je vous aider pour autre chose ?",
      pt: "Obrigado pelo seu carinho. Cada gesto importa. Posso ajudar em algo mais?",
      ar: "شكرًا لاهتمامك. كل عمل خير له قيمة. هل هناك شيء آخر يمكنني مساعدتك به؟",
    },
  },
];

export const FALLBACK: L = {
  en: "I’m not certain about that, and I’d rather not guess. I can help with:\n\n• How to donate with crypto\n• Available campaigns\n• How funds are intended to be used\n• Supported coins, networks and fees\n\nFor anything else, the Haven Fund team can help via the Contact section.",
  es: "No estoy seguro de eso y prefiero no adivinar. Puedo ayudarte con:\n\n• Cómo donar con cripto\n• Campañas disponibles\n• Cómo se destinan los fondos\n• Monedas, redes y comisiones\n\nPara otras consultas, contacta al equipo de Haven Fund.",
  fr: "Je ne suis pas certain et je préfère ne pas deviner. Je peux vous aider pour :\n\n• Faire un don en crypto\n• Les campagnes disponibles\n• L’utilisation prévue des fonds\n• Cryptos, réseaux et frais\n\nPour le reste, contactez l’équipe Haven Fund.",
  pt: "Não tenho certeza e prefiro não adivinhar. Posso ajudar com:\n\n• Como doar com cripto\n• Campanhas disponíveis\n• Como os fundos são destinados\n• Moedas, redes e taxas\n\nPara outros assuntos, fale com a equipe do Haven Fund.",
  ar: "لست متأكدًا من ذلك ولا أريد التخمين. يمكنني مساعدتك في:\n\n• كيفية التبرع بالعملات الرقمية\n• الحملات المتاحة\n• كيفية استخدام التبرعات\n• العملات والشبكات والرسوم\n\nلأي استفسار آخر، تواصل مع فريق Haven Fund.",
};

export const COIN_TEMPLATE: L<(name: string, symbol: string, network: string) => string> = {
  en: (n, s, net) => `**${n} (${s})**\nNetwork: **${net}**\n\nSend only ${s} on the ${net} network to our ${n} address. Always check the network in your wallet before confirming.`,
  es: (n, s, net) => `**${n} (${s})**\nRed: **${net}**\n\nEnvía solo ${s} por la red ${net} a nuestra dirección de ${n}. Verifica siempre la red en tu billetera antes de confirmar.`,
  fr: (n, s, net) => `**${n} (${s})**\nRéseau : **${net}**\n\nEnvoyez uniquement des ${s} sur le réseau ${net} à notre adresse ${n}. Vérifiez toujours le réseau avant de confirmer.`,
  pt: (n, s, net) => `**${n} (${s})**\nRede: **${net}**\n\nEnvie apenas ${s} pela rede ${net} para nosso endereço de ${n}. Sempre confira a rede na carteira antes de confirmar.`,
  ar: (n, s, net) => `**${n} (${s})**\nالشبكة: **${net}**\n\nأرسل ${s} فقط عبر شبكة ${net} إلى عنوان ${n} الخاص بنا. تحقق دائمًا من الشبكة في محفظتك قبل التأكيد.`,
};

export const CAMPAIGN_TEMPLATE: L<(name: string, short: string, items: string) => string> = {
  en: (n, s, i) => `**${n}** — ${s}\n\nDonations to this campaign are intended for:\n${i}\n\nChoose it in the donation panel. Verified progress will be published once available.`,
  es: (n, s, i) => `**${n}** — ${s}\n\nLas donaciones a esta campaña están destinadas a:\n${i}\n\nElígela en el panel de donación. El progreso verificado se publicará cuando esté disponible.`,
  fr: (n, s, i) => `**${n}** — ${s}\n\nLes dons à cette campagne sont destinés à :\n${i}\n\nChoisissez-la dans le panneau de don. Les progrès vérifiés seront publiés dès que possible.`,
  pt: (n, s, i) => `**${n}** — ${s}\n\nAs doações para esta campanha são destinadas a:\n${i}\n\nEscolha-a no painel de doação. O progresso verificado será publicado quando disponível.`,
  ar: (n, s, i) => `**${n}** — ${s}\n\nالتبرعات لهذه الحملة مخصّصة لـ:\n${i}\n\nاخترها في لوحة التبرع. سيتم نشر التقدم الموثّق عند توفره.`,
};
