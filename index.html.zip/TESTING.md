# Haven Fund — Pre-launch Test Report

## How to run the tests

```bash
npm run build
npm test                                   # 250+ browser tests: 4 phones/tablets + desktop (network mocked)
npx playwright test --project=live         # REAL internet: verifies a real donation on the Bitcoin blockchain
npm run test:chain                         # REAL blockchain data on all 6 networks (20 checks)
npx playwright test --project=desktop links.spec && npm run test:links   # every external link, live
npm run verify:wallets                     # donation addresses match the pinned, verified values
```

Devices tested (real Chromium engine, touch + mobile viewport emulation):
**iPhone 13** (390×664), **Pixel 7** (412×839), **small Android** (360×740), **iPad Mini** (768×1024), **Desktop** (1440×900).

---

## Results by requirement

**Browser suite: 253 tests across 5 devices. 252 passed and 1 was skipped by design (a phone-only test on desktop).** Ten iPhone tests first failed on an older build; they were fixed and re-run until they passed (see bugs below). **Live blockchain: 20/20. Live website on the real network: 2/2. External links: 0 broken.**

| Requirement | Status | What was tested |
|---|---|---|
| **Works on phones** | ✅ Automated | All 11 pages on iPhone 13, Pixel 7, 360 px Android, iPad Mini and desktop: page loads, exactly one heading, **no sideways scrolling** (every element checked), no JavaScript errors, Haven AI button visible. Mobile menu reaches every page, closes correctly and has tap targets of at least 24 px. Back/forward buttons and the 404 page work. Screenshots are saved in `test-results/screens/`. |
| **Donate button works** | ✅ Automated | Every Donate button (header, mobile menu, hero, About, Campaigns cards, How Donations Help, Updates) opens the donation panel. Campaign cards pre-select their campaign. |
| **Payment succeeds** | ✅ Automated · ⚠️ needs one real test per network | **Real blockchain data:** 2 of Haven Fund's real past Bitcoin donations verified as *confirmed* with exact amounts (9,597 and 30,014 sats), including through the live website. Real transactions on Ethereum, USDC, USDT, Solana and Litecoin confirmed for their true recipients and **rejected** for Haven Fund. Unknown IDs show "not found"; Haven Fund's own outgoing ETH is not counted as a gift. **Every cryptocurrency on every device:** the exact address is shown, the **QR image decodes to the exact address** (BIP21/Solana Pay with amount), **nothing covers the QR**, and Copy puts the exact address on the clipboard. The network confirmation is required before continuing. Verification states tested: confirmed, pending, not found, wrong recipient, service down. |
| **Donation confirmation works** | ✅ Automated | Confirmation screen: reference `HF-YYYYMMDD-XXXXXXXX`, campaign, asset, network, amount, transaction, on-chain status. The heading adapts to the result (confirmed / found / check your transaction). The downloaded receipt contains the reference, network, address, verification result, the "not a tax receipt" note and your address. The "Email receipt to myself" link is correct. "Make another donation" resets the flow. |
| **Emails / receipts arrive** | ✅ Request contents verified · ⚠️ **one-time activation required** | Contact form, donation notice + donor copy (`_cc`), and newsletter all send the correct fields to `formsubmit.co/ajax/havenfund@hotmail.com`, with Reply-To set to the visitor. Only the site origin is sent as referrer. **Live check:** FormSubmit answers "This form needs Activation", so **no email is delivered until you click the activation link** (see checklist). If email fails, donors still get their confirmation, a receipt download and a pre-filled email link. |
| **Contact form works** | ✅ Automated | Required-field errors and focus, email format, consent, successful send and "Message received", activation/outage fallback with a pre-filled "Email us directly" link, anti-bot timer, 60-second cooldown, honeypot. Email, phone, address/map and Facebook links are correct. |
| **All links work** | ✅ Automated | Crawled every link on all 11 pages plus 6 news posts: all internal links open real pages, and every `#section` target exists. Old one-page links redirect correctly. `mailto:`/`tel:` links are correct and every external link is HTTPS. **Live:** Facebook, Google Maps, mempool.space and litecoinspace.org load. Etherscan, Solscan and Tronscan are behind Cloudflare bot protection (they load for people, not robots), so check them by hand once. |
| Privacy & AI | ✅ Automated | The privacy notice appears on the first visit and the choice is remembered. Settings reopen from the footer. No cookies are set. Haven AI answers in English and Spanish, its action buttons navigate, and the microphone asks permission first. |

### Bugs found and fixed by testing

| # | Problem found | Impact | Fix |
|---|---|---|---|
| 1 | On phones, the floating **“Ask Haven AI” button covered part of the QR code** when it was near the bottom of the screen | Donors scanning with a second phone could fail | Launcher now automatically fades away whenever it would overlap a QR code; test asserts nothing covers any of 81 points on the QR |
| 2 | Contact form: pressing **Send quickly on an empty form showed “That was quick!”** instead of listing missing fields | Confusing for real visitors | Field validation now runs before the anti-bot timer |
| 3 | **Privacy / Terms / Security links in the phone menu were only 16 px tall** | Hard to tap (below WCAG 2.5.8 minimum of 24 px) | Enlarged to 44 px touch targets |
| 4 | The site had **no way to confirm a payment actually arrived**, and **sent no emails** | “Payment succeeds” and “emails arrive” could not be true | Added on-chain verification for 6 networks, email delivery for contact/donations/newsletter, receipt download and mailto fallbacks |
| 5 | Free Tron/Solana APIs return rate-limit or odd errors for unknown IDs | Verification could show “error” instead of “not found” | Automatic retry with back-off; invalid IDs reported as “not found” |

---

## ⚠️ What automated tests CANNOT prove — do these by hand before advertising

These need a real person, a real wallet or a real inbox. Tick each one.

### 1. Activate email delivery (5 minutes, required)
- [ ] Publish the site on its real HTTPS domain.
- [ ] Run `node scripts/activate-email.mjs https://YOUR-DOMAIN` (or send one message through the contact form).
- [ ] Open **havenfund@hotmail.com** → find the FormSubmit email (check **Junk**) → click **Activate Form**.
- [ ] Run the script again → confirm the test email **arrives in the inbox**.
- [ ] Mark FormSubmit as “Not junk” / add it to safe senders so messages don’t go to spam.

### 2. Real donations — one small test per network (~$1–5 each)
For each row: send a small amount from a real wallet → paste the transaction ID on the site → click **Verify on blockchain** → **Complete donation** with “Email me a copy” ticked (use your own address).

| Network | Sent from wallet | Verify shows “Confirmed” | Amount matches | Receipt email arrived | Team email arrived | Funds visible in Haven Fund wallet |
|---|---|---|---|---|---|---|
| Bitcoin (on-chain) | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Lightning (BOLT12) | ☐ | n/a (private) | n/a | ☐ | ☐ | ☐ |
| Ethereum | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| USDT (TRC-20) | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| USDC (ERC-20) | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Solana | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Litecoin | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |

Also: scan each QR code **from a second phone’s wallet app** and confirm it fills in the right address (tests decode the QR image, but real wallet apps are the final proof). For Lightning, confirm your sending wallet supports **BOLT12** (e.g. Phoenix).

### 3. Real phones (15 minutes)
Tests used a Chromium engine with phone screen sizes. Also check on the actual devices donors use:
- [ ] **iPhone Safari** — open the site, donate flow to the QR step, copy address, open Haven AI, contact form.
- [ ] **Android Chrome** — same.
- [ ] **Voice questions** in Haven AI (tap mic, allow microphone) on both phones — requires a real microphone.
- [ ] Rotate to landscape once on each phone.

### 4. Links that block robots
Some sites (e.g. Facebook, some block explorers) refuse automated checks. The link report marks these **BOT-BLOCKED** — open each once in a browser to confirm.

### 5. After publishing
- [ ] https://www.ssllabs.com/ssltest/ → grade A or A+
- [ ] https://securityheaders.com → grade A
- [ ] `node scripts/verify-wallets.mjs https://YOUR-DOMAIN` → passes (addresses, HTTPS, HSTS, CSP)
- [ ] Post your official wallet addresses on the Facebook page (independent verification for donors).
