import { useEffect, useState } from "react";
import { Menu, X, HouseHeart, Sparkles, ArrowRight } from "lucide-react";
import { openHavenAI } from "./AssistantSection";
import { useRoute, to, PAGE_META, type PageId } from "../router";
import { cn } from "../utils/cn";

export const NAV: { page: Exclude<PageId, "notfound" | "privacy" | "terms" | "donate">; label: string }[] = [
  { page: "home", label: "Home" },
  { page: "about", label: "About Us" },
  { page: "campaigns", label: "Campaigns" },
  { page: "impact", label: "How Donations Help" },
  { page: "updates", label: "Updates" },
  { page: "contact", label: "Contact" },
];

export function Logo({ className }: { className?: string }) {
  return (
    <a href={to("home")} className={cn("group inline-flex items-center gap-2.5", className)} aria-label="Haven Fund home">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-hope-400 via-hope-500 to-tech-400 shadow-[0_0_30px_-4px_rgba(245,180,60,0.6)] transition-transform duration-500 group-hover:rotate-[8deg]">
        <HouseHeart className="h-5 w-5 text-ink-950" strokeWidth={2.4} />
        <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/30" />
      </span>
      <span className="text-lg font-extrabold tracking-tight text-white">
        Haven <span className="text-gradient">Fund</span>
      </span>
    </a>
  );
}

export default function Navbar() {
  const route = useRoute();
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const on = () => {
      setScrolled(window.scrollY > 24);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => setOpen(false), [route.nonce]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const isActive = (p: PageId) => route.page === p;
  const onDonatePage = route.page === "donate";

  return (
    <header className={cn("fixed inset-x-0 top-0 z-50 transition-all duration-500", scrolled ? "py-3" : "py-5")}>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-hope-400 focus:px-4 focus:py-2 focus:text-ink-950">
        Skip to content
      </a>
      <nav
        aria-label="Primary"
        className={cn(
          "relative mx-auto flex max-w-7xl items-center justify-between gap-4 rounded-2xl px-4 transition-all duration-500 sm:px-6",
          scrolled ? "glass-strong mx-3 py-2.5 sm:mx-auto xl:w-[calc(100%-2rem)]" : "py-2"
        )}
      >
        <Logo />
        <ul className="hidden items-center gap-0.5 xl:flex">
          {NAV.map((n) => (
            <li key={n.page}>
              <a
                href={to(n.page)}
                aria-current={isActive(n.page) ? "page" : undefined}
                className={cn(
                  "relative rounded-lg px-3 py-2 text-sm font-medium transition",
                  isActive(n.page) ? "text-white" : "text-slate-300 hover:bg-white/5 hover:text-white"
                )}
              >
                {n.label}
                {isActive(n.page) && (
                  <span className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-r from-hope-400 to-tech-400" />
                )}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => openHavenAI()}
            className="hidden items-center gap-1.5 rounded-xl border border-tech-400/40 bg-tech-400/10 px-3.5 py-2.5 text-sm font-bold text-tech-100 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)] transition hover:bg-tech-400/20 md:inline-flex"
          >
            <Sparkles className="h-4 w-4" /> Ask Haven AI
          </button>
          <a
            href={to("donate")}
            aria-current={onDonatePage ? "page" : undefined}
            className={cn(
              "btn-shine hidden rounded-xl px-4 py-2.5 text-sm font-bold text-ink-950 shadow-[0_8px_30px_-8px_rgba(245,180,60,0.7)] transition hover:scale-[1.03] sm:inline-flex",
              onDonatePage && "ring-2 ring-hope-200/60 ring-offset-2 ring-offset-ink-950"
            )}
          >
            Donate
          </a>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white xl:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {scrolled && (
          <span aria-hidden className="absolute inset-x-4 bottom-0 h-px overflow-hidden rounded-full">
            <span className="block h-full origin-left bg-gradient-to-r from-hope-400 via-tech-400 to-aura-500 transition-transform duration-150" style={{ transform: `scaleX(${progress})` }} />
          </span>
        )}
      </nav>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        className={cn(
          "fixed inset-x-3 top-[76px] max-h-[calc(100svh-96px)] origin-top overflow-y-auto rounded-2xl glass-strong p-4 transition-all duration-300 xl:hidden",
          open ? "scale-100 opacity-100" : "pointer-events-none scale-95 opacity-0"
        )}
        inert={!open}
      >
        <ul className="grid gap-1">
          {[...NAV, { page: "donate" as const, label: "Donate" }].map((n) => (
            <li key={n.page}>
              <a
                href={to(n.page)}
                aria-current={isActive(n.page) ? "page" : undefined}
                className={cn(
                  "flex items-center justify-between rounded-xl px-4 py-3 text-base font-medium transition",
                  isActive(n.page) ? "bg-white/[0.07] text-white" : "text-slate-200 hover:bg-white/5"
                )}
              >
                <span>
                  {n.label}
                  <span className="block text-xs font-normal text-slate-500">{PAGE_META[n.page].description.split(".")[0].slice(0, 60)}…</span>
                </span>
                <ArrowRight className={cn("h-4 w-4 shrink-0", isActive(n.page) ? "text-hope-300" : "text-slate-600")} />
              </a>
            </li>
          ))}
        </ul>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <a href={to("donate")} className="btn-shine block rounded-xl px-4 py-3 text-center font-bold text-ink-950">
            Donate With Crypto
          </a>
          <button
            type="button"
            onClick={() => { setOpen(false); openHavenAI(); }}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-tech-400/40 bg-tech-400/10 px-4 py-3 font-bold text-tech-100"
          >
            <Sparkles className="h-4 w-4" /> Ask Haven AI
          </button>
        </div>
        <p className="mt-3 flex flex-wrap justify-center gap-x-2 text-sm text-slate-400">
          <a href={to("privacy")} className="inline-flex min-h-11 items-center rounded-lg px-3 hover:bg-white/5 hover:text-white">Privacy Policy</a>
          <a href={to("terms")} className="inline-flex min-h-11 items-center rounded-lg px-3 hover:bg-white/5 hover:text-white">Terms & Conditions</a>
          <a href={to("security")} className="inline-flex min-h-11 items-center rounded-lg px-3 hover:bg-white/5 hover:text-white">Security</a>
        </p>
      </div>
    </header>
  );
}
