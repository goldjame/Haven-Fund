/**
 * Email delivery for a static website (no server needed).
 * ------------------------------------------------------------------
 * Default provider: FormSubmit (https://formsubmit.co) — forwards submissions
 * to Haven Fund's inbox. ONE-TIME SETUP: the first submission sends an
 * "Activate Form" email to havenfund@hotmail.com; click it once and all
 * future messages are delivered. (Run `node scripts/activate-email.mjs`.)
 *
 * Override with VITE_FORM_ENDPOINT (any HTTPS endpoint accepting the same JSON),
 * or set VITE_FORM_ENDPOINT=off to disable email sending entirely.
 *
 * Data sent: only the fields the visitor typed / chose to send. Disclosed in
 * the Privacy Policy. Only the site ORIGIN is sent as referrer (FormSubmit
 * requires it to identify the form); never the full URL.
 */
import { ORG } from "../config/org";
import { secureFetch } from "./http";

const OVERRIDE = import.meta.env.VITE_FORM_ENDPOINT?.trim();
export const EMAIL_ENDPOINT =
  OVERRIDE === "off" ? null : OVERRIDE || `https://formsubmit.co/ajax/${encodeURIComponent(ORG.email)}`;
export const emailEnabled = Boolean(EMAIL_ENDPOINT);

export class EmailNotActivatedError extends Error {}
export class EmailError extends Error {}

export interface EmailOptions {
  subject: string;
  /** Visitor's email for Reply-To (lets the team reply directly) */
  replyTo?: string;
  /** Send a copy of the submission to this address (donor receipt) */
  copyTo?: string;
  fields: Record<string, string | number | undefined>;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const clip = (v: unknown, max = 4000) => String(v ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").slice(0, max);

export async function sendEmail({ subject, replyTo, copyTo, fields }: EmailOptions): Promise<void> {
  if (!EMAIL_ENDPOINT) throw new EmailError("Email delivery is not configured.");
  const body: Record<string, string> = {};
  for (const [k, v] of Object.entries(fields)) if (v !== undefined && v !== "") body[clip(k, 60)] = clip(v);
  body._subject = clip(subject, 150);
  body._template = "table";
  body._captcha = "false";
  if (replyTo && EMAIL_RE.test(replyTo)) {
    body.email = replyTo;
    body._replyto = replyTo;
  }
  if (copyTo && EMAIL_RE.test(copyTo)) body._cc = copyTo;

  const res = await secureFetch(
    EMAIL_ENDPOINT,
    {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify(body),
      referrerPolicy: "strict-origin",
    },
    { timeoutMs: 20000 }
  );
  let data: { success?: string | boolean; message?: string } = {};
  try {
    data = await res.json();
  } catch {
    /* non-JSON */
  }
  const ok = res.ok && (data.success === true || data.success === "true");
  if (ok) return;
  if (data.message && /activat/i.test(data.message)) throw new EmailNotActivatedError(data.message);
  throw new EmailError(data.message || `Email service responded ${res.status}`);
}

/** Pre-filled mailto: link used as a fallback when automatic sending fails. */
export function mailtoLink(to: string, subject: string, body: string) {
  return `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body.slice(0, 1800))}`;
}
