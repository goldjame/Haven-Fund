/**
 * Privacy & cookie controls.
 * ------------------------------------------------------------------
 * Haven Fund sets NO cookies and uses NO analytics or advertising trackers.
 * The only optional items are listed below, and each is OFF until the visitor
 * chooses. The visitor's choice itself is stored locally (strictly necessary).
 *
 *  - preferences : remember chat history, language and donation references
 *                  on this device (localStorage / sessionStorage)
 *  - prices      : fetch live USD price estimates from CoinGecko
 *  - voice       : use the browser's speech-recognition service for voice questions
 *
 * Browsers sending Global Privacy Control (GPC) get optional items OFF by default.
 */
import { useEffect, useState } from "react";

export type ConsentCategory = "preferences" | "prices" | "voice";
export interface Consent {
  preferences: boolean;
  prices: boolean;
  voice: boolean;
  decided: boolean;
  updatedAt?: string;
  version: number;
}

const KEY = "havenfund.consent";
const VERSION = 1;

/** Keys written only when `preferences` consent is given. */
export const PREFERENCE_KEYS = {
  local: ["havenfund.lang", "havenfund.donations"],
  session: ["havenfund.chat"],
};

const DEFAULT: Consent = { preferences: false, prices: false, voice: false, decided: false, version: VERSION };

export const gpcEnabled = () =>
  typeof navigator !== "undefined" && Boolean((navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl);

function read(): Consent {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const c = JSON.parse(raw) as Consent;
      if (c.version === VERSION) return { ...DEFAULT, ...c };
    }
  } catch {
    /* storage unavailable */
  }
  return DEFAULT;
}

let state: Consent = typeof window !== "undefined" ? read() : DEFAULT;
const listeners = new Set<(c: Consent) => void>();

export const getConsent = () => state;
export const hasConsent = (c: ConsentCategory) => state[c];

function clearPreferenceData() {
  try {
    PREFERENCE_KEYS.local.forEach((k) => localStorage.removeItem(k));
    PREFERENCE_KEYS.session.forEach((k) => sessionStorage.removeItem(k));
  } catch {
    /* ignore */
  }
}

export function setConsent(next: Partial<Omit<Consent, "decided" | "version">>) {
  const prev = state;
  state = { ...state, ...next, decided: true, version: VERSION, updatedAt: new Date().toISOString() };
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* ignore */
  }
  if (prev.preferences && !state.preferences) clearPreferenceData();
  listeners.forEach((l) => l(state));
}

export const acceptAll = () => setConsent({ preferences: true, prices: true, voice: true });
export const essentialOnly = () => setConsent({ preferences: false, prices: false, voice: false });

export function useConsent() {
  const [c, setC] = useState(state);
  useEffect(() => {
    listeners.add(setC);
    return () => {
      listeners.delete(setC);
    };
  }, []);
  return c;
}

export const openPrivacySettings = () => window.dispatchEvent(new CustomEvent("haven:privacy"));

/* ---------- consent-aware storage helpers ---------- */
type Area = "local" | "session";
const area = (a: Area) => (a === "local" ? localStorage : sessionStorage);

export function prefGet(a: Area, key: string): string | null {
  if (!state.preferences) return null;
  try {
    return area(a).getItem(key);
  } catch {
    return null;
  }
}

export function prefSet(a: Area, key: string, value: string) {
  if (!state.preferences) return;
  try {
    area(a).setItem(key, value);
  } catch {
    /* quota / disabled */
  }
}
