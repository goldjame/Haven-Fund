import { defineConfig, devices } from "@playwright/test";

/**
 * Haven Fund end-to-end tests.
 *   npm run build && npm test            all mocked tests on 4 phones/tablets + desktop
 *   npx playwright test --project=live   real-network checks (blockchain + external links)
 */
const mobileChromium = (d: (typeof devices)[string]) => ({ ...d, browserName: "chromium" as const, defaultBrowserType: "chromium" as const });

export default defineConfig({
  testDir: "tests/e2e",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: true,
  workers: 4,
  retries: 1,
  reporter: [["list"], ["json", { outputFile: "test-results/results.json" }]],
  use: {
    baseURL: "http://localhost:4173",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    permissions: ["clipboard-read", "clipboard-write"],
    acceptDownloads: true,
  },
  webServer: {
    command: "npx vite preview --port 4173 --strictPort",
    url: "http://localhost:4173",
    reuseExistingServer: true,
    timeout: 30_000,
  },
  projects: [
    { name: "iphone-13", use: mobileChromium(devices["iPhone 13"]), testIgnore: /live\.spec/ },
    { name: "pixel-7", use: mobileChromium(devices["Pixel 7"]), testIgnore: /live\.spec/ },
    {
      name: "small-android-360",
      use: { viewport: { width: 360, height: 740 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, userAgent: devices["Galaxy S9+"].userAgent },
      testIgnore: /live\.spec/,
    },
    { name: "ipad-mini", use: mobileChromium(devices["iPad Mini"]), testIgnore: /live\.spec|links\.spec/ },
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } }, testIgnore: /live\.spec/ },
    { name: "live", use: { ...devices["Desktop Chrome"] }, testMatch: /live\.spec/, retries: 2 },
  ],
});
