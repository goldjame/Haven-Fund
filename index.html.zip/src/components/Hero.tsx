import { ArrowRight, Mic, ShieldCheck, Sparkles } from "lucide-react";
import { openHavenAI } from "./AssistantSection";
import hero from "../assets/hero.jpg";
import { ASSETS } from "../config/wallets";
import { CryptoIcon } from "./CryptoIcon";
import { useCountUp } from "../hooks";

function Stat({ value, suffix = "", label, prefix = "" }: { value: number; suffix?: string; label: string; prefix?: string }) {
  const { ref, value: v } = useCountUp(value);
  return (
    <div className="glass group rounded-2xl p-4 transition duration-500 hover:-translate-y-1 hover:border-hope-400/30 sm:p-5">
      <p className="font-display text-3xl text-white sm:text-4xl">
        <span ref={ref as React.RefObject<HTMLSpanElement>}>
          {prefix}
          {v}
        </span>
        <span className="text-gradient">{suffix}</span>
      </p>
      <p className="mt-1 text-xs font-medium uppercase tracking-wider text-slate-400">{label}</p>
    </div>
  );
}

export default function Hero() {
  const orbit = ASSETS.filter((a) => a.id !== "LN");
  return (
    <section id="top" aria-labelledby="hero-title" className="relative isolate min-h-[100svh] overflow-hidden pt-28 pb-16 sm:pt-32 lg:pt-36">
      {/* Cinematic image layer */}
      <div aria-hidden className="absolute inset-0 -z-10 grain">
        <img
          src={hero}
          alt=""
          className="h-full w-full object-cover object-[70%_center] opacity-60"
          fetchPriority="high"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/80 to-ink-950/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/60" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <p className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-semibold text-slate-200 backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-hope-400" />
            Technology With Humanity
            <span className="h-3 w-px bg-white/20" />
            <span className="text-tech-300">Crypto-only giving</span>
          </p>

          <h1
            id="hero-title"
            className="animate-fade-up mt-6 font-display text-[3.1rem] leading-[0.95] tracking-tight text-white [animation-delay:120ms] sm:text-7xl lg:text-[5.6rem]"
          >
            A Digital Wallet
            <br />
            for <em className="text-gradient italic">Human Hope.</em>
          </h1>

          <p className="animate-fade-up mt-6 max-w-xl text-base leading-relaxed text-slate-300 [animation-delay:240ms] sm:text-lg">
            Your cryptocurrency donation is intended to help provide <strong className="font-semibold text-white">food, shelter, clothing, education</strong> and
            essential support to vulnerable street children and homeless people — sent directly, verifiable on-chain,
            from anywhere in the world.
          </p>

          <div className="animate-fade-up mt-9 flex flex-col gap-3 [animation-delay:360ms] sm:flex-row">
            <a
              href="#/donate"
              className="btn-shine group relative inline-flex items-center justify-center gap-2 rounded-2xl px-7 py-4 text-base font-bold text-ink-950 shadow-[0_18px_50px_-12px_rgba(245,180,60,0.8)] transition hover:scale-[1.02]"
            >
              Donate With Crypto
              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </a>
            <a
              href="#/about"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-7 py-4 text-base font-semibold text-white backdrop-blur transition hover:border-white/30 hover:bg-white/10"
            >
              Learn About Our Mission
            </a>
          </div>

          <button
            type="button"
            onClick={() => openHavenAI()}
            className="animate-fade-up group mt-5 flex w-full max-w-xl items-center gap-3 rounded-2xl border border-tech-400/30 bg-gradient-to-r from-tech-400/10 via-aura-500/10 to-transparent p-3 pr-4 text-left backdrop-blur transition [animation-delay:420ms] hover:border-tech-400/60"
          >
            <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-tech-400 to-aura-500 text-white">
              <Sparkles className="h-5 w-5" />
              <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-ink-950 bg-emerald-400" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-bold text-white">Ask Haven AI</span>
              <span className="block truncate text-xs text-slate-400">Questions about campaigns or crypto? Type or speak — 5 languages.</span>
            </span>
            <Mic className="h-5 w-5 shrink-0 text-tech-300 transition group-hover:scale-110" />
          </button>

          <div className="animate-fade-up mt-8 flex flex-wrap items-center gap-x-5 gap-y-3 text-sm text-slate-400 [animation-delay:480ms]">
            <div className="flex -space-x-2">
              {ASSETS.map((a) => (
                <span key={a.id} className="rounded-full ring-2 ring-ink-950">
                  <CryptoIcon id={a.id} size={28} />
                </span>
              ))}
            </div>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-400" /> Address formats validated in-app
            </span>
          </div>
        </div>

        {/* Orbiting wallet visual */}
        <div className="relative mx-auto hidden aspect-square w-full max-w-[460px] lg:block" aria-hidden>
          <div className="absolute inset-0 rounded-full border border-white/5" />
          <div className="absolute inset-10 rounded-full border border-dashed border-hope-400/15" />
          <div className="absolute inset-24 rounded-full border border-tech-400/10" />
          <div className="absolute inset-0 animate-spin-slow">
            {orbit.map((a, i) => {
              const angle = (i / orbit.length) * Math.PI * 2;
              const x = 50 + Math.cos(angle) * 46;
              const y = 50 + Math.sin(angle) * 46;
              return (
                <div
                  key={a.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${x}%`, top: `${y}%` }}
                >
                  <div className="glass grid h-14 w-14 place-items-center rounded-2xl [animation:spin_40s_linear_infinite_reverse]">
                    <CryptoIcon id={a.id} size={30} />
                  </div>
                </div>
              );
            })}
          </div>
          {/* Center card */}
          <div className="absolute left-1/2 top-1/2 w-64 -translate-x-1/2 -translate-y-1/2 animate-float">
            <div className="glass-strong border-gradient rounded-3xl p-5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Haven Wallet</span>
                <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-300">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> Open
                </span>
              </div>
              <p className="mt-4 font-display text-3xl italic text-white">Food · Shelter</p>
              <p className="font-display text-3xl italic text-gradient">Education · Care</p>
              <div className="mt-5 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
              <p className="mt-4 font-mono text-[11px] text-slate-400">6 campaigns · 7 assets · 24/7</p>
            </div>
            <div className="absolute -inset-10 -z-10 rounded-full bg-hope-500/20 blur-3xl" />
          </div>
        </div>
      </div>

      <div className="mx-auto mt-14 grid max-w-7xl grid-cols-2 gap-3 px-5 sm:px-8 md:grid-cols-4 md:gap-4 lg:mt-20">
        <Stat value={7} label="Supported crypto assets" />
        <Stat value={6} label="Blockchain networks" />
        <Stat value={24} suffix="/7" label="Donations accepted" />
        <Stat value={0} label="Accounts required to give" />
      </div>
    </section>
  );
}
