/**
 * Updates & News.
 * ------------------------------------------------------------------
 * RULE: Only publish verified information. Posts below describe the
 * platform itself or are educational guides. Field updates (activities,
 * beneficiaries, distributions) must only be added once verified — and
 * never identify children without consent.
 *
 * `date` is optional ISO (YYYY-MM-DD). Leave undefined rather than invent one.
 */

export type NewsCategory = "announcement" | "campaigns" | "transparency" | "guide" | "field";

export const NEWS_CATEGORIES: { id: NewsCategory | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "announcement", label: "Announcements" },
  { id: "campaigns", label: "Campaigns" },
  { id: "transparency", label: "Transparency" },
  { id: "guide", label: "Guides" },
  { id: "field", label: "Field updates" },
];

export type Block = { type: "p"; text: string } | { type: "h"; text: string } | { type: "list"; items: string[] } | { type: "note"; text: string };

export interface NewsPost {
  slug: string;
  title: string;
  excerpt: string;
  category: NewsCategory;
  date?: string;
  readMinutes: number;
  featured?: boolean;
  cta?: { label: string; href: string };
  body: Block[];
}

export const NEWS: NewsPost[] = [
  {
    slug: "welcome-to-haven-fund",
    title: "Welcome to Haven Fund: a digital wallet for human hope",
    excerpt: "Introducing our cryptocurrency-only donation platform for street children and homeless people — built on the idea of Technology With Humanity.",
    category: "announcement",
    readMinutes: 3,
    featured: true,
    cta: { label: "Donate with crypto", href: "#/donate" },
    body: [
      { type: "p", text: "Haven Fund is a cryptocurrency-only donation platform created to support street children and homeless people. Donations are intended to help provide food, shelter, clothing, education and essential support." },
      { type: "h", text: "Why crypto?" },
      { type: "p", text: "Cryptocurrency lets anyone, anywhere, give directly and quickly — without a bank account or card processor. Every on-chain donation address we publish can be viewed on a public block explorer, so anyone can independently see incoming transactions." },
      { type: "h", text: "What you can do on the website" },
      { type: "list", items: [
        "Donate Bitcoin, Lightning, Ethereum, USDT (TRC-20), USDC (ERC-20), Solana or Litecoin",
        "Scan a QR code or copy the address with one tap",
        "Choose a campaign for your donation",
        "Get help from Haven AI in five languages, by text or voice",
        "Verify our official wallets in the transparency section",
      ] },
      { type: "note", text: "Organization registration details and impact reports have not been published yet. They will be added to the website once available and verified." },
    ],
  },
  {
    slug: "meet-haven-ai",
    title: "Meet Haven AI: multilingual help by text or voice",
    excerpt: "Our AI assistant answers questions about donating, campaigns and how funds are intended to be used — in English, Español, Français, Português and العربية.",
    category: "announcement",
    readMinutes: 2,
    cta: { label: "Ask Haven AI", href: "#ask-haven-ai" },
    body: [
      { type: "p", text: "Haven AI is an AI assistant — not a human — designed to make crypto giving approachable for everyone, including people who have never used cryptocurrency before." },
      { type: "h", text: "What Haven AI can help with" },
      { type: "list", items: [
        "How to donate, step by step",
        "Which coins and networks are supported, and why the network matters",
        "Available campaigns and how donations are intended to be used",
        "Finding your way around the website",
        "Frequently asked questions",
      ] },
      { type: "h", text: "Text or voice, in five languages" },
      { type: "p", text: "Type your question or tap the microphone to speak. Haven AI detects your language automatically, and you can tap “Listen” to hear any reply read aloud." },
      { type: "note", text: "Haven AI is designed never to invent statistics, beneficiaries, projects or financial information. If something hasn’t been published, it will say so." },
    ],
  },
  {
    slug: "six-campaigns-open",
    title: "Six campaigns are now open for donations",
    excerpt: "Choose where your kindness goes: General Fund, Meals of Hope, Safe Haven, Warmth & Dignity, Future Minds and Essential Care.",
    category: "campaigns",
    readMinutes: 2,
    cta: { label: "Explore campaigns", href: "#/campaigns" },
    body: [
      { type: "p", text: "Donors can now choose a campaign when giving. Each campaign describes a focus area and how donations to it are intended to be used." },
      { type: "list", items: [
        "Haven General Fund — where it’s needed most",
        "Meals of Hope — food & clean water",
        "Safe Haven — shelter & safe nights",
        "Warmth & Dignity — clothing & hygiene",
        "Future Minds — education for street children",
        "Essential Care — basic care & support",
      ] },
      { type: "p", text: "All campaigns share the same secure wallets. Your campaign preference is recorded with your donation reference." },
      { type: "note", text: "Campaign targets and progress will only be shown once verified figures are available." },
    ],
  },
  {
    slug: "wallets-published",
    title: "Our donation wallets are published for public verification",
    excerpt: "Every official on-chain donation address is listed with its network and a link to a public block explorer.",
    category: "transparency",
    readMinutes: 2,
    cta: { label: "View official wallets", href: "#/how-donations-help/transparency" },
    body: [
      { type: "p", text: "Transparency is central to Haven Fund. All official donation addresses are listed on the How Donations Help page, each with its exact network and a link to view incoming transactions on a public block explorer." },
      { type: "p", text: "The website also checks each address against the expected format for its network before displaying it — a safety net against typos." },
      { type: "list", items: [
        "Only use addresses shown on the official Haven Fund website",
        "Compare the first and last 6 characters after pasting",
        "Haven Fund will never ask for your seed phrase or private keys",
      ] },
    ],
  },
  {
    slug: "donate-crypto-safely",
    title: "A beginner’s guide to donating crypto safely",
    excerpt: "Never used cryptocurrency before? Here’s how to give with confidence in four simple steps.",
    category: "guide",
    readMinutes: 4,
    cta: { label: "Start donating", href: "#/donate" },
    body: [
      { type: "h", text: "1. Get crypto" },
      { type: "p", text: "Use a reputable exchange or wallet app available in your country. Stablecoins such as USDT or USDC are often easiest, because they are designed to track the US dollar." },
      { type: "h", text: "2. Choose the right network" },
      { type: "p", text: "When your wallet or exchange asks for a network, choose exactly the one shown on the donation card — for example TRON (TRC-20) for USDT." },
      { type: "h", text: "3. Scan or paste the address" },
      { type: "p", text: "Scan the QR code, or copy and paste the address. Then compare the first and last 6 characters to make sure it matches." },
      { type: "h", text: "4. Send a test first if unsure" },
      { type: "p", text: "Crypto transactions cannot be reversed. If you’re unsure, send a small amount first, then the rest." },
      { type: "note", text: "This guide is general information, not financial advice." },
    ],
  },
  {
    slug: "why-the-network-matters",
    title: "Why the network matters: USDT (TRC-20) vs USDC (ERC-20)",
    excerpt: "The same coin can exist on several blockchains. Here’s how to make sure your donation arrives.",
    category: "guide",
    readMinutes: 3,
    cta: { label: "See supported networks", href: "#/how-donations-help/transparency" },
    body: [
      { type: "p", text: "Stablecoins like USDT and USDC are issued on multiple blockchains. An address on one network cannot automatically receive funds sent on another." },
      { type: "list", items: [
        "Haven Fund’s USDT address is on TRON (TRC-20)",
        "Haven Fund’s USDC address is on Ethereum (ERC-20)",
        "ETH and USDC share the same Ethereum address",
      ] },
      { type: "p", text: "USDT on TRON needs a small amount of TRX (or energy) in the sending wallet to cover fees. USDC on Ethereum needs ETH for gas." },
      { type: "note", text: "Funds sent on an unsupported network may be permanently lost." },
    ],
  },
];

export const getPost = (slug?: string) => NEWS.find((n) => n.slug === slug);
export const categoryLabel = (c: NewsCategory) => NEWS_CATEGORIES.find((x) => x.id === c)?.label ?? c;
