import { useEffect, useRef, useState } from "react";
import { Cookie, Database, LineChart, Lock, Mic, ShieldCheck, X } from "lucide-react";
import { acceptAll, essentialOnly, gpcEnabled, setConsent, useConsent, type ConsentCategory } from "../../services/consent";
import { to } from "../../router";
import { cn } from "../../utils/cn";

const ITEMS: { id: ConsentCategory | "essential"; icon: typeof Lock; title: string; text: string; locked?: boolean }[] = [
  {
    id: "essential",
    icon: Lock,
    title: "Strictly necessary",
    text: "Remembers your privacy choice on this device. No cookies, no tracking. Always on.",
    locked: true,
  },
  {
    id: "preferences",
    icon: Database,
    title: "Remember my preferences",
    text: "Keeps your Haven AI chat for this session, your language, and donation references on this device only. Nothing is sent to us.",
  },
  {
    id: "prices",
    icon: LineChart,
    title: "Live price estimates",
    text: "Fetches public crypto prices from CoinGecko to show USD estimates. CoinGecko can see your IP address.",
  },
  {
    id: "voice",
    icon: Mic,
    title: "Voice questions",
    text: "Lets Haven AI use your browser’s speech recognition. Depending on your browser, audio may be processed by its vendor (e.g. Google or Apple). The microphone is only used when you tap it.",
  },
];

function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange?: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange?.(!checked)}
      className={cn(
        "relative h-7 w-12 shrink-0 rounded-full border transition",
        checked ? "border-hope-400/60 bg-hope-400" : "border-white/15 bg-white/10",
        disabled && "cursor-not-allowed opacity-60"
      )}
    >
      <span className={cn("absolute top-0.5 h-5.5 w-5.5 rounded-full bg-white shadow transition-all", checked ? "left-[calc(100%-1.5rem)]" : "left-0.5")} />
    </button>
  );
}

export default function PrivacyControls() {
  const consent = useConsent();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState({ preferences: consent.preferences, prices: consent.prices, voice: consent.voice });
  const dialogRef = useRef<HTMLDivElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const on = () => {
      lastFocus.current = document.activeElement as HTMLElement;
      setDraft({ preferences: consent.preferences, prices: consent.prices, voice: consent.voice });
      setOpen(true);
    };
    window.addEventListener("haven:privacy", on);
    return () => window.removeEventListener("haven:privacy", on);
  }, [consent]);

  // Focus management + Escape + simple focus trap
  useEffect(() => {
    if (!open) return;
    const el = dialogRef.current;
    el?.querySelector<HTMLElement>("button")?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
      if (e.key === "Tab" && el) {
        const f = Array.from(el.querySelectorAll<HTMLElement>("button:not([disabled]), a[href]"));
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      lastFocus.current?.focus?.();
    };
  }, [open]);

  const save = () => { setConsent(draft); setOpen(false); };
  const gpc = gpcEnabled();

  return (
    <>
      {/* First-visit notice */}
      {!consent.decided && !open && (
        <div
          role="region"
          aria-label="Privacy choices"
          className="glass-strong animate-fade-up fixed inset-x-3 bottom-3 z-[70] rounded-3xl p-5 sm:inset-x-auto sm:bottom-6 sm:left-6 sm:max-w-md"
        >
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-hope-400/15 text-hope-300"><Cookie className="h-5 w-5" /></span>
            <div>
              <p className="font-bold text-white">Your privacy, your choice</p>
              <p className="mt-1 text-sm leading-relaxed text-slate-400">
                We use <strong className="text-slate-200">no tracking cookies</strong> and no analytics. A few optional features (saving preferences, live price
                estimates, voice questions) need your permission.{" "}
                <a href={to("privacy")} className="text-hope-300 underline underline-offset-2">Privacy Policy</a>
              </p>
              {gpc && <p className="mt-2 text-xs text-emerald-300">Global Privacy Control detected — optional features stay off unless you enable them.</p>}
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            <button onClick={essentialOnly} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-xs font-bold text-white hover:bg-white/10 sm:text-sm">
              Essential only
            </button>
            <button
              onClick={() => { setDraft({ preferences: false, prices: false, voice: false }); setOpen(true); }}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-xs font-bold text-white hover:bg-white/10 sm:text-sm"
            >
              Customize
            </button>
            <button onClick={acceptAll} className="btn-shine rounded-xl px-3 py-2.5 text-xs font-bold text-ink-950 sm:text-sm">
              Allow all
            </button>
          </div>
        </div>
      )}

      {/* Settings dialog */}
      {open && (
        <div className="fixed inset-0 z-[80] flex items-end justify-center p-3 sm:items-center">
          <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-sm" onClick={() => setOpen(false)} aria-hidden />
          <div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="privacy-title"
            className="glass-strong animate-fade-up relative max-h-[90svh] w-full max-w-lg overflow-y-auto rounded-[2rem] p-6 md:p-8"
          >
            <button onClick={() => setOpen(false)} className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-white/5 hover:text-white" aria-label="Close privacy settings">
              <X className="h-4 w-4" />
            </button>
            <ShieldCheck className="h-7 w-7 text-hope-300" />
            <h2 id="privacy-title" className="mt-3 font-display text-3xl text-white">Privacy settings</h2>
            <p className="mt-2 text-sm text-slate-400">Choose which optional features to allow. You can change this any time from the footer.</p>

            <ul className="mt-6 space-y-3">
              {ITEMS.map((it) => {
                const checked = it.locked ? true : draft[it.id as ConsentCategory];
                return (
                  <li key={it.id} className="flex gap-4 rounded-2xl border border-white/5 bg-white/[0.03] p-4">
                    <it.icon className="mt-0.5 h-5 w-5 shrink-0 text-tech-300" />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-white">{it.title}</p>
                      <p className="mt-1 text-xs leading-relaxed text-slate-400">{it.text}</p>
                    </div>
                    <Toggle
                      checked={checked}
                      disabled={it.locked}
                      label={it.title}
                      onChange={(v) => setDraft((d) => ({ ...d, [it.id]: v }))}
                    />
                  </li>
                );
              })}
            </ul>

            <p className="mt-4 text-xs text-slate-500">
              Turning off “Remember my preferences” immediately deletes saved chat, language and donation references from this device.
              {consent.updatedAt && <> Last updated: {new Date(consent.updatedAt).toLocaleString()}.</>}
            </p>

            <div className="mt-6 grid gap-2 sm:grid-cols-3">
              <button onClick={() => { essentialOnly(); setOpen(false); }} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white hover:bg-white/10">
                Essential only
              </button>
              <button onClick={save} className="rounded-xl border border-hope-400/40 bg-hope-400/10 px-4 py-3 text-sm font-bold text-hope-100 hover:bg-hope-400/20">
                Save choices
              </button>
              <button onClick={() => { acceptAll(); setOpen(false); }} className="btn-shine rounded-xl px-4 py-3 text-sm font-bold text-ink-950">
                Allow all
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
