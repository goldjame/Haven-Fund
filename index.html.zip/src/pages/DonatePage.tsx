import { ArrowRight } from "lucide-react";
import DonateSection from "../components/donate/DonateSection";
import { HowItWorks } from "../components/InfoSections";
import FAQ from "../components/FAQ";
import { PageHero, Section } from "../components/layout";
import { ASSETS } from "../config/wallets";
import { CryptoIcon } from "../components/CryptoIcon";
import { to } from "../router";

export default function DonatePage() {
  return (
    <>
      <PageHero
        eyebrow="Donate"
        title="Give in minutes."
        accent="Change a life."
        crumb="Donate"
        chips={[`${ASSETS.length} crypto options`, "No account needed", "QR code + one-tap copy", "Address format verified"]}
      >
        Choose a campaign and cryptocurrency, scan the QR code, and send. We guide you through every step — even if it’s your first time using
        crypto.
      </PageHero>

      <DonateSection showHeading={false} />

      <HowItWorks />

      {/* Supported assets strip */}
      <Section className="py-10 md:py-14">
        <div className="reveal glass flex flex-col items-center justify-between gap-6 rounded-[2rem] p-6 md:flex-row md:p-8">
          <div>
            <p className="font-bold text-white">Want to verify our wallets first?</p>
            <p className="text-sm text-slate-400">Every official address is listed with its network and a public block-explorer link.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {ASSETS.map((a) => (
                <span key={a.id} className="rounded-full ring-2 ring-ink-900"><CryptoIcon id={a.id} size={30} /></span>
              ))}
            </div>
            <a href={to("impact", "transparency")} className="inline-flex items-center gap-2 whitespace-nowrap rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white hover:bg-white/10">
              Official wallets <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </Section>

      <FAQ topic="crypto" title="Crypto donation" accent="questions." intro="Quick answers about coins, networks, fees and verification." />
    </>
  );
}
