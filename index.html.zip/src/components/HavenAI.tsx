import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { ArrowUp, Bot, Globe, Loader2, Mic, MicOff, RefreshCw, RotateCcw, Sparkles, Square, Volume2, X } from "lucide-react";
import { askHavenAI, aiMode, LANGS, UI, langMeta, type ChatMessage, type Lang } from "../services/ai";
import { useSpeechRecognition, useSpeechSynthesis } from "../hooks/useVoice";
import { cn } from "../utils/cn";
import { prefGet, prefSet, setConsent, useConsent, openPrivacySettings } from "../services/consent";

const STORAGE = "havenfund.chat";
const LANG_KEY = "havenfund.lang";
const uid = () => Math.random().toString(36).slice(2, 10);
const isRTL = (s: string) => /[\u0600-\u06FF]/.test(s);

const browserLang = (): Lang => {
  const n = (typeof navigator !== "undefined" ? navigator.language : "en").slice(0, 2) as Lang;
  return LANGS.some((l) => l.code === n) ? n : "en";
};

/* ---------- tiny safe markdown renderer (no HTML injection) ---------- */
function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g).map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={i} className="font-semibold text-white">{p.slice(2, -2)}</strong>;
    if (p.startsWith("`") && p.endsWith("`")) return <code key={i} className="rounded bg-white/10 px-1 font-mono text-[0.85em]" dir="ltr">{p.slice(1, -1)}</code>;
    if (p.startsWith("*") && p.endsWith("*") && p.length > 2) return <em key={i}>{p.slice(1, -1)}</em>;
    return p;
  });
}
function Markdown({ text }: { text: string }) {
  return (
    <div className="space-y-2.5">
      {text.split(/\n{2,}/).map((b, i) => {
        const lines = b.split("\n");
        if (lines.every((l) => /^(•|-)\s/.test(l)))
          return (
            <ul key={i} className="space-y-1">
              {lines.map((l, j) => (
                <li key={j} className="flex gap-2"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-hope-300" /><span>{inline(l.replace(/^(•|-)\s/, ""))}</span></li>
              ))}
            </ul>
          );
        if (lines.every((l) => /^\d+\.\s/.test(l)))
          return (
            <ol key={i} className="space-y-1">
              {lines.map((l, j) => (
                <li key={j} className="flex gap-2"><span className="font-semibold text-hope-300">{j + 1}.</span><span>{inline(l.replace(/^\d+\.\s/, ""))}</span></li>
              ))}
            </ol>
          );
        return (
          <p key={i}>
            {lines.map((l, j) => (
              <span key={j}>{inline(l)}{j < lines.length - 1 && <br />}</span>
            ))}
          </p>
        );
      })}
    </div>
  );
}

export default function HavenAI() {
  const [open, setOpen] = useState(false);
  const [pref, setPref] = useState<Lang | "auto">(() => {
    return (prefGet("local", LANG_KEY) as Lang | "auto" | null) || "auto";
  });
  const [detected, setDetected] = useState<Lang>(browserLang);
  const uiLang: Lang = pref === "auto" ? detected : pref;
  const t = UI[uiLang];

  const welcome = useCallback((l: Lang): ChatMessage => ({ id: "welcome", role: "assistant", content: UI[l].welcome, lang: l }), []);
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = prefGet("session", STORAGE);
      if (saved) return JSON.parse(saved) as ChatMessage[];
    } catch { /* ignore */ }
    return [{ id: "welcome", role: "assistant", content: UI[browserLang()].welcome, lang: browserLang() }];
  });
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [langMenu, setLangMenu] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const tts = useSpeechSynthesis();

  useEffect(() => {
    prefSet("local", LANG_KEY, pref);
    // keep welcome message in the chosen language
    setMessages((m) => (m.length === 1 && m[0].id === "welcome" ? [welcome(uiLang)] : m));
  }, [pref, uiLang, welcome]);

  useEffect(() => {
    prefSet("session", STORAGE, JSON.stringify(messages.slice(-40)));
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = useCallback(
    async (text: string, opts?: { base?: ChatMessage[]; viaVoice?: boolean }) => {
      const q = text.trim().slice(0, 500);
      if (!q || loading) return;
      const history = [...(opts?.base ?? messages).filter((m) => !m.error), { id: uid(), role: "user" as const, content: q, viaVoice: opts?.viaVoice }];
      setMessages(history);
      setInput("");
      setLoading(true);
      abortRef.current?.abort();
      const ac = new AbortController();
      abortRef.current = ac;
      try {
        const res = await askHavenAI(history, pref, ac.signal);
        const msg: ChatMessage = { id: uid(), role: "assistant", ...res };
        if (res.lang) setDetected(res.lang);
        setMessages((m) => [...m, msg]);
        if (opts?.viaVoice && tts.supported) tts.speak(msg.id, msg.content, langMeta(res.lang ?? uiLang).speech);
      } catch (e) {
        if ((e as Error)?.name === "AbortError") return;
        setMessages((m) => [...m, { id: uid(), role: "assistant", error: true, content: UI[uiLang].error, lang: uiLang }]);
      } finally {
        setLoading(false);
      }
    },
    [loading, messages, pref, tts, uiLang]
  );

  const voice = useSpeechRecognition((text) => send(text, { viaVoice: true }));
  const voiceErrMsg = useMemo(() => {
    switch (voice.error) {
      case "unsupported": return t.voiceUnsupported;
      case "denied": return t.voiceDenied;
      case "no-speech": return t.voiceNoSpeech;
      case "other": return t.voiceNoSpeech;
      default: return null;
    }
  }, [voice.error, t]);

  const consent = useConsent();
  const [voicePrompt, setVoicePrompt] = useState(false);
  const startVoice = () => {
    if (!consent.voice) return setVoicePrompt(true);
    tts.cancel();
    voice.start(langMeta(uiLang).speech);
  };
  const toggleMic = () => {
    if (voice.listening) return voice.stop();
    startVoice();
  };

  // Open from anywhere via custom event
  useEffect(() => {
    const on = (e: Event) => {
      const detail = (e as CustomEvent<{ question?: string; voice?: boolean }>).detail;
      setOpen(true);
      if (detail?.question) setTimeout(() => send(detail.question!), 150);
      else if (detail?.voice) setTimeout(startVoice, 250);
    };
    window.addEventListener("havenai:open", on);
    return () => window.removeEventListener("havenai:open", on);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [send, voice, uiLang, consent.voice]);

  useEffect(() => {
    if (!open) { tts.cancel(); voice.stop(); return; }
    const tm = setTimeout(() => inputRef.current?.focus(), 250);
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (langMenu) setLangMenu(false);
      else setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => { clearTimeout(tm); window.removeEventListener("keydown", onKey); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, langMenu]);

  const submit = (e: FormEvent) => { e.preventDefault(); send(input); };

  const retry = () => {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    send(lastUser.content, { base: messages.slice(0, messages.lastIndexOf(lastUser)) });
  };

  // Never let the floating launcher cover a donation QR code (phones scan the screen).
  const launcherRef = useRef<HTMLButtonElement>(null);
  const [yieldToQr, setYieldToQr] = useState(false);
  useEffect(() => {
    let raf = 0;
    const check = () => {
      raf = 0;
      const btn = launcherRef.current;
      const zones = document.querySelectorAll<HTMLElement>("[data-qr-zone]");
      if (!btn || !zones.length) return setYieldToQr(false);
      const b = btn.getBoundingClientRect();
      const pad = 12;
      const hit = Array.from(zones).some((z) => {
        const r = z.getBoundingClientRect();
        return r.width > 0 && b.left - pad < r.right && b.right + pad > r.left && b.top - pad < r.bottom && b.bottom + pad > r.top;
      });
      setYieldToQr(hit);
    };
    const schedule = () => { if (!raf) raf = requestAnimationFrame(check); };
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    const mo = new MutationObserver(schedule);
    mo.observe(document.body, { childList: true, subtree: true });
    schedule();
    return () => {
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      mo.disconnect();
      cancelAnimationFrame(raf);
    };
  }, []);

  const reset = () => { abortRef.current?.abort(); tts.cancel(); setLoading(false); setMessages([welcome(uiLang)]); };
  const onlyWelcome = messages.length === 1;

  return (
    <>
      {/* Launcher */}
      <button
        ref={launcherRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        data-yield={yieldToQr && !open ? "true" : undefined}
        aria-label={open ? "Close Haven AI assistant" : "Ask Haven AI"}
        aria-expanded={open}
        aria-controls="haven-ai-panel"
        className={cn(
          "group fixed bottom-5 right-5 z-[60] flex items-center gap-2 rounded-full bg-gradient-to-br from-tech-400 via-tech-500 to-aura-500 p-1 text-white shadow-[0_20px_60px_-10px_rgba(34,211,238,0.8)] transition-all duration-500 hover:scale-105 sm:bottom-7 sm:right-7",
          !open && "pr-4 sm:pr-6",
          yieldToQr && !open && "pointer-events-none translate-y-4 opacity-0"
        )}
      >
        {!open && <span aria-hidden className="absolute inset-0 rounded-full bg-tech-400/50 animate-pulse-ring" />}
        <span className="relative grid h-12 w-12 place-items-center rounded-full bg-ink-950/30 backdrop-blur sm:h-14 sm:w-14">
          {open ? <X className="h-5 w-5" /> : <Sparkles className="h-6 w-6" />}
        </span>
        {!open && (
          <span className="relative text-left leading-tight">
            <span className="block text-sm font-extrabold sm:text-base">Ask Haven AI</span>
            <span className="hidden text-[10px] font-medium text-white/80 sm:flex sm:items-center sm:gap-1">
              <Mic className="h-2.5 w-2.5" /> Voice · 5 languages
            </span>
          </span>
        )}
      </button>

      {/* Panel */}
      <div
        id="haven-ai-panel"
        role="dialog"
        aria-modal="false"
        aria-label="Haven AI assistant chat"
        lang={uiLang}
        className={cn(
          "glass-strong fixed z-[60] flex flex-col overflow-hidden transition-all duration-500 ease-[cubic-bezier(.2,.7,.2,1)]",
          "inset-x-2 bottom-[92px] top-20 rounded-3xl sm:inset-auto sm:bottom-32 sm:right-7 sm:h-[min(680px,calc(100vh-160px))] sm:w-[420px]",
          open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"
        )}
        inert={!open}
      >
        {/* Header */}
        <div className="relative flex items-center gap-2.5 border-b border-white/5 p-4">
          <div aria-hidden className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-tech-400/60 to-transparent" />
          <div className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-tech-400 to-aura-500">
            <Bot className="h-5 w-5 text-white" />
            <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-ink-900 bg-emerald-400" />
          </div>
          <div className="mr-auto min-w-0">
            <p className="font-bold text-white">Haven AI</p>
            <p className="truncate text-[11px] text-slate-400">{t.subtitle}{aiMode === "local" && " · grounded"}</p>
          </div>

          {/* Language picker */}
          <div className="relative">
            <button
              onClick={() => setLangMenu((v) => !v)}
              aria-haspopup="listbox"
              aria-expanded={langMenu}
              aria-label="Choose language"
              className="flex h-9 items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-2.5 text-xs font-bold uppercase text-slate-200 transition hover:bg-white/10"
            >
              <Globe className="h-3.5 w-3.5" />
              {pref === "auto" ? "Auto" : pref}
            </button>
            {langMenu && (
              <ul role="listbox" aria-label="Language" className="glass-strong absolute right-0 top-11 z-10 w-48 overflow-hidden rounded-2xl p-1.5 animate-fade-up">
                {[{ code: "auto" as const, native: t.auto }, ...LANGS].map((l) => (
                  <li key={l.code}>
                    <button
                      role="option"
                      aria-selected={pref === l.code}
                      onClick={() => { setPref(l.code); setLangMenu(false); }}
                      className={cn(
                        "flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm transition",
                        pref === l.code ? "bg-tech-400/15 text-tech-100" : "text-slate-300 hover:bg-white/5"
                      )}
                    >
                      <span>{l.native}</span>
                      <span className="text-[10px] font-bold uppercase text-slate-500">{l.code}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <button onClick={reset} className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-white/5 hover:text-white" aria-label="Start a new conversation" title="New conversation">
            <RotateCcw className="h-4 w-4" />
          </button>
          <button onClick={() => setOpen(false)} className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-white/5 hover:text-white" aria-label="Close assistant">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Messages */}
        <div ref={listRef} className="flex-1 space-y-4 overflow-y-auto p-4" aria-live="polite" aria-relevant="additions">
          {messages.map((m) => {
            const rtl = isRTL(m.content) && (m.role === "user" || m.lang === "ar");
            const speaking = tts.speakingId === m.id;
            return (
              <div key={m.id} className={cn("flex animate-fade-up", m.role === "user" ? "justify-end" : "justify-start")}>
                <div
                  dir={rtl ? "rtl" : "ltr"}
                  lang={m.lang}
                  className={cn(
                    "max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                    m.role === "user"
                      ? "rounded-tr-md bg-gradient-to-br from-hope-400 to-hope-500 font-medium text-ink-950"
                      : m.error
                        ? "rounded-tl-md border border-rose-400/30 bg-rose-400/10 text-rose-100"
                        : "rounded-tl-md bg-white/[0.06] text-slate-200"
                  )}
                >
                  {m.role === "user" ? (
                    <span className="inline-flex items-start gap-1.5">
                      {m.viaVoice && <Mic className="mt-0.5 h-3.5 w-3.5 shrink-0 opacity-70" aria-label="Voice question" />}
                      {m.content}
                    </span>
                  ) : (
                    <Markdown text={m.content} />
                  )}
                  {m.error && (
                    <button onClick={retry} className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold underline underline-offset-2">
                      <RefreshCw className="h-3 w-3" /> {t.retry}
                    </button>
                  )}
                  {m.role === "assistant" && !m.error && (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      {m.actions?.map((a) => {
                        const external = a.href.startsWith("http");
                        return (
                          <a
                            key={a.href + a.label}
                            href={a.href}
                            {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                            onClick={() => !external && window.innerWidth < 640 && setOpen(false)}
                            className="rounded-full border border-tech-400/30 bg-tech-400/10 px-3 py-1.5 text-xs font-semibold text-tech-200 transition hover:bg-tech-400/20"
                          >
                            {a.label} {rtl ? "←" : "→"}
                          </a>
                        );
                      })}
                      {tts.supported && (
                        <button
                          onClick={() => (speaking ? tts.cancel() : tts.speak(m.id, m.content, langMeta(m.lang ?? uiLang).speech))}
                          aria-pressed={speaking}
                          className={cn(
                            "inline-flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] font-semibold transition",
                            speaking ? "bg-hope-400/20 text-hope-200" : "text-slate-400 hover:bg-white/5 hover:text-white"
                          )}
                        >
                          {speaking ? <Square className="h-3 w-3" /> : <Volume2 className="h-3.5 w-3.5" />}
                          {speaking ? t.stop : t.listen}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {loading && (
            <div className="flex items-center gap-2 text-slate-400" aria-label="Haven AI is typing">
              <div className="flex gap-1 rounded-2xl rounded-tl-md bg-white/[0.06] px-4 py-3.5">
                {[0, 1, 2].map((i) => (
                  <span key={i} className="h-2 w-2 animate-bounce rounded-full bg-tech-300" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          )}
          {onlyWelcome && (
            <div className="flex flex-wrap gap-2 pt-1" dir={langMeta(uiLang).dir}>
              {t.suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-slate-200 transition hover:border-tech-400/40 hover:bg-tech-400/10"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Voice permission (just-in-time consent) */}
        {voicePrompt && !consent.voice && (
          <div className="border-t border-white/5 bg-white/[0.03] px-4 py-3" role="alertdialog" aria-labelledby="voice-consent-title">
            <p id="voice-consent-title" className="flex items-center gap-2 text-sm font-bold text-white"><Mic className="h-4 w-4 text-rose-300" /> Allow voice questions?</p>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">
              Your browser converts speech to text. Depending on your browser, audio may be processed by its vendor (e.g. Google or Apple).
              The microphone is used only while you speak.{" "}
              <button onClick={openPrivacySettings} className="text-hope-300 underline">Privacy settings</button>
            </p>
            <div className="mt-2.5 flex gap-2">
              <button
                onClick={() => { setConsent({ voice: true }); setVoicePrompt(false); tts.cancel(); voice.start(langMeta(uiLang).speech); }}
                className="rounded-lg bg-gradient-to-r from-tech-400 to-aura-500 px-3 py-1.5 text-xs font-bold text-white"
              >
                Allow & start
              </button>
              <button onClick={() => setVoicePrompt(false)} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-slate-300">Not now</button>
            </div>
          </div>
        )}

        {/* Voice status */}
        {(voice.listening || voiceErrMsg) && (
          <div className="border-t border-white/5 px-4 py-2.5" role="status" aria-live="assertive">
            {voice.listening ? (
              <div className="flex items-center gap-3">
                <span className="flex h-6 items-end gap-0.5" aria-hidden>
                  {[0, 1, 2, 3, 4].map((i) => (
                    <span key={i} className="w-1 animate-bounce rounded-full bg-rose-400" style={{ height: `${8 + (i % 3) * 6}px`, animationDelay: `${i * 0.1}s` }} />
                  ))}
                </span>
                <p className="min-w-0 flex-1 truncate text-sm text-slate-200" dir="auto">{voice.interim || t.listening}</p>
                <span className="text-[10px] font-bold uppercase text-slate-500">{langMeta(uiLang).speech}</span>
              </div>
            ) : (
              <p className="flex items-start gap-2 text-xs text-amber-200">
                <MicOff className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {voiceErrMsg}
                <button onClick={voice.clearError} className="ml-auto text-slate-400 hover:text-white" aria-label="Dismiss"><X className="h-3.5 w-3.5" /></button>
              </p>
            )}
          </div>
        )}

        {/* Input */}
        <form onSubmit={submit} className="border-t border-white/5 p-3">
          <div className="flex items-end gap-2 rounded-2xl border border-white/10 bg-ink-950/60 p-1.5 focus-within:border-tech-400/50">
            <button
              type="button"
              onClick={toggleMic}
              aria-label={voice.listening ? "Stop voice input" : "Ask with your voice"}
              aria-pressed={voice.listening}
              title={voice.supported ? undefined : t.voiceUnsupported}
              className={cn(
                "relative grid h-10 w-10 shrink-0 place-items-center rounded-xl transition",
                voice.listening ? "bg-rose-500 text-white" : "bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white",
                !voice.supported && "opacity-50"
              )}
            >
              {voice.listening && <span aria-hidden className="absolute inset-0 rounded-xl bg-rose-500/60 animate-pulse-ring" />}
              {voice.listening ? <Square className="relative h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </button>
            <label htmlFor="haven-ai-input" className="sr-only">Message Haven AI</label>
            <textarea
              id="haven-ai-input"
              ref={inputRef}
              rows={1}
              dir="auto"
              value={input}
              maxLength={500}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder={voice.listening ? t.listening : t.placeholder}
              className="max-h-28 min-h-10 flex-1 resize-none bg-transparent px-2 py-2.5 text-sm text-white outline-none placeholder:text-slate-500"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              aria-label="Send message"
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-tech-400 to-aura-500 text-white transition hover:scale-105 disabled:opacity-40 disabled:hover:scale-100"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
            </button>
          </div>
          <p className="mt-2 px-1 text-center text-[10px] text-slate-500">{t.disclaimer}</p>
        </form>
      </div>
    </>
  );
}
