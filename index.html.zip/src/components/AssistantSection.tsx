import { Bot, MessageCircle, ShieldCheck, Ban, Compass, Mic, Languages, Volume2 } from "lucide-react";
import { SectionHeading } from "./ui";
import { LANGS, UI } from "../services/ai";

export const openHavenAI = (question?: string, voice?: boolean) =>
  window.dispatchEvent(new CustomEvent("havenai:open", { detail: { question, voice } }));

export default function AssistantSection() {
  const features = [
    { icon: Compass, title: "Guides you", text: "Explains campaigns, donations and helps you navigate the site." },
    { icon: Languages, title: "Multilingual", text: "English, Español, Français, Português and العربية — auto-detected." },
    { icon: Mic, title: "Voice or text", text: "Ask by typing or speaking. Replies can be read aloud." },
    { icon: ShieldCheck, title: "Grounded answers", text: "Responds from verified Haven Fund information only." },
    { icon: Ban, title: "Never invents", text: "No made-up statistics, beneficiaries, projects or finances." },
    { icon: Bot, title: "Honest identity", text: "Always clear that it is an AI — never pretends to be human." },
  ];
  return (
    <section id="haven-ai" aria-labelledby="ai-title" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading id="ai-title" eyebrow="Haven AI Assistant" title="Ask anything." accent="In any voice." center={false}>
              Haven AI is our multilingual humanitarian assistant. Type or speak your question about Haven Fund, our campaigns,
              crypto donations, or how funds are intended to be used.
            </SectionHeading>
            <div className="reveal -mt-4 grid gap-3 sm:grid-cols-2">
              {features.map((f) => (
                <div key={f.title} className="glass rounded-2xl p-5">
                  <f.icon className="h-5 w-5 text-tech-300" />
                  <p className="mt-3 font-bold text-white">{f.title}</p>
                  <p className="mt-1 text-sm text-slate-400">{f.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="reveal relative">
            <div aria-hidden className="absolute -inset-8 -z-10 rounded-full bg-tech-500/15 blur-3xl" />
            <div className="glass-strong border-gradient rounded-[2rem] p-6 md:p-8">
              <div className="flex items-center gap-3">
                <div className="relative grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-tech-400 to-aura-500">
                  <Bot className="h-7 w-7 text-white" />
                  <span className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-ink-900 bg-emerald-400" />
                </div>
                <div className="mr-auto">
                  <p className="text-lg font-bold text-white">Haven AI</p>
                  <p className="text-xs text-slate-400">AI assistant · not a human</p>
                </div>
                <div className="flex flex-wrap justify-end gap-1">
                  {LANGS.map((l) => (
                    <span key={l.code} className="rounded-md border border-white/10 bg-white/5 px-1.5 py-0.5 text-[10px] font-bold uppercase text-slate-300">{l.code}</span>
                  ))}
                </div>
              </div>
              <div className="mt-6 space-y-3">
                <div className="ml-auto flex max-w-[80%] items-center gap-2 rounded-2xl rounded-tr-md bg-gradient-to-br from-hope-400 to-hope-500 p-4 text-sm font-medium text-ink-950">
                  <Mic className="h-4 w-4 shrink-0 opacity-70" /> ¿Qué campañas hay disponibles?
                </div>
                <div className="max-w-[88%] rounded-2xl rounded-tl-md bg-white/[0.06] p-4 text-sm text-slate-200">
                  Haven Fund ofrece campañas como <strong className="text-white">Meals of Hope</strong>, <strong className="text-white">Safe Haven</strong> y <strong className="text-white">Future Minds</strong>…
                  <span className="mt-2 flex items-center gap-1 text-[11px] text-slate-400"><Volume2 className="h-3.5 w-3.5" /> Escuchar</span>
                </div>
                <div className="ml-auto max-w-[70%] rounded-2xl rounded-tr-md bg-gradient-to-br from-hope-400 to-hope-500 p-4 text-sm font-medium text-ink-950" dir="rtl">
                  كيف تُستخدم التبرعات؟
                </div>
              </div>
              <p className="mt-6 text-xs font-semibold uppercase tracking-wider text-slate-500">Try asking</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {[UI.en.suggestions[0], UI.en.suggestions[1], UI.fr.suggestions[2], UI.pt.suggestions[0]].map((s) => (
                  <button
                    key={s}
                    onClick={() => openHavenAI(s)}
                    className="rounded-full border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-medium text-slate-200 transition hover:border-tech-400/50 hover:bg-tech-400/10"
                  >
                    {s}
                  </button>
                ))}
              </div>
              <div className="mt-6 grid gap-2 sm:grid-cols-[1fr_auto]">
                <button
                  onClick={() => openHavenAI()}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-tech-400 to-aura-500 px-5 py-3.5 font-bold text-white shadow-[0_12px_40px_-12px_rgba(34,211,238,0.7)] transition hover:scale-[1.01]"
                >
                  <MessageCircle className="h-5 w-5" /> Ask Haven AI
                </button>
                <button
                  onClick={() => openHavenAI(undefined, true)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3.5 font-bold text-white transition hover:bg-white/10"
                >
                  <Mic className="h-5 w-5 text-rose-300" /> Ask by voice
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
