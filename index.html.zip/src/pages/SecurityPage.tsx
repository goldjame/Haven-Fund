import {
  AlertTriangle, BadgeCheck, Ban, Bug, CheckCircle2, Cookie, CreditCard, EyeOff, FileLock2, Fingerprint, Globe, KeyRound, Lock, Mail, Phone,
  ServerCog, ShieldCheck, Smartphone,
} from "lucide-react";
import { CtaBand, PageHero, Section } from "../components/layout";
import { SectionHeading, FacebookIcon } from "../components/ui";
import { WalletRegistry } from "../components/Transparency";
import { connectionState } from "../components/security/SecureConnection";
import { openPrivacySettings } from "../services/consent";
import { ORG } from "../config/org";
import { to } from "../router";
import { cn } from "../utils/cn";

const MEASURES = [
  { icon: Lock, t: "HTTPS everywhere", d: "All traffic is encrypted with TLS. Plain-HTTP visits are redirected to HTTPS and browsers are told to always use HTTPS (HSTS)." },
  { icon: FileLock2, t: "Strict security headers", d: "A Content-Security-Policy limits what the page can load and where it can connect. Clickjacking, MIME-sniffing and referrer leaks are blocked." },
  { icon: Fingerprint, t: "Address safety checks", d: "Every wallet address is validated against its network’s format before it is shown. A failing address is hidden, never displayed." },
  { icon: CreditCard, t: "No card data — ever", d: "Donations go wallet-to-wallet. If a hosted checkout is enabled, it runs on the payment provider’s own secure HTTPS page from an approved list of domains." },
  { icon: EyeOff, t: "Privacy by default", d: "No tracking cookies, no analytics, no ad trackers. Fonts are self-hosted. Optional features stay off until you allow them." },
  { icon: ServerCog, t: "Hardened requests", d: "The site only talks to HTTPS services, with timeouts, no cookies sent to third parties and no referrer leakage." },
];

const NEVER = [
  "Ask for your seed phrase, recovery words, private key or wallet password",
  "Send you a different wallet address by direct message, email or phone",
  "Ask you to “verify” or “double” your crypto",
  "Offer refunds that require you to send crypto first",
  "Contact you from an account other than our official channels below",
];

export default function SecurityPage() {
  const conn = connectionState();
  return (
    <>
      <PageHero
        eyebrow="Security & Trust"
        title="Give with"
        accent="confidence."
        crumb="Security"
        chips={["HTTPS + HSTS", "Content-Security-Policy", "No tracking cookies", "Verified wallet formats"]}
      >
        How Haven Fund protects donors, the donation process and your privacy — plus how to spot scams and report a security issue.
      </PageHero>

      {/* Live check */}
      <Section className="pt-0 pb-6 md:pb-8">
        <div
          className={cn(
            "reveal flex flex-col gap-4 rounded-[1.75rem] border p-6 sm:flex-row sm:items-center",
            conn === "secure" ? "border-emerald-400/30 bg-emerald-400/[0.06]" : conn === "dev" ? "border-white/10 bg-white/[0.03]" : "border-rose-400/40 bg-rose-400/10"
          )}
        >
          <span className={cn("grid h-12 w-12 shrink-0 place-items-center rounded-2xl", conn === "secure" ? "bg-emerald-400/20 text-emerald-300" : conn === "dev" ? "bg-white/10 text-slate-300" : "bg-rose-400/20 text-rose-300")}>
            {conn === "insecure" ? <AlertTriangle className="h-6 w-6" /> : <ShieldCheck className="h-6 w-6" />}
          </span>
          <div>
            <p className="font-bold text-white">
              {conn === "secure" ? "Your connection to this site is secure." : conn === "dev" ? "You are viewing a local preview." : "Warning: this connection is not secure."}
            </p>
            <p className="text-sm text-slate-400">
              {conn === "secure"
                ? "Look for the padlock in your browser’s address bar and make sure the address is our official domain."
                : conn === "dev"
                  ? "The published website must be served over HTTPS."
                  : "Do not donate from this page. Reload using https:// or type our official address directly."}
            </p>
          </div>
        </div>
      </Section>

      {/* Measures */}
      <Section labelledBy="measures-title">
        <SectionHeading id="measures-title" eyebrow="How we protect you" title="Security" accent="built in.">
          Protections that apply every time you visit.
        </SectionHeading>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {MEASURES.map((m, i) => (
            <article key={m.t} className="reveal glass rounded-3xl p-7" style={{ transitionDelay: `${(i % 3) * 80}ms` }}>
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-tech-400/15 text-tech-300"><m.icon className="h-6 w-6" /></span>
              <h3 className="mt-5 text-lg font-bold text-white">{m.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{m.d}</p>
            </article>
          ))}
        </div>
      </Section>

      {/* Scam warnings */}
      <Section labelledBy="scam-title">
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="reveal glass-strong rounded-[2rem] p-7 md:p-9">
            <Ban className="h-7 w-7 text-rose-300" />
            <h2 id="scam-title" className="mt-4 font-display text-4xl text-white">Haven Fund will <em className="italic text-rose-300">never</em>…</h2>
            <ul className="mt-6 space-y-3">
              {NEVER.map((n) => (
                <li key={n} className="flex gap-3 text-sm text-slate-300">
                  <Ban className="mt-0.5 h-4 w-4 shrink-0 text-rose-300" /> {n}
                </li>
              ))}
            </ul>
          </div>
          <div className="reveal glass-strong rounded-[2rem] p-7 md:p-9">
            <BadgeCheck className="h-7 w-7 text-emerald-300" />
            <h2 className="mt-4 font-display text-4xl text-white">Official <em className="text-gradient italic">channels</em></h2>
            <p className="mt-2 text-sm text-slate-400">If in doubt, verify a wallet address through one of these before sending.</p>
            <ul className="mt-6 space-y-3 text-sm">
              <li><a href={ORG.emailHref} className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3.5 text-white hover:border-hope-400/30"><Mail className="h-4 w-4 text-hope-300" /> {ORG.email}</a></li>
              <li><a href={ORG.phoneHref} className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3.5 text-white hover:border-hope-400/30" dir="ltr"><Phone className="h-4 w-4 text-hope-300" /> {ORG.phone}</a></li>
              <li><a href={ORG.facebook} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3.5 text-white hover:border-hope-400/30"><FacebookIcon className="h-4 w-4 text-[#6ea8ff]" /> Haven Fund on Facebook</a></li>
              <li className="flex items-start gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3.5 text-slate-300"><Globe className="mt-0.5 h-4 w-4 shrink-0 text-hope-300" /> {ORG.address}</li>
            </ul>
          </div>
        </div>
      </Section>

      {/* Donor checklist */}
      <Section labelledBy="checklist-title">
        <SectionHeading id="checklist-title" eyebrow="Donor safety checklist" title="Five checks" accent="before you send.">
          Takes 30 seconds and protects your donation.
        </SectionHeading>
        <ol className="grid gap-4 md:grid-cols-5">
          {[
            { icon: Lock, t: "Padlock", d: "The page uses HTTPS on our official domain." },
            { icon: Smartphone, t: "Right network", d: "Your wallet’s network matches the donation card exactly." },
            { icon: Fingerprint, t: "Match the ends", d: "First and last 6 characters of the pasted address match." },
            { icon: KeyRound, t: "Keep keys private", d: "Never share seed phrases or private keys with anyone." },
            { icon: CheckCircle2, t: "Test if unsure", d: "Send a small amount first for large donations." },
          ].map((c, i) => (
            <li key={c.t} className="reveal glass rounded-3xl p-5" style={{ transitionDelay: `${i * 70}ms` }}>
              <div className="flex items-center justify-between">
                <c.icon className="h-5 w-5 text-hope-300" />
                <span className="font-display text-3xl text-white/10">0{i + 1}</span>
              </div>
              <p className="mt-4 font-bold text-white">{c.t}</p>
              <p className="mt-1 text-sm text-slate-400">{c.d}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section id="wallets" labelledBy="wallets-title" className="pt-0">
        <h2 id="wallets-title" className="sr-only">Official wallets</h2>
        <WalletRegistry />
      </Section>

      {/* Privacy + reporting */}
      <Section labelledBy="report-title" className="pt-0">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="reveal glass rounded-[2rem] p-7">
            <Cookie className="h-6 w-6 text-hope-300" />
            <h2 className="mt-4 text-xl font-bold text-white">Privacy & cookie controls</h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              We set no cookies and use no analytics. You decide whether to allow saved preferences, live price estimates and voice questions.
              We respect Global Privacy Control signals.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <button onClick={openPrivacySettings} className="rounded-xl border border-hope-400/40 bg-hope-400/10 px-4 py-2.5 text-sm font-bold text-hope-100 hover:bg-hope-400/20">
                Open privacy settings
              </button>
              <a href={to("privacy")} className="rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white hover:bg-white/10">Privacy Policy</a>
            </div>
          </div>
          <div className="reveal glass rounded-[2rem] p-7">
            <Bug className="h-6 w-6 text-tech-300" />
            <h2 id="report-title" className="mt-4 text-xl font-bold text-white">Report a security issue</h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              Found a vulnerability, a suspicious copy of this site, or a scam using our name? Please tell us right away. Include a description
              and, if relevant, links or screenshots. Please don’t publicly disclose issues before we’ve had a chance to fix them.
            </p>
            <a href={`${ORG.emailHref}?subject=${encodeURIComponent("Security report — Haven Fund")}`} className="mt-5 inline-flex items-center gap-2 rounded-xl border border-tech-400/40 bg-tech-400/10 px-4 py-2.5 text-sm font-bold text-tech-100 hover:bg-tech-400/20">
              <Mail className="h-4 w-4" /> Email a security report
            </a>
          </div>
        </div>
      </Section>

      <CtaBand title="Safe, simple, transparent." />
    </>
  );
}
