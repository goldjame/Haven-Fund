/**
 * LIVE tests — real internet, no mocks.
 * Verifies a REAL past donation to Haven Fund's Bitcoin address through the actual website UI.
 * (Emails are NOT sent live here to avoid messages to the real inbox — use scripts/activate-email.mjs.)
 */
import { test, expect } from "@playwright/test";
import { ASSETS, goToConfirmStep, presetConsent } from "./helpers";

test("real Bitcoin donation to Haven Fund verifies as confirmed on-chain", async ({ page }) => {
  await presetConsent(page);
  await page.route("https://formsubmit.co/**", (r) => r.fulfill({ json: { success: "true" } })); // don't email the real inbox
  await page.goto("/#/donate");
  const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "BTC")!, "0.00009597");
  await panel.getByRole("checkbox", { name: /I confirm/ }).check();
  await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
  await panel.locator("#txhash").fill("4546ce8818ae6e72125839a28b7f4cacc6b4cadce49c5062463bdbf5c4c8b1ad");
  await panel.getByRole("button", { name: "Verify on blockchain" }).click();
  await expect(panel.getByTestId("verify-status")).toHaveAttribute("data-status", "confirmed", { timeout: 30_000 });
  await expect(panel.getByTestId("verify-amount")).toHaveText(/0\.00009597 BTC/);
  await panel.getByRole("button", { name: "Complete donation" }).click();
  await expect(page.getByTestId("complete-title")).toHaveText(/Donation confirmed/);
});

test("a real transaction that did NOT pay Haven Fund is rejected (live Litecoin)", async ({ page, request }) => {
  const tip = await (await request.get("https://litecoinspace.org/api/blocks/tip/hash")).text();
  const txids: string[] = await (await request.get(`https://litecoinspace.org/api/block/${tip}/txids`)).json();
  await presetConsent(page);
  await page.goto("/#/donate");
  const panel = await goToConfirmStep(page, ASSETS.find((a) => a.id === "LTC")!);
  await panel.getByRole("checkbox", { name: /I confirm/ }).check();
  await panel.getByRole("button", { name: /I’ve sent my donation/ }).click();
  await panel.locator("#txhash").fill(txids[1]);
  await panel.getByRole("button", { name: "Verify on blockchain" }).click();
  await expect(panel.getByTestId("verify-status")).toHaveAttribute("data-status", "wrong_recipient", { timeout: 30_000 });
});
