/**
 * Donation campaigns (focus areas).
 * ------------------------------------------------------------------
 * These describe HOW donations are INTENDED to be used. They contain no
 * targets, totals, locations or beneficiary counts — add such data here
 * only once it is verified and published.
 *
 * All campaigns currently share the same donation wallets. A donor's
 * campaign preference is recorded with their donation reference.
 */

export type CampaignId = "general" | "food" | "shelter" | "warmth" | "education" | "care";

export interface Campaign {
  id: CampaignId;
  name: string;
  short: string;
  description: string;
  intendedUse: string[];
  accent: "hope" | "tech" | "aura" | "emerald" | "rose";
}

export const CAMPAIGNS: Campaign[] = [
  {
    id: "general",
    name: "Haven General Fund",
    short: "Where it’s needed most",
    description: "Flexible support that allows Haven Fund to respond to the most urgent needs of street children and homeless people.",
    intendedUse: ["Urgent needs as they arise", "Any of the focus areas below", "Operational essentials that make support possible"],
    accent: "hope",
  },
  {
    id: "food",
    name: "Meals of Hope",
    short: "Food & clean water",
    description: "Intended to provide nutritious meals and clean drinking water for children and adults living on the streets.",
    intendedUse: ["Hot and nutritious meals", "Clean drinking water", "Food packs for emergencies"],
    accent: "emerald",
  },
  {
    id: "shelter",
    name: "Safe Haven",
    short: "Shelter & safe nights",
    description: "Intended to fund safe, secure places to sleep — especially during extreme cold, heat or storms.",
    intendedUse: ["Emergency accommodation", "Safe night shelter", "Bedding and blankets"],
    accent: "aura",
  },
  {
    id: "warmth",
    name: "Warmth & Dignity",
    short: "Clothing & hygiene",
    description: "Intended to provide weather-appropriate clothing, shoes and hygiene essentials that restore comfort and dignity.",
    intendedUse: ["Warm clothing and shoes", "Hygiene kits", "Seasonal essentials"],
    accent: "rose",
  },
  {
    id: "education",
    name: "Future Minds",
    short: "Education for street children",
    description: "Intended to help street children access learning — the path from temporary help to lasting change.",
    intendedUse: ["School supplies", "Learning materials", "Access to education programmes"],
    accent: "tech",
  },
  {
    id: "care",
    name: "Essential Care",
    short: "Basic care & support",
    description: "Intended to connect vulnerable people with basic care and essential support services.",
    intendedUse: ["Access to basic care", "Essential support services", "Pathways toward stability"],
    accent: "hope",
  },
];

export const getCampaign = (id: CampaignId) => CAMPAIGNS.find((c) => c.id === id)!;
