import type { ReactNode } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "../utils/cn";
import { useCopy } from "../hooks";

export function SectionHeading({
  eyebrow,
  title,
  accent,
  children,
  center = true,
  id,
}: {
  eyebrow: string;
  title: string;
  accent?: string;
  children?: ReactNode;
  center?: boolean;
  id?: string;
}) {
  return (
    <div className={cn("reveal mb-12 max-w-3xl md:mb-16", center && "mx-auto text-center")}>
      <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-hope-300">
        <span className="h-1.5 w-1.5 rounded-full bg-hope-400 shadow-[0_0_10px_2px_rgba(245,180,60,0.7)]" />
        {eyebrow}
      </p>
      <h2 id={id} className="font-display text-4xl leading-[1.05] text-white sm:text-5xl md:text-6xl">
        {title} {accent && <em className="text-gradient italic">{accent}</em>}
      </h2>
      {children && <p className="mt-5 text-base leading-relaxed text-slate-400 md:text-lg">{children}</p>}
    </div>
  );
}

export function CopyButton({
  text,
  label = "Copy",
  className,
  compact,
}: {
  text: string;
  label?: string;
  className?: string;
  compact?: boolean;
}) {
  const { copied, error, copy } = useCopy();
  return (
    <span className="inline-flex flex-col">
      <button
        type="button"
        onClick={() => copy(text)}
        aria-label={copied ? "Copied to clipboard" : `${label} to clipboard`}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-xl border text-sm font-semibold transition-all duration-300",
          copied
            ? "border-emerald-400/40 bg-emerald-400/15 text-emerald-300"
            : "border-white/10 bg-white/5 text-white hover:border-hope-400/40 hover:bg-hope-400/10",
          compact ? "h-9 w-9" : "h-11 px-4",
          className
        )}
      >
        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
        {!compact && <span>{copied ? "Copied!" : label}</span>}
      </button>
      <span className="sr-only" aria-live="polite">
        {copied ? "Address copied to clipboard" : ""}
      </span>
      {error && <span className="mt-1 text-xs text-rose-300">{error}</span>}
    </span>
  );
}

export function Placeholder({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md border border-dashed border-amber-300/40 bg-amber-300/5 px-2 py-0.5 text-[13px] text-amber-200/90">
      <span className="rounded bg-amber-300/20 px-1 text-[9px] font-bold uppercase tracking-wider text-amber-200">
        Placeholder
      </span>
      {children}
    </span>
  );
}

export function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden className={className}>
      <path d="M24 12.07C24 5.41 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.8-4.7 4.54-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.5c-1.5 0-1.96.93-1.96 1.89v2.26h3.33l-.53 3.5h-2.8V24C19.62 23.1 24 18.1 24 12.07" />
    </svg>
  );
}
