import { test, expect, type Page } from "@playwright/test";
import { mockEmail, presetConsent } from "./helpers";

async function fill(page: Page, msg = "Hello Haven Fund — I would like to learn more about the Future Minds campaign.") {
  const f = page.getByTestId("contact-form");
  await f.getByLabel("Your name", { exact: true }).fill("Maria Lopez");
  await f.getByLabel("Email", { exact: true }).fill("maria@example.com");
  await f.getByLabel("Topic", { exact: true }).selectOption("Donation help");
  await f.getByLabel("Message", { exact: true }).fill(msg);
  await f.getByRole("checkbox", { name: /I agree/ }).check();
  return f;
}

test.describe("Contact form", () => {
  test("shows validation errors for an empty form", async ({ page }) => {
    await presetConsent(page);
    const email = await mockEmail(page);
    await page.goto("/#/contact");
    const f = page.getByTestId("contact-form");
    await f.getByRole("button", { name: "Send message" }).click();
    await expect(f.getByText("Please enter your name")).toBeVisible();
    await expect(f.getByText("Please enter a valid email address.")).toBeVisible();
    await expect(f.getByText("Please choose a topic.")).toBeVisible();
    await expect(f.getByText("Please write at least 20 characters.")).toBeVisible();
    await expect(f.getByText("Please agree so we can reply to you.")).toBeVisible();
    await expect(f.getByLabel("Your name")).toBeFocused();
    expect(email.requests).toHaveLength(0);
  });

  test("sends the message to havenfund@hotmail.com and confirms", async ({ page }) => {
    await presetConsent(page);
    const email = await mockEmail(page, "ok");
    await page.goto("/#/contact");
    const f = await fill(page);
    await page.waitForTimeout(3100); // anti-bot time trap
    await f.getByRole("button", { name: "Send message" }).click();
    await expect(page.getByText("Message received.")).toBeVisible();
    await expect(page.getByText(/team will get back to you/)).toBeVisible();
    expect(email.requests).toHaveLength(1);
    const r = email.requests[0];
    expect(r.url).toBe("https://formsubmit.co/ajax/havenfund%40hotmail.com");
    expect(r.body).toMatchObject({ Name: "Maria Lopez", Email: "maria@example.com", Topic: "Donation help", _replyto: "maria@example.com", _template: "table" });
    expect(r.body.Message).toContain("Future Minds");
    expect(r.body._subject).toContain("Maria Lopez");
    expect(r.referer).toMatch(/^http:\/\/localhost:4173\/?$/); // origin only, never the full URL
  });

  test("if email delivery fails, offers a pre-filled ‘Email us directly’ link", async ({ page }) => {
    await presetConsent(page);
    await mockEmail(page, "activation");
    await page.goto("/#/contact");
    const f = await fill(page);
    await page.waitForTimeout(3100);
    await f.getByRole("button", { name: "Send message" }).click();
    const link = f.getByRole("link", { name: "Email us directly" });
    await expect(link).toBeVisible();
    const href = decodeURIComponent((await link.getAttribute("href"))!);
    expect(href).toMatch(/^mailto:havenfund@hotmail\.com\?subject=/);
    expect(href).toContain("Future Minds");
  });

  test("network outage is handled", async ({ page }) => {
    await presetConsent(page);
    await mockEmail(page, "down");
    await page.goto("/#/contact");
    const f = await fill(page);
    await page.waitForTimeout(3100);
    await f.getByRole("button", { name: "Send message" }).click();
    await expect(f.getByRole("alert")).toContainText("couldn’t send your message");
  });

  test("anti-spam: instant bot submissions and repeat sends are blocked", async ({ page }) => {
    await presetConsent(page);
    const email = await mockEmail(page, "ok");
    const t0 = new Date("2026-06-01T12:00:00Z");
    await page.clock.install({ time: t0 });
    await page.goto("/#/contact");
    await page.clock.pauseAt(new Date(t0.getTime() + 1000)); // freeze time: a bot submitting ~instantly
    const f = await fill(page);
    await f.getByRole("button", { name: "Send message" }).click();
    await expect(f.getByRole("alert")).toContainText("That was quick");
    expect(email.requests).toHaveLength(0);
    await page.clock.fastForward(4000); // a human takes a few seconds
    await f.getByRole("button", { name: "Send message" }).click();
    await expect(page.getByText("Message received.")).toBeVisible();
    await page.getByRole("button", { name: "Send another message" }).click();
    await fill(page);
    await page.clock.fastForward(5000); // 5s later — still inside the 60s cooldown
    await page.getByTestId("contact-form").getByRole("button", { name: "Send message" }).click();
    await expect(page.getByTestId("contact-form").getByRole("alert")).toContainText("Please wait");
    expect(email.requests).toHaveLength(1);
  });

  test("honeypot: hidden field filled by a bot → nothing is sent", async ({ page }) => {
    await presetConsent(page);
    const email = await mockEmail(page, "ok");
    await page.goto("/#/contact");
    const f = await fill(page);
    await page.locator('[data-testid="contact-form"] input[tabindex="-1"]').evaluate((el: HTMLInputElement) => {
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!;
      set.call(el, "spam");
      el.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await page.waitForTimeout(3100);
    await f.getByRole("button", { name: "Send message" }).click();
    await page.waitForTimeout(800);
    expect(email.requests).toHaveLength(0);
  });

  test("email, phone, address and Facebook links are correct", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/contact");
    const main = page.locator("main");
    await expect(main.locator('a[href="mailto:havenfund@hotmail.com"]').first()).toBeVisible();
    await expect(main.locator('a[href="tel:+13154945538"]').first()).toBeVisible();
    await expect(main.locator('a[href="https://www.facebook.com/share/1DZA9K4PpQ/"]').first()).toBeVisible();
    await expect(main.getByText("23 Charter Oak Place #4")).toBeVisible();
    await expect(main.locator('a[href*="google.com/maps"]')).toHaveAttribute("href", /23\+Charter\+Oak\+Place/);
  });
});

test.describe("Updates sign-up", () => {
  test("validates and sends the subscription email", async ({ page }) => {
    await presetConsent(page);
    const email = await mockEmail(page, "ok");
    await page.goto("/#/updates");
    await page.getByLabel("Email address").fill("bad-email");
    await page.getByRole("button", { name: "Subscribe" }).click();
    await expect(page.getByText("Please enter a valid email address.")).toBeVisible();
    await page.getByLabel("Email address").fill("reader@example.com");
    await page.getByRole("button", { name: "Subscribe" }).click();
    await expect(page.getByText("You’re subscribed. Thank you!")).toBeVisible();
    expect(email.requests[0].body).toMatchObject({ Email: "reader@example.com", _replyto: "reader@example.com" });
  });
});
