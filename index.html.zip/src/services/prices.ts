/**
 * Optional USD price estimates.
 * Uses CoinGecko's public endpoint by default. Prices are ONLY used to
 * help donors estimate an amount; the blockchain transaction itself is
 * always the source of truth.
 */
import { secureFetch } from "./http";
import { ASSETS } from "../config/wallets";
import { hasConsent } from "./consent";

export type PriceMap = Record<string, number>;

const ENDPOINT =
  import.meta.env.VITE_PRICE_ENDPOINT ||
  `https://api.coingecko.com/api/v3/simple/price?ids=${[
    ...new Set(ASSETS.map((a) => a.priceId)),
  ].join(",")}&vs_currencies=usd`;

let cache: { at: number; data: PriceMap } | null = null;
const TTL = 60_000;

export class ConsentRequiredError extends Error {}

export async function fetchPrices(signal?: AbortSignal): Promise<PriceMap> {
  if (!hasConsent("prices")) throw new ConsentRequiredError("Live price estimates are turned off in privacy settings.");
  if (cache && Date.now() - cache.at < TTL) return cache.data;
  const res = await secureFetch(ENDPOINT, { signal, headers: { accept: "application/json" } }, { timeoutMs: 8000 });
  if (!res.ok) throw new Error(`Price service responded with ${res.status}`);
  const json = (await res.json()) as Record<string, { usd?: number }>;
  const data: PriceMap = {};
  for (const [k, v] of Object.entries(json)) {
    if (typeof v?.usd === "number" && v.usd > 0) data[k] = v.usd;
  }
  if (!Object.keys(data).length) throw new Error("Price data unavailable");
  cache = { at: Date.now(), data };
  return data;
}
