import { Building2, ExternalLink, FileText, Scale, ShieldAlert, Apple, Home, Shirt, BookOpen, HeartPulse, Link2, BarChart3 } from "lucide-react";
import { ASSETS, isValidAddress, shortAddress } from "../config/wallets";
import { ORG, isPlaceholder } from "../config/org";
import { to } from "../router";
import { CryptoIcon } from "./CryptoIcon";
import { CopyButton, Placeholder } from "./ui";

export const USES = [
  { icon: Apple, title: "Food & clean water", text: "Meals and nutrition for children and adults living on the streets.", campaign: "food" },
  { icon: Home, title: "Shelter", text: "Emergency and safe accommodation, especially in harsh weather.", campaign: "shelter" },
  { icon: Shirt, title: "Clothing & hygiene", text: "Warm clothing, blankets, shoes and hygiene essentials.", campaign: "warmth" },
  { icon: BookOpen, title: "Education", text: "School supplies, learning materials and access to education.", campaign: "education" },
  { icon: HeartPulse, title: "Essential support", text: "Access to basic care and pathways toward stability.", campaign: "care" },
] as const;

function Value({ v }: { v: string }) {
  if (isPlaceholder(v)) return <Placeholder>{v.slice(1, -1)}</Placeholder>;
  if (v.startsWith("http")) return <a href={v} target="_blank" rel="noopener noreferrer" className="text-tech-300 hover:underline">Haven Fund on Facebook ↗</a>;
  if (v.includes("@")) return <a href={`mailto:${v}`} className="text-white hover:underline">{v}</a>;
  if (v.startsWith("+")) return <a href={`tel:${v.replace(/\s/g, "")}`} className="text-white hover:underline" dir="ltr">{v}</a>;
  return <span className="text-white">{v}</span>;
}

/* ------------------------------ Wallet registry ----------------------------- */
export function WalletRegistry() {
  return (
    <div className="reveal glass-strong overflow-hidden rounded-[2rem]">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 p-6">
        <div>
          <h3 className="flex items-center gap-2 text-lg font-bold text-white"><Link2 className="h-5 w-5 text-tech-300" /> Official donation wallets</h3>
          <p className="text-sm text-slate-400">Supported cryptocurrencies, networks and public transaction references.</p>
        </div>
        <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-300">
          {ASSETS.filter((a) => isValidAddress(a)).length}/{ASSETS.length} addresses format-verified
        </span>
      </div>
      <ul className="divide-y divide-white/5">
        {ASSETS.map((a) => (
          <li key={a.id} className="grid items-center gap-4 p-5 transition hover:bg-white/[0.02] md:grid-cols-[220px_1fr_auto] md:px-6">
            <div className="flex items-center gap-3">
              <CryptoIcon id={a.id} size={36} />
              <div>
                <p className="font-bold text-white">{a.name}</p>
                <p className="text-xs text-tech-200">{a.network}</p>
              </div>
            </div>
            <p className="mono-break font-mono text-xs text-slate-400 sm:text-sm" title={a.address}>
              <span className="hidden lg:inline">{a.id === "LN" ? shortAddress(a.address, 28, 16) : a.address}</span>
              <span className="lg:hidden">{shortAddress(a.address, 14, 10)}</span>
            </p>
            <div className="flex items-center gap-2">
              <CopyButton text={a.address} compact label={`Copy ${a.name} address`} />
              {a.explorerAddress ? (
                <a
                  href={a.explorerAddress(a.address)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 text-xs font-semibold text-white transition hover:border-tech-400/40 hover:bg-tech-400/10"
                >
                  Transactions <ExternalLink className="h-3.5 w-3.5" />
                </a>
              ) : (
                <span className="inline-flex h-9 items-center rounded-xl border border-white/5 px-3 text-xs text-slate-500" title="Lightning payments are private and do not appear on a public explorer">
                  Off-chain · private
                </span>
              )}
            </div>
          </li>
        ))}
      </ul>
      <p className="border-t border-white/5 p-5 text-xs text-slate-500 md:px-6">
        Note: Ethereum (ETH) and USD Coin (USDC, ERC-20) share the same Ethereum address. Lightning payments settle off-chain and are not publicly listed.
      </p>
    </div>
  );
}

/* -------------------------------- Intended use ------------------------------ */
export function IntendedUse() {
  return (
    <div className="reveal glass rounded-[2rem] p-6 md:p-8">
      <h3 className="text-lg font-bold text-white">How donations are intended to be used</h3>
      <p className="mt-1 text-sm text-slate-400">Each area links to the matching campaign.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {USES.map((u) => (
          <a key={u.title} href={to("donate", undefined, { campaign: u.campaign })} className="group flex gap-3 rounded-2xl border border-white/5 bg-white/[0.02] p-4 transition hover:border-hope-400/30 hover:bg-white/[0.04]">
            <u.icon className="mt-0.5 h-5 w-5 shrink-0 text-hope-300" />
            <div>
              <p className="font-semibold text-white group-hover:text-hope-100">{u.title}</p>
              <p className="text-sm text-slate-400">{u.text}</p>
            </div>
          </a>
        ))}
        <div className="flex items-center gap-3 rounded-2xl border border-dashed border-white/10 p-4 text-sm text-slate-400">
          <BarChart3 className="h-5 w-5 shrink-0 text-slate-500" />
          A percentage allocation breakdown will be published once verified.
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- Impact reports ----------------------------- */
export function ImpactReports() {
  return (
    <div className="reveal glass rounded-[2rem] p-6 md:p-8">
      <h3 className="text-lg font-bold text-white">Impact reports</h3>
      <p className="mt-1 text-sm text-slate-400">Verified figures only. Nothing here is estimated or invented.</p>
      <dl className="mt-6 space-y-4 text-sm">
        {["Total donations received", "People supported", "Meals provided", "Shelter nights funded"].map((k) => (
          <div key={k} className="flex items-center justify-between gap-3 border-b border-white/5 pb-3">
            <dt className="text-slate-400">{k}</dt>
            <dd><Placeholder>Not yet published</Placeholder></dd>
          </div>
        ))}
      </dl>
      <p className="mt-5 text-xs text-slate-500">
        {ORG.reportsUrl ? (
          <a className="text-tech-300 underline" href={ORG.reportsUrl} target="_blank" rel="noopener noreferrer">View published reports</a>
        ) : (
          "Financial and impact reports will be linked here when available."
        )}
      </p>
    </div>
  );
}

/* ------------------------------ Organization info --------------------------- */
export function OrgInfo() {
  return (
    <div className="reveal glass rounded-[2rem] p-6 md:p-8">
      <h3 className="flex items-center gap-2 text-lg font-bold text-white"><Building2 className="h-5 w-5 text-hope-300" /> Organization information</h3>
      <dl className="mt-5 space-y-3.5 text-sm">
        {[
          ["Name", ORG.legalName],
          ["Registration no.", ORG.registration],
          ["Jurisdiction", ORG.jurisdiction],
          ["Founded", ORG.founded],
          ["Address", ORG.address],
          ["Email", ORG.email],
          ["Phone", ORG.phone],
          ["Facebook", ORG.facebook],
        ].map(([k, v]) => (
          <div key={k} className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
            <dt className="text-slate-500">{k}</dt>
            <dd className="sm:text-right"><Value v={v} /></dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

/* ---------------------------- Policies & disclaimers ------------------------ */
export function Policies() {
  return (
    <div className="reveal glass rounded-[2rem] p-6 md:p-8">
      <h3 className="flex items-center gap-2 text-lg font-bold text-white"><Scale className="h-5 w-5 text-hope-300" /> Policies & disclaimers</h3>
      <ul className="mt-5 space-y-3 text-sm text-slate-400">
        <li className="flex gap-2.5"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /> Cryptocurrency transactions are irreversible. Always verify the asset, network and address.</li>
        <li className="flex gap-2.5"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /> Tax-deductibility has not been confirmed. This site does not issue tax receipts.</li>
        <li className="flex gap-2.5"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /> USD values are estimates from a public price feed and may differ from actual value.</li>
        <li className="flex gap-2.5"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /> No certifications or partnerships are claimed on this website.</li>
      </ul>
      <div className="mt-6 flex flex-wrap gap-2">
        <a href={to("privacy")} className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white hover:bg-white/10"><FileText className="h-3.5 w-3.5" /> Privacy Policy</a>
        <a href={to("terms")} className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white hover:bg-white/10"><FileText className="h-3.5 w-3.5" /> Terms & Conditions</a>
      </div>
    </div>
  );
}
