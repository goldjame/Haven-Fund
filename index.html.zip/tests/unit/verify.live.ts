/** LIVE blockchain test for src/services/verify.ts — run: npm run test:chain */
Object.assign(globalThis, { window: { location: { origin: "https://havenfund.org" }, setTimeout, clearTimeout } });
import { verifyDonation, tronToHex20, ENDPOINTS } from "../../src/services/verify";
import { ASSETS } from "../../src/config/wallets";

const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
async function tronHexToBase58(hex20: string) {
  const payload = Uint8Array.from(("41" + hex20).match(/../g)!.map((h) => parseInt(h, 16)));
  const d1 = new Uint8Array(await crypto.subtle.digest("SHA-256", payload));
  const d2 = new Uint8Array(await crypto.subtle.digest("SHA-256", d1));
  const full = new Uint8Array([...payload, ...d2.slice(0, 4)]);
  let n = BigInt("0x" + Array.from(full, (b) => b.toString(16).padStart(2, "0")).join("")), s = "";
  while (n > 0n) { s = B58[Number(n % 58n)] + s; n /= 58n; }
  return s;
}
const j = async (url: string, body?: unknown) => (await fetch(url, body ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {})).json();
const rpc = (url: string, method: string, params: unknown[]) => j(url, { jsonrpc: "2.0", id: 1, method, params }).then((r: any) => r.result);

let pass = 0, fail = 0;
function expect(name: string, r: { status: string; received?: number; unit: string; detail?: string }, status: string, amount?: number) {
  const ok = r.status === status && (amount === undefined || Math.abs((r.received ?? -1) - amount) < 1e-9);
  ok ? pass++ : fail++;
  console.log(`${ok ? "✅" : "❌"} ${name.padEnd(46)} → ${r.status}${r.received !== undefined ? ` (${r.received} ${r.unit})` : ""}${ok ? "" : `  EXPECTED ${status}${amount !== undefined ? ` ${amount}` : ""} ${r.detail ?? ""}`}`);
}
const asset = (id: string, address?: string) => { const a = ASSETS.find((x) => x.id === id)!; return { ...a, address: address ?? a.address }; };
const FAKE64 = "ab".repeat(32);

(async () => {
  console.log("sanity: USDT contract hex =", tronToHex20("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"));

  // ---------- BTC: REAL donations to Haven Fund's own address ----------
  expect("BTC real donation to Haven Fund (9,597 sats)", await verifyDonation(asset("BTC"), "4546ce8818ae6e72125839a28b7f4cacc6b4cadce49c5062463bdbf5c4c8b1ad"), "confirmed", 0.00009597);
  expect("BTC real donation to Haven Fund (30,014 sats)", await verifyDonation(asset("BTC"), "9bbc54e91b2b396f20ba399a65262af9d6ab139399c4aeff0855201ca3f72e4b"), "confirmed", 0.00030014);
  expect("BTC unknown tx id", await verifyDonation(asset("BTC"), FAKE64), "not_found");

  // ---------- LTC ----------
  const tip = await (await fetch(`${ENDPOINTS.ltc}/blocks/tip/hash`)).text();
  const txids: string[] = await j(`${ENDPOINTS.ltc}/block/${tip}/txids`);
  const ltx: any = await j(`${ENDPOINTS.ltc}/tx/${txids[1]}`);
  const lout = ltx.vout.find((o: any) => o.scriptpubkey_address);
  const lsum = ltx.vout.filter((o: any) => o.scriptpubkey_address === lout.scriptpubkey_address).reduce((s: number, o: any) => s + o.value, 0) / 1e8;
  expect("LTC real tx → correct recipient", await verifyDonation(asset("LTC", lout.scriptpubkey_address), txids[1]), "confirmed", lsum);
  expect("LTC same tx → Haven Fund (not paid)", await verifyDonation(asset("LTC"), txids[1]), "wrong_recipient");
  expect("LTC unknown tx id", await verifyDonation(asset("LTC"), FAKE64), "not_found");

  // ---------- ETH native ----------
  const head = parseInt(await rpc(ENDPOINTS.eth, "eth_blockNumber", []), 16);
  const blk: any = await rpc(ENDPOINTS.eth, "eth_getBlockByNumber", ["0x" + (head - 3).toString(16), true]);
  const etx = blk.transactions.find((t: any) => t.input === "0x" && BigInt(t.value) > 0n && t.to);
  expect("ETH real transfer → correct recipient", await verifyDonation(asset("ETH", etx.to), etx.hash), "confirmed", Number(BigInt(etx.value)) / 1e18);
  expect("ETH same tx → Haven Fund (not paid)", await verifyDonation(asset("ETH"), etx.hash), "wrong_recipient");
  expect("ETH Haven Fund’s own OUTGOING tx (not a gift)", await verifyDonation(asset("ETH"), "0x874a8469d49a7c80ac93428b26d77181275b0b16d3d898eeb557dcd9759aad34"), "wrong_recipient");
  expect("ETH unknown tx hash", await verifyDonation(asset("ETH"), "0x" + FAKE64), "not_found");

  // ---------- USDC (ERC-20) ----------
  const logs: any[] = await rpc(ENDPOINTS.eth, "eth_getLogs", [{ address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", fromBlock: "0x" + (head - 6).toString(16), toBlock: "0x" + (head - 3).toString(16), topics: ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] }]);
  const ul = logs.find((l) => BigInt(l.data) > 0n);
  const uto = "0x" + ul.topics[2].slice(26);
  const usum = logs.filter((l) => l.transactionHash === ul.transactionHash && l.topics[2] === ul.topics[2]).reduce((s, l) => s + Number(BigInt(l.data)), 0) / 1e6;
  expect("USDC real transfer → correct recipient", await verifyDonation(asset("USDC", uto), ul.transactionHash), "confirmed", usum);
  expect("USDC same tx → Haven Fund (not paid)", await verifyDonation(asset("USDC"), ul.transactionHash), "wrong_recipient");

  // ---------- USDT (TRC-20) ----------
  const ev: any = await j("https://api.trongrid.io/v1/contracts/TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t/events?event_name=Transfer&limit=20&only_confirmed=true");
  const e = ev.data.find((x: any) => BigInt(x.result.value) > 0n);
  const tTo = await tronHexToBase58(e.result.to.replace(/^0x/, "").slice(-40));
  const tsum = ev.data.filter((x: any) => x.transaction_id === e.transaction_id && x.result.to === e.result.to).reduce((s: number, x: any) => s + Number(x.result.value), 0) / 1e6;
  expect(`USDT real transfer → correct recipient`, await verifyDonation(asset("USDT", tTo), e.transaction_id), "confirmed", tsum);
  expect("USDT same tx → Haven Fund (not paid)", await verifyDonation(asset("USDT"), e.transaction_id), "wrong_recipient");
  expect("USDT unknown tx id", await verifyDonation(asset("USDT"), FAKE64), "not_found");

  // ---------- SOL ----------
  const sigs: any[] = await rpc(ENDPOINTS.sol, "getSignaturesForAddress", ["11111111111111111111111111111111", { limit: 15 }]);
  let solOk = false;
  for (const s of sigs.filter((x) => !x.err)) {
    const tx: any = await rpc(ENDPOINTS.sol, "getTransaction", [s.signature, { encoding: "jsonParsed", maxSupportedTransactionVersion: 0 }]);
    if (!tx?.meta) continue;
    const keys = tx.transaction.message.accountKeys.map((k: any) => k.pubkey);
    const idx = keys.findIndex((_: string, i: number) => i > 0 && tx.meta.postBalances[i] > tx.meta.preBalances[i]);
    if (idx < 0) continue;
    expect("SOL real transfer → correct recipient", await verifyDonation(asset("SOL", keys[idx]), s.signature), "confirmed", (tx.meta.postBalances[idx] - tx.meta.preBalances[idx]) / 1e9);
    expect("SOL same tx → Haven Fund (not paid)", await verifyDonation(asset("SOL"), s.signature), "wrong_recipient");
    solOk = true;
    break;
  }
  if (!solOk) { fail++; console.log("❌ SOL: could not find a sample transfer"); }
  const rnd = crypto.getRandomValues(new Uint8Array(64)); let n = BigInt("0x" + Array.from(rnd, (b) => b.toString(16).padStart(2, "0")).join("")), fakeSig = "";
  while (n > 0n) { fakeSig = B58[Number(n % 58n)] + fakeSig; n /= 58n; }
  expect("SOL unknown (valid-format) signature", await verifyDonation(asset("SOL"), fakeSig), "not_found");
  expect("SOL malformed signature", await verifyDonation(asset("SOL"), "1".repeat(20)), "not_found");

  // ---------- Lightning ----------
  expect("Lightning → honestly unsupported", await verifyDonation(asset("LN"), FAKE64), "unsupported");

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
