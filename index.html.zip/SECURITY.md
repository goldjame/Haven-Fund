# Haven Fund — Security Guide

This website is a **static site** (one HTML file plus config files). It has **no admin panel, no database, no login and no server code**, which removes most of the usual attack surface. The main risks for a crypto donation site are:

1. **Someone swapping the wallet addresses** (hacked hosting, repository, domain or email account)
2. **Phishing copies** of the site or fake social accounts
3. **Insecure connections** letting attackers alter the page in transit

The website code covers what it can (section A). **Sections B–F must be done by the operators** — the security of the site depends on them.

---

## A. Built into the website ✅

| Control | Where |
|---|---|
| HTTPS redirect + HSTS | `public/_headers`, `public/.htaccess`, `vercel.json`, `deploy/nginx.conf`, plus a JS fallback in `src/main.tsx` |
| Content-Security-Policy, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy, COOP/CORP | same files (header) + `index.html` (meta fallback) |
| Clickjacking protection | `frame-ancestors 'none'` header + JS fallback that refuses to render inside frames |
| HTTPS-only network requests with timeouts; no cookies sent to third parties | `src/services/http.ts` |
| Wallet address format validation (invalid address → hidden) | `src/config/wallets.ts` |
| Wallet integrity pinning + tamper detection | `scripts/verify-wallets.mjs`, `security/wallets.lock.json` |
| Secure checkout: HTTPS + host allow-list + idempotency keys | `src/services/payments.ts` |
| "Secure connection" indicator before donors copy an address | `src/components/security/SecureConnection.tsx` |
| Privacy & cookie controls (no cookies, opt-in features, GPC respected) | `src/services/consent.ts`, `src/components/security/PrivacyControls.tsx` |
| Self-hosted fonts (no Google Fonts requests) | `src/fonts.css` |
| Contact form honeypot, time-trap and cooldown | `src/components/Contact.tsx` |
| Vulnerability disclosure contact | `public/.well-known/security.txt`, `#/security` page |
| Backup script with checksums and retention | `scripts/backup.mjs` |

---

## B. HTTPS / SSL certificate

- **Netlify, Vercel, Cloudflare Pages, GitHub Pages:** HTTPS is automatic and free. Enable **"Force HTTPS"** in the dashboard. `_headers` / `vercel.json` add the security headers.
- **cPanel / Apache:** enable **AutoSSL** or **Let's Encrypt** in cPanel. `.htaccess` (copied into `dist/`) forces HTTPS and sets headers.
- **VPS / Nginx:** use `deploy/nginx.conf`, then run `sudo certbot --nginx -d yourdomain.org` (renews automatically).
- After launch, test at **https://www.ssllabs.com/ssltest/** (aim for **A or A+**) and **https://securityheaders.com**.
- HSTS is set for 2 years. Only add `preload` and submit to hstspreload.org once you're sure **every subdomain** supports HTTPS.
- Enable **DNSSEC** and **registrar lock** at your domain registrar.

## C. Strong administrator passwords

"Admin" here means every account that could change the website or its addresses:

| Account | Why it matters |
|---|---|
| Hosting (Netlify/Vercel/cPanel) | can replace the website |
| Domain registrar | can point the domain to a fake site |
| Code repository (GitHub, etc.) | can change wallet addresses |
| **havenfund@hotmail.com** | password resets for everything above |
| Facebook page | used by donors to verify addresses |
| Crypto wallets / exchange | hold the donations |
| Payment provider (if used) | payouts and API keys |

Rules:
- Use a **password manager** (Bitwarden, 1Password, etc.) and a **unique, randomly generated password of 16+ characters** for every account. Never reuse passwords.
- Never share passwords by email or chat. Use the password manager's sharing feature.
- Remove access for anyone who leaves, and review access every quarter.
- Crypto **seed phrases must never be stored** in this project, email, cloud notes or photos. Write them on paper or metal and keep them offline. Consider a hardware wallet or multisig for funds.

## D. Two-factor authentication (2FA)

Turn on 2FA for **every account in the table above**, starting with the email account:

- Prefer an **authenticator app** (Microsoft Authenticator, Google Authenticator, Authy, 2FAS) or a **hardware security key / passkey** (YubiKey). Avoid SMS when possible (SIM-swap risk).
- **Microsoft (Hotmail):** account.microsoft.com → Security → Advanced security options → Two-step verification. Also add a passkey.
- **Facebook:** Settings → Accounts Center → Password and security → Two-factor authentication.
- **GitHub / hosting / registrar:** Settings → Security → 2FA.
- **Save recovery codes** offline in the password manager or on paper.
- Consider moving to a **domain email** (e.g. `hello@yourdomain.org`) for a more professional and controllable identity.

## E. Regular backups

```bash
node scripts/backup.mjs                  # timestamped .tar.gz + .sha256 in ./backups (keeps 14)
node scripts/backup.mjs --out /path/usb  # to an external drive
node scripts/backup.mjs --verify backups/havenfund-YYYYMMDD-HHMMSS.tar.gz
```

- **Schedule:** weekly, and **always before and after** changing wallet addresses or deploying.
  - macOS/Linux cron: `0 3 * * 0 cd /path/to/site && node scripts/backup.mjs --out /backup/drive`
  - Windows: Task Scheduler running `node scripts/backup.mjs`.
- **3-2-1 rule:** 3 copies, on 2 different media, 1 off-site (e.g. an encrypted cloud drive).
- A Git repository with a remote (GitHub/GitLab) also serves as versioned backup. Keep it **private** or at least protect the main branch.
- **Test a restore quarterly:** extract a backup, run `npm ci && npm run build`, open `dist/index.html`.
- Backups contain no secrets. Keep it that way: never add `.env` files with real secrets or seed phrases.

## F. Wallet address integrity (most important)

```bash
node scripts/verify-wallets.mjs --pin              # ONLY after verifying each address in the wallet app
node scripts/verify-wallets.mjs                    # before every deploy (source + dist)
node scripts/verify-wallets.mjs https://your.site  # the LIVE site: addresses, HTTPS, HSTS, CSP
```

- Run the live check **daily** (cron, UptimeRobot, or a scheduled GitHub Action) and alert on failure.
- When changing an address: verify it in the wallet app → update `src/config/wallets.ts` → `--pin` → build → verify → deploy → run the live check → announce the change on Facebook.
- Post your official addresses on the Facebook page as an independent verification channel.

## G. Secure payment-provider checkout (optional)

The site works without a payment provider (direct wallet donations). To add a hosted crypto checkout (e.g. **BTCPay Server** (self-hosted, no fees), **Coinbase Commerce**, **NOWPayments**):

1. Build a small backend (serverless function) that **creates the checkout session server-side** using the provider's **secret API key**. The key lives in the server's environment variables, **never** in `VITE_*` variables.
2. Set `VITE_PAYMENT_ENDPOINT=https://your-backend/…` and `VITE_CHECKOUT_ALLOWED_HOSTS=checkout.provider.com`. The site refuses to redirect anywhere else.
3. **Confirm payments only via signed webhooks:** verify the provider's HMAC signature and timestamp on every webhook, and reject replays. Never mark a donation "paid" based on a browser redirect.
4. Use the `Idempotency-Key` header the site sends to avoid duplicate sessions.
5. Restrict the backend's CORS to your domain and rate-limit it.

## H. If something goes wrong

1. **Suspected address tampering:** take the site offline (hosting dashboard → disable/rollback), post a warning on Facebook, restore from a verified backup, then change all passwords and review 2FA.
2. **Compromised account:** reset the password from a clean device, revoke sessions and API tokens, re-enable 2FA, check forwarding rules on the email account.
3. **Phishing site / fake page:** report it to the host, registrar and Facebook, and warn donors.
4. Security reports arrive at **havenfund@hotmail.com** (see `security.txt`). Acknowledge within 72 hours.

## I. Maintenance checklist

- [ ] Monthly: `npm audit` and update dependencies, rebuild, run `verify-wallets.mjs`
- [ ] Quarterly: review account access, test a backup restore, check SSL Labs / securityheaders.com
- [ ] Yearly: update `Expires` in `public/.well-known/security.txt` and review the Privacy Policy
