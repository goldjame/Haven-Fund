import { useEffect, useRef } from "react";
import Background from "./components/Background";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import HavenAI from "./components/HavenAI";
import LegalPage from "./components/LegalPage";
import Home from "./pages/Home";
import About from "./pages/About";
import CampaignsPage from "./pages/CampaignsPage";
import DonatePage from "./pages/DonatePage";
import ImpactPage from "./pages/ImpactPage";
import Updates from "./pages/Updates";
import ContactPage from "./pages/ContactPage";
import NotFound from "./pages/NotFound";
import SecurityPage from "./pages/SecurityPage";
import PrivacyControls from "./components/security/PrivacyControls";
import { useRevealAll } from "./hooks";
import { PAGE_META, useRoute, type PageId } from "./router";

function setMeta(name: string, content: string, attr: "name" | "property" = "name") {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.content = content;
}

const PAGES: Record<PageId, () => React.ReactElement> = {
  home: () => <Home />,
  about: () => <About />,
  campaigns: () => <CampaignsPage />,
  donate: () => <DonatePage />,
  impact: () => <ImpactPage />,
  updates: () => <Updates />,
  contact: () => <ContactPage />,
  privacy: () => <LegalPage kind="privacy" />,
  terms: () => <LegalPage kind="terms" />,
  security: () => <SecurityPage />,
  notfound: () => <NotFound />,
};

export default function App() {
  const route = useRoute();
  const prevPage = useRef<PageId | null>(null);
  const viewKey = `${route.page}/${route.page === "updates" ? route.param ?? "" : ""}`;

  useRevealAll(viewKey);

  // Per-page SEO metadata
  useEffect(() => {
    const meta = PAGE_META[route.page];
    if (!(route.page === "updates" && route.param)) document.title = meta.title;
    setMeta("description", meta.description);
    setMeta("og:title", meta.title, "property");
    setMeta("og:description", meta.description, "property");
    setMeta("robots", route.page === "notfound" ? "noindex" : "index,follow");
  }, [route.page, route.param]);

  // Scroll handling: new page → top (or section); same page → smooth scroll to section/top
  useEffect(() => {
    const pageChanged = prevPage.current !== route.page || route.page === "updates";
    prevPage.current = route.page;
    const section = route.page !== "updates" ? route.param : undefined;

    if (section) {
      const t = window.setTimeout(() => {
        const el = document.getElementById(section);
        if (el) el.scrollIntoView({ behavior: pageChanged ? "auto" : "smooth", block: "start" });
      }, pageChanged ? 80 : 0);
      if (pageChanged) window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      return () => window.clearTimeout(t);
    }
    window.scrollTo({ top: 0, behavior: pageChanged ? ("instant" as ScrollBehavior) : "smooth" });
    if (pageChanged) document.getElementById("main")?.focus({ preventScroll: true });
  }, [route.nonce, route.page, route.param]);

  return (
    <>
      <Background />
      <Navbar />
      <main id="main" tabIndex={-1} className="relative outline-none">
        <div key={viewKey} className="animate-page-in">
          {PAGES[route.page]()}
        </div>
      </main>
      <Footer />
      <HavenAI />
      <PrivacyControls />
    </>
  );
}
