import { test, expect } from "@playwright/test";
import { ROUTES, presetConsent, trackErrors, expectNoHorizontalScroll } from "./helpers";

test.describe("Every page renders correctly on this device", () => {
  for (const r of ROUTES) {
    test(`${r.path} — loads, no errors, fits the screen`, async ({ page }, info) => {
      await presetConsent(page);
      const errors = trackErrors(page);
      await page.goto(r.path);
      await expect(page.locator("h1").first()).toBeVisible();
      await expect(page.locator("h1").first()).toHaveText(r.h1);
      await expect(page.locator("h1")).toHaveCount(1);
      // Let reveal animations finish, then check layout
      await page.evaluate(async () => {
        for (let y = 0; y < document.body.scrollHeight; y += window.innerHeight) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 40)); }
        window.scrollTo(0, 0);
      });
      await expectNoHorizontalScroll(page);
      // Floating Haven AI button always reachable
      await expect(page.getByRole("button", { name: /Ask Haven AI|Open Haven AI|Close Haven AI/ }).last()).toBeVisible();
      if (info.project.name !== "desktop" && r.path === "/#/") await page.screenshot({ path: `test-results/screens/${info.project.name}-home.png`, fullPage: false });
      if (info.project.name !== "desktop" && r.path === "/#/donate") await page.screenshot({ path: `test-results/screens/${info.project.name}-donate.png`, fullPage: false });
      expect(errors).toEqual([]);
    });
  }

  test("unknown address shows a friendly 404 page", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/this-page-does-not-exist");
    await expect(page.locator("h1")).toContainText("nowhere");
    await page.getByRole("link", { name: "Back to home" }).click();
    await expect(page.locator("h1")).toContainText("Digital Wallet");
  });
});

test.describe("Navigation", () => {
  test("menu reaches every main page", async ({ page, isMobile }, info) => {
    await presetConsent(page);
    await page.goto("/#/");
    const pages = [
      { label: "About Us", h1: /Technology with/ },
      { label: "Campaigns", h1: /kindness goes/ },
      { label: "How Donations Help", h1: /real needs/ },
      { label: "Updates", h1: /told honestly/ },
      { label: "Contact", h1: /about hope/ },
      { label: "Home", h1: /Digital Wallet/ },
    ];
    const useBurger = isMobile || info.project.name === "ipad-mini";
    for (const p of pages) {
      if (useBurger) {
        await page.getByRole("button", { name: "Open menu" }).click();
        await page.locator("#mobile-menu").getByRole("link", { name: new RegExp(`^${p.label}`) }).click();
        await expect(page.locator("#mobile-menu")).toHaveClass(/opacity-0/);
      } else {
        await page.getByRole("navigation", { name: "Primary" }).getByRole("link", { name: p.label, exact: true }).click();
      }
      await expect(page.locator("h1")).toHaveText(p.h1);
      expect(await page.evaluate(() => window.scrollY)).toBeLessThan(5);
    }
  });

  test("mobile menu tap targets are large enough", async ({ page, isMobile }) => {
    test.skip(!isMobile, "phones only");
    await presetConsent(page);
    await page.goto("/#/");
    const burger = page.getByRole("button", { name: "Open menu" });
    const b = await burger.boundingBox();
    expect(b!.height).toBeGreaterThanOrEqual(40);
    await burger.click();
    for (const link of await page.locator("#mobile-menu a").all()) {
      const bb = await link.boundingBox();
      if (bb && bb.width > 0) expect(bb.height, await link.innerText()).toBeGreaterThanOrEqual(24);
    }
    await page.keyboard.press("Escape");
    await expect(page.locator("#mobile-menu")).toHaveClass(/opacity-0/);
  });

  test("browser back/forward works between pages", async ({ page }) => {
    await presetConsent(page);
    await page.goto("/#/");
    await page.goto("/#/campaigns");
    await page.goto("/#/contact");
    await page.goBack();
    await expect(page.locator("h1")).toHaveText(/kindness goes/);
    await page.goForward();
    await expect(page.locator("h1")).toHaveText(/about hope/);
  });
});
