#!/usr/bin/env node
/**
 * External link checker — visits every outbound link found by the E2E crawl
 * (test-results/links.json, produced by tests/e2e/links.spec.ts).
 *
 *   npx playwright test --project=desktop links.spec && node scripts/check-links.mjs
 *
 * Results: OK (2xx/3xx), BOT-BLOCKED (403/429/999 from anti-bot protection —
 * the page exists but refuses automated checks; open it by hand once), BROKEN.
 */
import { readFileSync, writeFileSync } from "node:fs";

const file = "test-results/links.json";
let data;
try {
  data = JSON.parse(readFileSync(file, "utf8"));
} catch {
  console.error(`Missing ${file}. Run: npx playwright test --project=desktop links.spec`);
  process.exit(2);
}
const urls = Object.keys(data.external).sort();
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36";

async function check(url) {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow", headers: { "user-agent": UA, accept: "text/html,*/*" }, signal: AbortSignal.timeout(15000) });
      const s = res.status;
      if (s < 400) return { url, status: s, result: "OK", final: res.url };
      if ([401, 403, 405, 429, 999].includes(s)) return { url, status: s, result: "BOT-BLOCKED" };
      if (attempt === 1) return { url, status: s, result: "BROKEN" };
    } catch (e) {
      if (attempt === 1) return { url, status: 0, result: "BROKEN", error: e.message };
    }
    await new Promise((r) => setTimeout(r, 1500));
  }
}

const results = [];
for (let i = 0; i < urls.length; i += 4) {
  results.push(...(await Promise.all(urls.slice(i, i + 4).map(check))));
}

// Second opinion for anything not OK: open it in a real browser (many sites block plain HTTP clients).
const suspicious = results.filter((r) => r.result !== "OK");
if (suspicious.length) {
  const { chromium } = await import("@playwright/test");
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ userAgent: UA, locale: "en-US" });
  for (const r of suspicious) {
    const page = await ctx.newPage();
    try {
      const res = await page.goto(r.url, { waitUntil: "domcontentloaded", timeout: 15000 });
      await page.waitForTimeout(1200);
      const title = await page.title();
      const status = res?.status() ?? 0;
      if (status && status < 400) Object.assign(r, { status, result: "OK", via: "browser", title });
      else if (/just a moment|attention required|cloudflare|security verification/i.test(title)) Object.assign(r, { status, result: "BOT-BLOCKED", via: "browser", title: "Cloudflare bot protection" });
      else Object.assign(r, { status, result: "BROKEN", via: "browser", title });
    } catch (e) {
      Object.assign(r, { result: r.result === "BOT-BLOCKED" ? "BOT-BLOCKED" : "BROKEN", error: e.message.split("\n")[0] });
    }
    await page.close();
  }
  await browser.close();
}
const icon = { OK: "✅", "BOT-BLOCKED": "🛡️ ", BROKEN: "❌" };
for (const r of results) console.log(`${icon[r.result]} ${String(r.status).padEnd(4)} ${r.url}${r.via ? `  [browser: ${r.title?.slice(0, 50)}]` : ""}${r.error ? `  (${r.error})` : ""}`);
const broken = results.filter((r) => r.result === "BROKEN");
const blocked = results.filter((r) => r.result === "BOT-BLOCKED");
console.log(`\n${results.length} external links · ${results.length - broken.length - blocked.length} OK · ${blocked.length} bot-blocked (check manually) · ${broken.length} broken`);
writeFileSync("test-results/external-links.json", JSON.stringify(results, null, 2));
process.exit(broken.length ? 1 : 0);
