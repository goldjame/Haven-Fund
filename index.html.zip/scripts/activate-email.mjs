#!/usr/bin/env node
/**
 * ONE-TIME: activate email delivery for the website's forms.
 *
 *   node scripts/activate-email.mjs https://your-live-domain.org
 *
 * Sends a single test submission to FormSubmit for havenfund@hotmail.com.
 * FormSubmit then emails an "Activate Form" link to that inbox — click it once.
 * Run it again afterwards: you should receive the test message itself.
 * Use your LIVE domain: activation is tied to the website address.
 */
const site = process.argv[2];
const to = process.argv[3] || "havenfund@hotmail.com";
if (!site || !/^https:\/\//.test(site)) {
  console.error("Usage: node scripts/activate-email.mjs https://your-live-domain.org [email]");
  process.exit(2);
}
const origin = new URL(site).origin;
const res = await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(to)}`, {
  method: "POST",
  headers: { "content-type": "application/json", accept: "application/json", Origin: origin, Referer: `${origin}/` },
  body: JSON.stringify({
    _subject: "Haven Fund website — email delivery test",
    _template: "table",
    _captcha: "false",
    Message: "If you can read this, contact-form and donation emails are working.",
    Sent: new Date().toISOString(),
  }),
});
const data = await res.json().catch(() => ({}));
if (data.success === "true" || data.success === true) {
  console.log(`✅ Delivered. Check ${to} (and the spam folder) for "Haven Fund website — email delivery test".`);
} else if (/activat/i.test(data.message || "")) {
  console.log(`📧 Activation needed. Open ${to}, find the FormSubmit email, click "Activate Form", then run this script again.`);
} else {
  console.log(`❌ ${res.status} ${data.message || "Unknown response"}`);
  process.exit(1);
}
