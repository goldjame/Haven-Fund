import { Apple, BookOpen, Moon, PenLine } from "lucide-react";
import { SectionHeading } from "./ui";

const SCENARIOS = [
  {
    icon: Moon,
    tag: "Shelter",
    title: "A night off the pavement",
    text: "Imagine a cold night where, instead of sleeping in a doorway, someone has a warm, safe bed and a door that locks. That is what shelter support is meant to make possible.",
    gradient: "from-aura-500/30 via-tech-500/10",
  },
  {
    icon: Apple,
    tag: "Food",
    title: "A meal that means tomorrow",
    text: "For a child living on the street, a reliable meal is more than food — it’s the energy to learn, to play, and to feel that someone cares.",
    gradient: "from-hope-500/30 via-amber-500/10",
  },
  {
    icon: BookOpen,
    tag: "Education",
    title: "A notebook, a future",
    text: "School supplies and access to learning can open a door that the streets keep closed. Education is how temporary help becomes lasting change.",
    gradient: "from-tech-500/30 via-emerald-500/10",
  },
];

export default function Stories() {
  return (
    <section id="stories" aria-labelledby="stories-title" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading id="stories-title" eyebrow="Stories of Hope" title="The human side" accent="of every block.">
          Real stories will be shared only with informed consent and with identities protected. Until then, these
          illustrative scenarios show what your support is intended to make possible.
        </SectionHeading>

        <div className="grid gap-6 md:grid-cols-3">
          {SCENARIOS.map((s, i) => (
            <article
              key={s.title}
              className="reveal group relative overflow-hidden rounded-[2rem] border border-white/10 bg-ink-900/60 p-7 transition duration-500 hover:-translate-y-2"
              style={{ transitionDelay: `${i * 110}ms` }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${s.gradient} to-transparent opacity-60 transition duration-700 group-hover:opacity-100`} />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/10 text-white backdrop-blur">
                    <s.icon className="h-6 w-6" />
                  </span>
                  <span className="rounded-full border border-white/15 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-slate-300">{s.tag}</span>
                </div>
                <h3 className="mt-16 font-display text-3xl leading-tight text-white">{s.title}</h3>
                <p className="mt-3 leading-relaxed text-slate-300">{s.text}</p>
                <p className="mt-6 inline-flex items-center gap-1.5 rounded-md bg-black/30 px-2 py-1 text-[11px] font-semibold text-slate-400">
                  Illustrative scenario — not a real person or event
                </p>
              </div>
            </article>
          ))}
        </div>

        <div className="reveal glass mt-6 flex flex-col items-start gap-4 rounded-[2rem] p-6 sm:flex-row sm:items-center md:p-8">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-hope-400/15 text-hope-300">
            <PenLine className="h-6 w-6" />
          </span>
          <div className="flex-1">
            <p className="font-bold text-white">Verified stories coming soon</p>
            <p className="text-sm text-slate-400">We will never publish testimonials, photos or names without consent — especially for children.</p>
          </div>
          <a href="#/donate" className="btn-shine rounded-xl px-5 py-3 text-sm font-bold text-ink-950">Be part of the story</a>
        </div>
      </div>
    </section>
  );
}
